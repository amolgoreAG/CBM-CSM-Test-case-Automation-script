package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CSM;
import PageLayerPackage.CSM_Login;

public class CSM_Login_Test extends Base_Class_CSM {
	
	private static final Logger log = Logger.getLogger(CSM_Login_Test.class);
	
	public static CSM_Login login;

	@Test(priority = 1)
	public void user_is_on_login_page() {
		Base_Class_CSM.CSM();
		log.info("Open the Chrome and Open CSM URL");
	}

	@Test(priority = 2)
	public void display_Status_of_Username_Test() {
		login = new CSM_Login();
		Assert.assertEquals(login.display_Status_of_Username(), true);
		log.info("display status of login page : " + login.display_Status_of_Username());
	}

	@Test(priority = 3)
	public void enable_Status_of_Username_Test() {
		Assert.assertEquals(login.enable_Status_of_Username(), true);
		log.info("enable status of login page : " + login.enable_Status_of_Username());
	}

	@Test(priority = 4)
	public void enter_username_Test() {
		login.enter_username();
	}

	@Test(priority = 5)
	public void display_Status_of_Password_Test() {
		Assert.assertEquals(login.display_Status_of_Password(), true);
		log.info("display_Status_of_Password: " + login.display_Status_of_Password());
	}

	@Test(priority = 6)
	public void enable_Status_of_Password_Test() {
		Assert.assertEquals(login.enable_Status_of_Password(), true);
		log.info("enable_Status_of_Password: " + login.enable_Status_of_Password());
	}

	@Test(priority = 7)
	public void enter_Password_Test() {
		login.enter_Password();
	}

	@Test(priority = 8)
	public void display_Status_of_Login_Test() {
		Assert.assertEquals(login.display_Status_of_Login(), true);
		log.info("display_Status_of_Login: " + login.display_Status_of_Login());
	}

	@Test(priority = 9)
	public void enable_Status_of_Login_Test() {
		Assert.assertEquals(login.enable_Status_of_Login(), true);
		log.info("enable_Status_of_Login: " + login.enable_Status_of_Login());
	}

	@Test(priority = 10)
	public void tab_on_login_Test() {
		login.tab_on_login();
	}
}
