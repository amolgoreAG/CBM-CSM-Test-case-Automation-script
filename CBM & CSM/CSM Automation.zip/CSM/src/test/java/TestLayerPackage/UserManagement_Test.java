package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CSM;
import PageLayerPackage.UserManagement;

public class UserManagement_Test extends Base_Class_CSM{

	private static final Logger log = Logger.getLogger(UserManagement_Test.class);
	
public static UserManagement um ;
	
	@Test(priority = 371)
	public void display_Status_of_UserManagement_Test() {
		um = new UserManagement();
		Assert.assertEquals(um.display_Status_of_UserManagement(), true);
		log.info("display_Status_of_UserManagement : " + um.display_Status_of_UserManagement());
	}
	
	@Test(priority = 372)
	public void enable_Status_of_UserManagement_Test() {
		Assert.assertEquals(um.enable_Status_of_UserManagement(), true);
		log.info("enable_Status_of_UserManagement : " + um.enable_Status_of_UserManagement());
	}
	
	@Test(priority = 373)
	public void click_on_UserManagement_Test() {
		um.click_on_UserManagement();
		log.info("click_on_UserManagement");
	}
	@Test(priority = 374)
	public void display_Status_of_Add_New_User_Test() {
		Assert.assertEquals(um.display_Status_of_Add_New_User(), true);
		log.info("display_Status_of_Add_New_User : " + um.display_Status_of_Add_New_User());
	}
	
	@Test(priority = 375)
	public void enable_Status_of_Add_New_User_Test() {
		Assert.assertEquals(um.enable_Status_of_Add_New_User(), true);
		log.info("enable_Status_of_Add_New_User : " + um.enable_Status_of_Add_New_User());
	}
	
	@Test(priority = 375)
	public void click_on_Add_New_User_Test() {
		um.click_on_Add_New_User();
		log.info("click_on_Add_New_User");
	}
	@Test(priority = 376)
	public void display_Status_of_Employe_ID_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_Employe_ID(), true);
		log.info("display_Status_of_Employe_ID : " + um.display_Status_of_Employe_ID());
	}
	
	@Test(priority = 377)
	public void enable_Status_of_Employe_ID_Test() {
		Assert.assertEquals(um.enable_Status_of_Employe_ID(), true);
		log.info("enable_Status_of_Employe_ID : " + um.enable_Status_of_Employe_ID());
	}
	
	@Test(priority = 378)
	public void enter_Employe_ID_Test() {
		um.enter_Employe_ID();
		log.info("enter_Employe_ID");
	}
	@Test(priority = 379)
	public void display_Status_of_password_Test() {
		Assert.assertEquals(um.display_Status_of_password(), true);
		log.info("display_Status_of_password : " + um.display_Status_of_password());
	}
	
	@Test(priority = 380)
	public void enable_Status_of_password_Test() {
		Assert.assertEquals(um.enable_Status_of_password(), true);
		log.info("enable_Status_of_password : " + um.enable_Status_of_password());
	}
	
	@Test(priority = 381)
	public void enter_password_Test() {
		um.enter_password();
		log.info("enter_password");
	}
	@Test(priority = 382)
	public void display_Status_of_firstName_Test() {
		Assert.assertEquals(um.display_Status_of_firstName(), true);
		log.info("display_Status_of_firstName : " + um.display_Status_of_firstName());
	}
	
	@Test(priority = 383)
	public void enable_Status_of_firstName_Test() {
		Assert.assertEquals(um.enable_Status_of_firstName(), true);
		log.info("enable_Status_of_firstName : " + um.enable_Status_of_firstName());
	}
	
	@Test(priority = 384)
	public void enter_firstName_Test() {
		um.enter_firstName();
		log.info("enter_firstName");
	}
	@Test(priority = 385)
	public void display_Status_of_lastName_Test() {
		Assert.assertEquals(um.display_Status_of_lastName(), true);
		log.info("display_Status_of_lastName : " + um.display_Status_of_lastName());
	}
	
	@Test(priority = 386)
	public void enable_Status_of_lastName_Test() {
		Assert.assertEquals(um.enable_Status_of_lastName(), true);
		log.info("enable_Status_of_lastName : " + um.enable_Status_of_lastName());
	}
	
	@Test(priority = 387)
	public void enter_lastName_Test() {
		um.enter_lastName();
		log.info("enter_lastName");
	}
	@Test(priority = 388)
	public void display_Status_of_email_Test() {
		Assert.assertEquals(um.display_Status_of_email(), true);
		log.info("display_Status_of_email : " + um.display_Status_of_email());
	}
	
	@Test(priority = 389)
	public void enable_Status_of_email_Test() {
		Assert.assertEquals(um.enable_Status_of_email(), true);
		log.info("enable_Status_of_email : " + um.enable_Status_of_email());
	}
	
	@Test(priority = 390)
	public void enter_email_Test() {
		um.enter_email();
		log.info("enter_email");
	}
	@Test(priority = 391)
	public void display_Status_of_Role_DP_Test() {
		Assert.assertEquals(um.display_Status_of_Role_DP(), true);
		log.info("display_Status_of_Role_DP : " + um.display_Status_of_Role_DP());
	}
	
	@Test(priority = 392)
	public void enable_Status_of_Role_DP_Test() {
		Assert.assertEquals(um.enable_Status_of_Role_DP(), true);
		log.info("enable_Status_of_Role_DP : " + um.enable_Status_of_Role_DP());
	}
	
	@Test(priority = 393)
	public void tab_on_Role_DP_And_select_Admin_Test() {
		um.tab_on_Role_DP_And_select_Admin();
		log.info("tab_on_Role_DP_And_select_Admin");
	}
	@Test(priority = 394)
	public void display_Status_of_mobile_number_Test() {
		Assert.assertEquals(um.display_Status_of_mobile_number(), true);
		log.info("display_Status_of_mobile_number : " + um.display_Status_of_mobile_number());
	}
	
	@Test(priority = 395)
	public void enable_Status_of_mobile_number_Test() {
		Assert.assertEquals(um.enable_Status_of_mobile_number(), true);
		log.info("enable_Status_of_mobile_number : " + um.enable_Status_of_mobile_number());
	}
	
	@Test(priority = 396)
	public void enter_mobile_number_Test() {
		um.enter_mobile_number();
		log.info("enter_mobile_number");
	}
	@Test(priority = 397)
	public void display_Status_of_Survey_Type_DP_Test() {
		Assert.assertEquals(um.display_Status_of_Survey_Type_DP(), true);
		log.info("display_Status_of_Survey_Type_DP : " + um.display_Status_of_Survey_Type_DP());
	}
	
	@Test(priority = 398)
	public void enable_Status_of_Survey_Type_DP_Test() {
		Assert.assertEquals(um.enable_Status_of_Survey_Type_DP(), true);
		log.info("enable_Status_of_Survey_Type_DP : " + um.enable_Status_of_Survey_Type_DP());
	}
	
	@Test(priority = 399)
	public void tab_on_Survey_Type_DP_Test() throws InterruptedException {
		um.tab_on_Survey_Type_DP();
		log.info("tab_on_Survey_Type_DP");
	}
	@Test(priority = 400)
	public void display_Status_of_Add_User_save_Test() {
		Assert.assertEquals(um.display_Status_of_Add_User_save(), true);
		log.info("display_Status_of_Add_User_save : " + um.display_Status_of_Add_User_save());
	}
	
	@Test(priority = 401)
	public void enable_Status_of_Add_User_save_Test() {
		Assert.assertEquals(um.enable_Status_of_Add_User_save(), true);
		log.info("enable_Status_of_Add_User_save : " + um.enable_Status_of_Add_User_save());
	}
	
//	@Test(priority = 402)
	public void tab_on_Add_User_save_Test() throws InterruptedException {
		um.tab_on_Add_User_save();
		log.info("tab_on_Add_User_save");
	}
	@Test(priority = 403)
	public void display_Status_of_Add_User_Close_Test() {
		Assert.assertEquals(um.display_Status_of_Add_User_Close(), true);
		log.info("display_Status_of_Add_User_Close : " + um.display_Status_of_Add_User_Close());
	}
	
	@Test(priority = 404)
	public void enable_Status_of_Add_User_Close_Test() {
		Assert.assertEquals(um.enable_Status_of_Add_User_Close(), true);
		log.info("enable_Status_of_Add_User_Close : " + um.enable_Status_of_Add_User_Close());
	}
	
	@Test(priority = 405)
	public void tab_on_Add_User_Close_Test() throws InterruptedException {
		um.tab_on_Add_User_Close();
		log.info("tab_on_Add_User_Close");
	}
	@Test(priority = 406)
	public void display_Status_of_edit_Test() {
		Assert.assertEquals(um.display_Status_of_edit(), true);
		log.info("display_Status_of_edit : " + um.display_Status_of_edit());
	}
	
	@Test(priority = 407)
	public void enable_Status_of_edit_Test() {
		Assert.assertEquals(um.enable_Status_of_edit(), true);
		log.info("enable_Status_of_edit : " + um.enable_Status_of_edit());
	}
	
	@Test(priority = 408)
	public void tab_on_edit_Test() throws InterruptedException {
		um.tab_on_edit();
		log.info("tab_on_edit");
	}
	@Test(priority = 409)
	public void display_Status_of_edit_Employe_ID_Test() {
		Assert.assertEquals(um.display_Status_of_edit_Employe_ID(), false);
		log.info("display_Status_of_edit_Employe_ID : " + um.display_Status_of_edit_Employe_ID());
	}
	
	@Test(priority = 410)
	public void enable_Status_of_edit_Employe_ID_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_Employe_ID(), false);
		log.info("enable_Status_of_edit_Employe_ID : " + um.enable_Status_of_edit_Employe_ID());
	}
	@Test(priority = 411)
	public void display_Status_of_edit_mobile_number_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_edit_mobile_number(), true);
		log.info("display_Status_of_edit_mobile_number : " + um.display_Status_of_edit_mobile_number());
	}
	
	@Test(priority = 412)
	public void enable_Status_of_edit_mobile_number_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_mobile_number(), true);
		log.info("enable_Status_of_edit_mobile_number : " + um.enable_Status_of_edit_mobile_number());
	}
	
	@Test(priority = 413)
	public void tab_on_edit_mobile_number_Test() throws InterruptedException {
		um.tab_on_edit_mobile_number();
		log.info("tab_on_edit_mobile_number");
	}
	@Test(priority = 414)
	public void display_Status_of_edit_firstName_Test() {
		Assert.assertEquals(um.display_Status_of_edit_firstName(), true);
		log.info("display_Status_of_edit_firstName : " + um.display_Status_of_edit_firstName());
	}
	
	@Test(priority = 415)
	public void enable_Status_of_edit_firstName_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_firstName(), true);
		log.info("enable_Status_of_edit_firstName : " + um.enable_Status_of_edit_firstName());
	}
	
	@Test(priority = 416)
	public void tab_on_edit_firstName_Test() throws InterruptedException {
		um.tab_on_edit_firstName();
		log.info("tab_on_edit_firstName");
	}
	@Test(priority = 417)
	public void display_Status_of_edit_lastName_Test() {
		Assert.assertEquals(um.display_Status_of_edit_lastName(), true);
		log.info("display_Status_of_edit_lastName : " + um.display_Status_of_edit_lastName());
	}
	
	@Test(priority = 418)
	public void enable_Status_of_edit_lastName_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_lastName(), true);
		log.info("enable_Status_of_edit_lastName : " + um.enable_Status_of_edit_lastName());
	}
	
	@Test(priority = 419)
	public void tab_on_edit_lastName_Test() throws InterruptedException {
		um.tab_on_edit_lastName();
		log.info("tab_on_edit_lastName");
	}
	@Test(priority = 420)
	public void display_Status_of_edit_email_Test() {
		Assert.assertEquals(um.display_Status_of_edit_email(), true);
		log.info("display_Status_of_edit_email : " + um.display_Status_of_edit_email());
	}
	
	@Test(priority = 421)
	public void enable_Status_of_edit_email_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_email(), true);
		log.info("enable_Status_of_edit_email : " + um.enable_Status_of_edit_email());
	}
	
	@Test(priority = 422)
	public void tab_on_edit_email_Test() throws InterruptedException {
		um.tab_on_edit_email();
		log.info("tab_on_edit_email");
	}
	@Test(priority = 423)
	public void display_Status_of_edit_Role_DP_Test() {
		Assert.assertEquals(um.display_Status_of_edit_Role_DP(), true);
		log.info("display_Status_of_edit_Role_DP : " + um.display_Status_of_edit_Role_DP());
	}
	
	@Test(priority = 424)
	public void enable_Status_of_edit_Role_DP_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_Role_DP(), true);
		log.info("enable_Status_of_edit_Role_DP : " + um.enable_Status_of_edit_Role_DP());
	}
	
	@Test(priority = 425)
	public void tab_on_edit_Role_DP_and_Select_Dp_value_Test() throws InterruptedException {
		um.tab_on_edit_Role_DP_and_Select_Dp_value();
		log.info("tab_on_edit_Role_DP_and_Select_Dp_value");
	}
	@Test(priority = 426)
	public void display_Status_of_Edit_Survey_Type_DP_Test() {
		Assert.assertEquals(um.display_Status_of_Edit_Survey_Type_DP(), true);
		log.info("display_Status_of_Edit_Survey_Type_DP : " + um.display_Status_of_Edit_Survey_Type_DP());
	}
	
	@Test(priority = 427)
	public void enable_Status_of_Edit_Survey_Type_DP_Test() {
		Assert.assertEquals(um.enable_Status_of_Edit_Survey_Type_DP(), true);
		log.info("enable_Status_of_Edit_Survey_Type_DP : " + um.enable_Status_of_Edit_Survey_Type_DP());
	}
	
	@Test(priority = 428)
	public void tab_on_Edit_Survey_Type_DP_and_select_dp_value_Test() throws InterruptedException {
		um.tab_on_Edit_Survey_Type_DP_and_select_dp_value();
		log.info("tab_on_Edit_Survey_Type_DP_and_select_dp_value");
	}
	@Test(priority = 429)
	public void display_Status_of_Edit_change_pass_checkbox_Test() {
		Assert.assertEquals(um.display_Status_of_Edit_change_pass_checkbox(), true);
		log.info("display_Status_of_Edit_change_pass_checkbox : " + um.display_Status_of_Edit_change_pass_checkbox());
	}
	
	@Test(priority = 430)
	public void enable_Status_of_Edit_change_pass_checkbox_Test() {
		Assert.assertEquals(um.enable_Status_of_Edit_change_pass_checkbox(), true);
		log.info("enable_Status_of_Edit_change_pass_checkbox : " + um.enable_Status_of_Edit_change_pass_checkbox());
	}
	
	@Test(priority = 431)
	public void tab_on_change_pass_checkbox_Test() throws InterruptedException {
		um.tab_on_change_pass_checkbox();
		log.info("tab_on_change_pass_checkbox");
	}
	@Test(priority = 432)
	public void display_Status_of_Edit_password_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_Edit_password(), true);
		log.info("display_Status_of_Edit_password : " + um.display_Status_of_Edit_password());
	}
	
	@Test(priority = 433)
	public void enable_Status_of_Edit_password_Test() {
		Assert.assertEquals(um.enable_Status_of_Edit_password(), true);
		log.info("enable_Status_of_Edit_password : " + um.enable_Status_of_Edit_password());
	}
	
	@Test(priority = 434)
	public void Enter_Edit_password_Test() throws InterruptedException {
		um.Enter_Edit_password();
		log.info("Enter_Edit_password");
	}
	@Test(priority = 435)
	public void display_Status_of_edit_Update_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_edit_Update(), true);
		log.info("display_Status_of_edit_Update : " + um.display_Status_of_edit_Update());
	}
	
	@Test(priority = 436)
	public void enable_Status_of_edit_Update_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_Update(), true);
		log.info("enable_Status_of_edit_Update : " + um.enable_Status_of_edit_Update());
	}
	
//	@Test(priority = 437)
	public void tab_on_edit_Update_Test() throws InterruptedException {
		um.tab_on_edit_Update();
		log.info("tab_on_edit_Update");
	}
	@Test(priority = 438)
	public void display_Status_of_edit_Close_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_edit_Close(), true);
		log.info("display_Status_of_edit_Close : " + um.display_Status_of_edit_Close());
	}
	
	@Test(priority = 439)
	public void enable_Status_of_edit_Close_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_Close(), true);
		log.info("enable_Status_of_edit_Close : " + um.enable_Status_of_edit_Close());
	}
	
	@Test(priority = 440)
	public void tab_on_edit_Close_Test() throws InterruptedException {
		um.tab_on_edit_Close();
		log.info("tab_on_edit_Close");
	}
	@Test(priority = 441)
	public void display_Status_of_option_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_option(), true);
		log.info("display_Status_of_option : " + um.display_Status_of_option());
	}
	
	@Test(priority = 442)
	public void enable_Status_of_option_Test() {
		Assert.assertEquals(um.enable_Status_of_option(), true);
		log.info("enable_Status_of_option : " + um.enable_Status_of_option());
	}
	
	@Test(priority = 443)
	public void tab_on_option_Test() throws InterruptedException {
		um.tab_on_option();
		log.info("tab_on_option");
	}
	@Test(priority = 444)
	public void display_Status_of_sign_out_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_sign_out(), true);
		log.info("display_Status_of_sign_out : " + um.display_Status_of_sign_out());
	}
	
	@Test(priority = 445)
	public void enable_Status_of_sign_out_Test() {
		Assert.assertEquals(um.enable_Status_of_sign_out(), true);
		log.info("enable_Status_of_sign_out : " + um.enable_Status_of_sign_out());
	}
	
	@Test(priority = 446)
	public void tab_on_sign_out_Test() throws InterruptedException {
		um.tab_on_sign_out();
		log.info("tab_on_sign_out");
	}
}
