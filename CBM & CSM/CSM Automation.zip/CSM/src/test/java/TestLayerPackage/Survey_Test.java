package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CSM;
import PageLayerPackage.Survey;

public class Survey_Test extends Base_Class_CSM {

	private static final Logger log = Logger.getLogger(Survey_Test.class);
	public static Survey survey;

	@Test(priority = 11)
	public void display_Status_of_Survey_Test() {
		survey = new Survey();
		Assert.assertEquals(survey.display_Status_of_Survey(), true);
		log.info("display_Status_of_Survey : " + survey.display_Status_of_Survey());
	}

	@Test(priority = 12)
	public void enable_Status_of_Survey_Test() {
		Assert.assertEquals(survey.enable_Status_of_Survey(), true);
		log.info("enable_Status_of_Survey : " + survey.enable_Status_of_Survey());
	}

	@Test(priority = 13)
	public void click_on_Survey_Test() {
		survey.click_on_Survey();
		log.info("click_on_Survey");
	}

	@Test(priority = 14)
	public void display_Status_of_Survey_Element_Test() {
		Assert.assertEquals(survey.display_Status_of_Survey_Element(), true);
		log.info("display_Status_of_Survey_Element : " + survey.display_Status_of_Survey_Element());
	}

	@Test(priority = 15)
	public void enable_Status_of_Survey_Element_Test() {
		Assert.assertEquals(survey.enable_Status_of_Survey_Element(), true);
		log.info("enable_Status_of_Survey_Element : " + survey.enable_Status_of_Survey_Element());

	}

	@Test(priority = 16)
	public void click_on_Survey_Element_Test() {
		survey.click_on_Survey_Element();
		log.info("click_on_Survey_Element");
	}

	@Test(priority = 17)
	public void display_Status_of_Response_Test() {
		Assert.assertEquals(survey.display_Status_of_Response(), true);
		log.info("display_Status_of_Response : " + survey.display_Status_of_Response());
	}

	@Test(priority = 18)
	public void enable_Status_of_Response_Test() {
		Assert.assertEquals(survey.enable_Status_of_Response(), true);
		log.info("enable_Status_of_Response : " + survey.enable_Status_of_Response());
	}

	@Test(priority = 19)
	public void click_on_Response_Test() {
		survey.click_on_Response();
		log.info("click_on_Response");
	}

	@Test(priority = 20)
	public void display_Status_of_Add_response_Test() throws InterruptedException {
		Assert.assertEquals(survey.display_Status_of_Add_response(), true);
		log.info("display_Status_of_Add_response : " + survey.display_Status_of_Add_response());
	}

	@Test(priority = 21)
	public void enable_Status_of_Add_response_Test() {
		Assert.assertEquals(survey.enable_Status_of_Add_response(), true);
		log.info("enable_Status_of_Add_response : " + survey.enable_Status_of_Add_response());
	}

	@Test(priority = 22)
	public void click_on_Add_response_Test() {
		survey.click_on_Add_response();
		log.info("click_on_Add_response");
	}

	@Test(priority = 23)
	public void display_Status_of_Enter_response_Test() {
		Assert.assertEquals(survey.display_Status_of_Enter_response(), true);
		log.info("display_Status_of_Enter_response : " + survey.display_Status_of_Enter_response());
	}

	@Test(priority = 24)
	public void enable_Status_of_Enter_response_Test() {
		Assert.assertEquals(survey.enable_Status_of_Enter_response(), true);
		log.info("enable_Status_of_Enter_response : " + survey.enable_Status_of_Enter_response());
	}

//	@Test(priority = 25)
	public void Enter_response_Test() {
		survey.Enter_response("Very Very Very Good");
		log.info("Enter_response");
	}

	@Test(priority = 26)
	public void display_Status_of_Save_response_Test() {
		Assert.assertEquals(survey.display_Status_of_Save_response(), true);
		log.info("display_Status_of_Save_response : " + survey.display_Status_of_Save_response());
	}

	@Test(priority = 27)
	public void enable_Status_of_Save_response_Test() {
		Assert.assertEquals(survey.enable_Status_of_Save_response(), true);
		log.info("enable_Status_of_Save_response : " + survey.enable_Status_of_Save_response());
	}

	@Test(priority = 28)
	public void Tab_on_Save_response_Test() {
		survey.Tab_on_Save_response();
		log.info("Tab_on_Save_response");
	}

	@Test(priority = 29)
	public void display_Status_of_Edit_response_Test() {
		Assert.assertEquals(survey.display_Status_of_Edit_response(), true);
		log.info("display_Status_of_Edit_response : " + survey.display_Status_of_Edit_response());
	}

	@Test(priority = 30)
	public void enable_Status_of_Edit_response_Test() {
		Assert.assertEquals(survey.enable_Status_of_Edit_response(), true);
		log.info("enable_Status_of_Edit_response : " + survey.enable_Status_of_Edit_response());
	}

	@Test(priority = 31)
	public void Tab_on_Edit_response_Test() throws InterruptedException {
		survey.Tab_on_Edit_response();
		log.info("Tab_on_Edit_response");
	}

	@Test(priority = 32)
	public void display_Status_of_change_response_Test() {
		Assert.assertEquals(survey.display_Status_of_change_response(), true);
		log.info("display_Status_of_change_response : " + survey.display_Status_of_change_response());
	}

	@Test(priority = 33)
	public void enable_Status_of_change_response_Test() {
		Assert.assertEquals(survey.enable_Status_of_change_response(), true);
		log.info("enable_Status_of_change_response : " + survey.enable_Status_of_change_response());
	}

	@Test(priority = 34)
	public void Tab_on_change_response_and_change_text_Test() throws InterruptedException {
		survey.Tab_on_change_response_and_change_text("Very Very Bad");
		log.info("Tab_on_change_response_and_change_text");
	}

	@Test(priority = 35)
	public void display_Status_of_Delete_response_Test() {
		Assert.assertEquals(survey.display_Status_of_Delete_response(), true);
		log.info("display_Status_of_Delete_response : " + survey.display_Status_of_Delete_response());
	}

	@Test(priority = 36)
	public void enable_Status_of_Delete_response_Test() {
		Assert.assertEquals(survey.enable_Status_of_Delete_response(), true);
		log.info("enable_Status_of_Delete_response : " + survey.enable_Status_of_Delete_response());
	}

	@Test(priority = 37)
	public void Tab_on_Delete_response_Test() throws InterruptedException {
		survey.Tab_on_Delete_response();
		log.info("Tab_on_Delete_response");
	}

	@Test(priority = 38)
	public void click_on_Response_Test2() throws InterruptedException {
		survey.click_on_Response();
		log.info("click_on_Response");
	}

	@Test(priority = 39)
	public void display_Status_of_assessed_Skill_Test() {
		Assert.assertEquals(survey.display_Status_of_assessed_Skill(), true);
			log.info("display_Status_of_assessed_Skill : " + survey.display_Status_of_assessed_Skill());	}

	@Test(priority = 40)
	public void enable_Status_of_assessed_Skill_Test() {
		Assert.assertEquals(survey.enable_Status_of_assessed_Skill(), true);
			log.info("enable_Status_of_assessed_Skill : " + survey.enable_Status_of_assessed_Skill());	}

	@Test(priority = 41)
	public void Tab_on_assessed_Skill_Test() throws InterruptedException {
		survey.Tab_on_assessed_Skill();
			log.info("Tab_on_assessed_Skill");	}

	@Test(priority = 42)
	public void display_Status_of_Add_assessed_Skill_Test() {
		Assert.assertEquals(survey.display_Status_of_Add_assessed_Skill(), true);
		log.info("display_Status_of_Add_assessed_Skill : " + survey.display_Status_of_Add_assessed_Skill());
	}

	@Test(priority = 43)
	public void enable_Status_of_Add_assessed_Skill_Test() {
		Assert.assertEquals(survey.enable_Status_of_Add_assessed_Skill(), true);
		log.info("enable_Status_of_Add_assessed_Skill : " + survey.enable_Status_of_Add_assessed_Skill());
	}

	@Test(priority = 44)
	public void Tab_on_Add_assessed_Skill_Test() throws InterruptedException {
		survey.Tab_on_Add_assessed_Skill();
		log.info("Tab_on_Add_assessed_Skill");
	}

	@Test(priority = 45)
	public void display_Status_of_Enter_assessed_Skill_Test() {
		Assert.assertEquals(survey.display_Status_of_Enter_assessed_Skill(), true);
		log.info("display_Status_of_Enter_assessed_Skill : " + survey.display_Status_of_Enter_assessed_Skill());
	}

	@Test(priority = 46)
	public void enable_Status_of_Enter_assessed_Skill_Test() {
		Assert.assertEquals(survey.enable_Status_of_Enter_assessed_Skill(), true);
		log.info("enable_Status_of_Enter_assessed_Skill : " + survey.enable_Status_of_Enter_assessed_Skill());
	}

//	@Test(priority = 47)
	public void Enter_assessed_Skill_Test() throws InterruptedException {
		survey.Enter_assessed_Skill("Competition");
		log.info("Enter_assessed_Skill");
	}

	@Test(priority = 48)
	public void display_Status_of_Save_assessed_Skill_Test() {
		Assert.assertEquals(survey.display_Status_of_Save_assessed_Skill(), true);
		log.info("display_Status_of_Save_assessed_Skill : " + survey.display_Status_of_Save_assessed_Skill());
	}

	@Test(priority = 49)
	public void enable_Status_of_Save_assessed_Skill_Test() {
		Assert.assertEquals(survey.enable_Status_of_Save_assessed_Skill(), true);
		log.info("enable_Status_of_Save_assessed_Skill : " + survey.enable_Status_of_Save_assessed_Skill());
	}

	@Test(priority = 50)
	public void Tab_On_Save_assessed_Skill_Test() throws InterruptedException {
		survey.Tab_On_Save_assessed_Skill();
		log.info("Tab_On_Save_assessed_Skill");
	}

	@Test(priority = 51)
	public void display_Status_of_Edit_assessed_Skill_Test() {
		Assert.assertEquals(survey.display_Status_of_Edit_assessed_Skill(), true);
		log.info("display_Status_of_Edit_assessed_Skill : " + survey.display_Status_of_Edit_assessed_Skill());
	}

	@Test(priority = 52)
	public void enable_Status_of_Edit_assessed_Skill_Test() {
		Assert.assertEquals(survey.enable_Status_of_Edit_assessed_Skill(), true);
		log.info("enable_Status_of_Edit_assessed_Skill : " + survey.enable_Status_of_Edit_assessed_Skill());
	}

	@Test(priority = 53)
	public void Tab_On_Edit_assessed_Skill_Test() throws InterruptedException {
		survey.Tab_On_Edit_assessed_Skill();
		log.info("Tab_On_Edit_assessed_Skill");
	}

	@Test(priority = 54)
	public void display_Status_of_change_assessed_Skill_Test() {
		Assert.assertEquals(survey.display_Status_of_change_assessed_Skill(), true);
		log.info("display_Status_of_change_assessed_Skill : " + survey.display_Status_of_change_assessed_Skill());
	}

	@Test(priority = 55)
	public void enable_Status_of_change_assessed_Skill_Test() {
		Assert.assertEquals(survey.enable_Status_of_change_assessed_Skill(), true);
		log.info("enable_Status_of_change_assessed_Skill : " + survey.enable_Status_of_change_assessed_Skill());
	}

	@Test(priority = 56)
	public void Tab_On_change_assessed_Skill_clear_and_again_enter_Test() throws InterruptedException {
		survey.Tab_On_change_assessed_Skill_clear_and_again_enter();
		log.info("Tab_On_change_assessed_Skill_clear_and_again_enter");
	}

	@Test(priority = 57)
	public void display_Status_of_Delete_assessed_Skill_Test() {
		Assert.assertEquals(survey.display_Status_of_Delete_assessed_Skill(), true);
		log.info("display_Status_of_Delete_assessed_Skill : " + survey.display_Status_of_Delete_assessed_Skill());
	}

	@Test(priority = 58)
	public void enable_Status_of_Delete_assessed_Skill_Test() {
		Assert.assertEquals(survey.enable_Status_of_Delete_assessed_Skill(), true);
		log.info("enable_Status_of_Delete_assessed_Skill : " + survey.enable_Status_of_Delete_assessed_Skill());
	}

	@Test(priority = 59)
	public void Tab_on_Delete_assessed_Skill_Test() throws InterruptedException {
		survey.Tab_on_Delete_assessed_Skill();
		log.info("Tab_on_Delete_assessed_Skill");
	}

	@Test(priority = 60)
	public void Tab_on_assessed_Skill_Test2() throws InterruptedException {
		survey.Tab_on_assessed_Skill();
		log.info("Tab_on_assessed_Skill");
	}

	@Test(priority = 61)
	public void display_Status_of_survey_Type_Test() {
		Assert.assertEquals(survey.display_Status_of_survey_Type(), true);
		log.info("display_Status_of_survey_Type : " + survey.display_Status_of_survey_Type());
	}

	@Test(priority = 62)
	public void enable_Status_of_survey_Type_Test() {
		Assert.assertEquals(survey.enable_Status_of_survey_Type(), true);
		log.info("enable_Status_of_survey_Type : " + survey.enable_Status_of_survey_Type());
	}

	@Test(priority = 63)
	public void Tab_on_survey_Type_Test() throws InterruptedException {
		survey.Tab_on_survey_Type();
		log.info("Tab_on_survey_Type");
	}

	@Test(priority = 64)
	public void display_Status_of_Add_survey_Type_Test() {
		Assert.assertEquals(survey.display_Status_of_Add_survey_Type(), true);
		log.info("display_Status_of_Add_survey_Type : " + survey.display_Status_of_Add_survey_Type());
	}

	@Test(priority = 65)
	public void enable_Status_of_Add_survey_Type_Test() {
		Assert.assertEquals(survey.enable_Status_of_Add_survey_Type(), true);
		log.info("enable_Status_of_Add_survey_Type : " + survey.enable_Status_of_Add_survey_Type());
	}

	@Test(priority = 66)
	public void Tab_on_Add_survey_Type_Test() throws InterruptedException {
		survey.Tab_on_Add_survey_Type();
		log.info("Tab_on_Add_survey_Type");
	}

	@Test(priority = 67)
	public void display_Status_of_Enter_survey_Type_Test() throws InterruptedException {
		Assert.assertEquals(survey.display_Status_of_Enter_survey_Type(), true);
		log.info("display_Status_of_Enter_survey_Type : " + survey.display_Status_of_Enter_survey_Type());
	}

	@Test(priority = 68)
	public void enable_Status_of_Enter_survey_Type_Test() {
		Assert.assertEquals(survey.enable_Status_of_Enter_survey_Type(), true);
		log.info("enable_Status_of_Enter_survey_Type : " + survey.enable_Status_of_Enter_survey_Type());
	}

//	@Test(priority = 69)
	public void Enter_survey_Type_Test() throws InterruptedException {
		survey.Enter_survey_Type("");
		log.info("Enter_survey_Type");
	}

	@Test(priority = 70)
	public void display_Status_of_Save_survey_Type_Test() {
		Assert.assertEquals(survey.display_Status_of_Save_survey_Type(), true);
		log.info("display_Status_of_Save_survey_Type : " + survey.display_Status_of_Save_survey_Type());
	}

	@Test(priority = 71)
	public void enable_Status_of_Save_survey_Type_Test() {
		Assert.assertEquals(survey.enable_Status_of_Save_survey_Type(), true);
		log.info("enable_Status_of_Save_survey_Type : " + survey.enable_Status_of_Save_survey_Type());
	}

	@Test(priority = 72)
	public void Tab_on_Save_survey_Type_Test() throws InterruptedException {
		survey.Tab_on_Save_survey_Type();
		log.info("Tab_on_Save_survey_Type");
	}

	@Test(priority = 73)
	public void display_Status_of_Edit_survey_Type_Test() {
		Assert.assertEquals(survey.display_Status_of_Edit_survey_Type(), true);
		log.info("display_Status_of_Edit_survey_Type : " + survey.display_Status_of_Edit_survey_Type());
	}

	@Test(priority = 74)
	public void enable_Status_of_Edit_survey_Type_Test() {
		Assert.assertEquals(survey.enable_Status_of_Edit_survey_Type(), true);
		log.info("enable_Status_of_Edit_survey_Type : " + survey.enable_Status_of_Edit_survey_Type());
	}

	@Test(priority = 75)
	public void Tab_on_Edit_survey_Type_Test() throws InterruptedException {
		survey.Tab_on_Edit_survey_Type();
		log.info("Tab_on_Edit_survey_Type");
	}

	@Test(priority = 76)
	public void display_Status_of_change_survey_Type_Test() {
		Assert.assertEquals(survey.display_Status_of_change_survey_Type(), true);
		log.info("display_Status_of_change_survey_Type : " + survey.display_Status_of_change_survey_Type());
	}

	@Test(priority = 77)
	public void enable_Status_of_change_survey_Type_Test() {
		Assert.assertEquals(survey.enable_Status_of_change_survey_Type(), true);
		log.info("enable_Status_of_change_survey_Type : " + survey.enable_Status_of_change_survey_Type());
	}

	@Test(priority = 78)
	public void Enter_change_survey_Type_Test() throws InterruptedException {
		survey.Enter_change_survey_Type();
		log.info("Enter_change_survey_Type");
	}

	@Test(priority = 79)
	public void display_Status_of_Delete_survey_Type_Test() {
		Assert.assertEquals(survey.display_Status_of_Delete_survey_Type(), true);
		log.info("display_Status_of_Delete_survey_Type : " + survey.display_Status_of_Delete_survey_Type());
	}

	@Test(priority = 80)
	public void enable_Status_of_Delete_survey_Type_Test() {
		Assert.assertEquals(survey.enable_Status_of_Delete_survey_Type(), true);
		log.info("enable_Status_of_Delete_survey_Type : " + survey.enable_Status_of_Delete_survey_Type());
	}

	@Test(priority = 81)
	public void Tab_on_Delete_survey_Type_Test() throws InterruptedException {
		survey.Tab_on_Delete_survey_Type();
		log.info("Tab_on_Delete_survey_Type");
	}

	@Test(priority = 82)
	public void Tab_on_survey_Type_Test2() throws InterruptedException {
		survey.Tab_on_survey_Type();
		log.info("Tab_on_survey_Type");
	}

	@Test(priority = 83)
	public void display_Status_of_Save_Survey_Element_Test() {
		Assert.assertEquals(survey.display_Status_of_Save_Survey_Element(), true);
		log.info("display_Status_of_Save_Survey_Element : " + survey.display_Status_of_Save_Survey_Element());
	}

	@Test(priority = 84)
	public void enable_Status_of_Save_Survey_Element_Test() {
		Assert.assertEquals(survey.enable_Status_of_Save_Survey_Element(), true);
		log.info("enable_Status_of_Save_Survey_Element : " + survey.enable_Status_of_Save_Survey_Element());
	}

	@Test(priority = 85)
	public void Tab_on_Save_Survey_Element_Test() throws InterruptedException {
		survey.Tab_on_Save_Survey_Element();
		log.info("Tab_on_Save_Survey_Element");
	}

	@Test(priority = 86)
	public void display_Status_of_Save_Survey_Template_Test() {
		Assert.assertEquals(survey.display_Status_of_Save_Survey_Template(), true);
		log.info("display_Status_of_Save_Survey_Template : " + survey.display_Status_of_Save_Survey_Template());
	}

	@Test(priority = 87)
	public void enable_Status_of_Save_Survey_Template_Test() {
		Assert.assertEquals(survey.enable_Status_of_Save_Survey_Template(), true);
		log.info("enable_Status_of_Save_Survey_Template : " + survey.enable_Status_of_Save_Survey_Template());
	}

	@Test(priority = 88)
	public void Tab_on_Save_Survey_Template_Test() throws InterruptedException {
		survey.Tab_on_Save_Survey_Template();
		log.info("Tab_on_Save_Survey_Template");
	}

	@Test(priority = 89)
	public void display_Status_of_create_Template_Test() {
		Assert.assertEquals(survey.display_Status_of_create_Template(), true);
		log.info("display_Status_of_create_Template : " + survey.display_Status_of_create_Template());
	}

	@Test(priority = 90)
	public void enable_Status_of_create_Template_Test() throws InterruptedException {
		Assert.assertEquals(survey.enable_Status_of_create_Template(), true);
		log.info("enable_Status_of_create_Template : " + survey.enable_Status_of_create_Template());
	}

	@Test(priority = 91)
	public void Tab_on_create_Template_Test() throws InterruptedException {
		survey.Tab_on_create_Template();
		log.info("Tab_on_create_Template");
	}

	@Test(priority = 92)
	public void display_Status_of_questionary_Select_question_Test() throws InterruptedException {
		Thread.sleep(2000);
		Assert.assertEquals(survey.display_Status_of_questionary_Select_question(), true);
		log.info("display_Status_of_questionary_Select_question : " + survey.display_Status_of_questionary_Select_question());
	}

	@Test(priority = 93)
	public void enable_Status_of_questionary_Select_question_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Select_question(), true);
		log.info("enable_Status_of_questionary_Select_question : " + survey.enable_Status_of_questionary_Select_question());
	}

	@Test(priority = 94)
	public void Tab_on_questionary_Select_question_and_select_question_Test() throws InterruptedException {
		survey.Tab_on_questionary_Select_question_and_select_question();
		log.info("Tab_on_questionary_Select_question_and_select_question");
	}

	@Test(priority = 95)
	public void display_Status_of_questionary_discription_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_discription(), true);
		log.info("display_Status_of_questionary_discription : " + survey.display_Status_of_questionary_discription());
	}

	@Test(priority = 96)
	public void enable_Status_of_questionary_discription_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_discription(), true);
		log.info("enable_Status_of_questionary_discription : " + survey.enable_Status_of_questionary_discription());
	}

	@Test(priority = 97)
	public void Tab_on_questionary_discription_and_enter_data_Test() throws InterruptedException {
		survey.Tab_on_questionary_discription_and_enter_data("Friendly");
		log.info("Tab_on_questionary_discription_and_enter_data");
	}

	@Test(priority = 98)
	public void display_Status_of_questionary_FileName_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_FileName(), true);
		log.info("display_Status_of_questionary_FileName : " + survey.display_Status_of_questionary_FileName());
	}

	@Test(priority = 99)
	public void enable_Status_of_questionary_FileName_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_FileName(), true);
		log.info("enable_Status_of_questionary_FileName : " + survey.enable_Status_of_questionary_FileName());
	}

	@Test(priority = 100)
	public void Tab_on_questionary_FileName_and_enter_FileName_Test() throws InterruptedException {
		survey.Tab_on_questionary_FileName_and_enter_FileName("Sample.wav");
		log.info("Tab_on_questionary_FileName_and_enter_FileName");
	}

	@Test(priority = 101)
	public void display_Status_of_questionary_Min_Score_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Min_Score(), true);
		log.info("display_Status_of_questionary_Min_Score : " + survey.display_Status_of_questionary_Min_Score());
	}

	@Test(priority = 102)
	public void enable_Status_of_questionary_Min_Score_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Min_Score(), true);
		log.info("enable_Status_of_questionary_Min_Score : " + survey.enable_Status_of_questionary_Min_Score());
	}

	@Test(priority = 103)
	public void Tab_on_questionary_Min_Score_and_enter_questionary_Min_Score_Test() throws InterruptedException {
		survey.Tab_on_questionary_Min_Score_and_enter_questionary_Min_Score("1");
		log.info("Tab_on_questionary_Min_Score_and_enter_questionary_Min_Score");
	}

	@Test(priority = 104)
	public void display_Status_of_questionary_Max_Score_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Max_Score(), true);
		log.info("display_Status_of_questionary_Max_Score : " + survey.display_Status_of_questionary_Max_Score());
	}

	@Test(priority = 105)
	public void enable_Status_of_questionary_Max_Score_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Max_Score(), true);
		log.info("enable_Status_of_questionary_Max_Score : " + survey.enable_Status_of_questionary_Max_Score());
	}

	@Test(priority = 106)
	public void Tab_on_questionary_Max_Score_and_enter_questionary_Max_Score_Test() throws InterruptedException {
		survey.Tab_on_questionary_Max_Score_and_enter_questionary_Max_Score("9");
		log.info("Tab_on_questionary_Max_Score_and_enter_questionary_Max_Score");
	}

	@Test(priority = 107)
	public void display_Status_of_questionary_Response_Mapping_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_Mapping(), true);
		log.info("display_Status_of_questionary_Response_Mapping : " + survey.display_Status_of_questionary_Response_Mapping());
	}

	@Test(priority = 108)
	public void enable_Status_of_questionary_Response_Mapping_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_Mapping(), true);
		log.info("enable_Status_of_questionary_Response_Mapping : " + survey.enable_Status_of_questionary_Response_Mapping());
	}

	@Test(priority = 109)
	public void Tab_on_questionary_Response_Mapping_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_Mapping();
		log.info("Tab_on_questionary_Response_Mapping");
	}

	@Test(priority = 110)
	public void display_Status_of_questionary_Response_1_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_1(), true);
		log.info("display_Status_of_questionary_Response_1 : " + survey.display_Status_of_questionary_Response_1());
	}

	@Test(priority = 111)
	public void enable_Status_of_questionary_Response_1_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_1(), true);
		log.info("enable_Status_of_questionary_Response_1 : " + survey.enable_Status_of_questionary_Response_1());
	}

	@Test(priority = 112)
	public void Tab_on_questionary_Response_1_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_1_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_1_And_Select_Reponse_Value");
	}

	@Test(priority = 113)
	public void display_Status_of_questionary_Response_2_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_2(), true);
		log.info("display_Status_of_questionary_Response_2 : " + survey.display_Status_of_questionary_Response_2());
	}

	@Test(priority = 114)
	public void enable_Status_of_questionary_Response_2_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_2(), true);
		log.info("enable_Status_of_questionary_Response_2 : " + survey.enable_Status_of_questionary_Response_2());
	}

	@Test(priority = 115)
	public void Tab_on_questionary_Response_2_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_2_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_2_And_Select_Reponse_Value");
	}

	@Test(priority = 116)
	public void display_Status_of_questionary_Response_3_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_3(), true);
		log.info("display_Status_of_questionary_Response_3 : " + survey.display_Status_of_questionary_Response_3());
	}

	@Test(priority = 117)
	public void enable_Status_of_questionary_Response_3_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_3(), true);
		log.info("enable_Status_of_questionary_Response_3 : " + survey.enable_Status_of_questionary_Response_3());
	}

	@Test(priority = 118)
	public void Tab_on_questionary_Response_3_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_3_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_3_And_Select_Reponse_Value");
	}

	@Test(priority = 119)
	public void display_Status_of_questionary_Response_4_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_4(), true);
		log.info("display_Status_of_questionary_Response_4 : " + survey.display_Status_of_questionary_Response_4());
	}

	@Test(priority = 120)
	public void enable_Status_of_questionary_Response_4_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_4(), true);
		log.info("enable_Status_of_questionary_Response_4 : " + survey.enable_Status_of_questionary_Response_4());
	}

	@Test(priority = 121)
	public void Tab_on_questionary_Response_4_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_4_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_4_And_Select_Reponse_Value");
	}

	@Test(priority = 122)
	public void display_Status_of_questionary_Response_5_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_5(), true);
		log.info("display_Status_of_questionary_Response_5 : " + survey.display_Status_of_questionary_Response_5());
	}

	@Test(priority = 123)
	public void enable_Status_of_questionary_Response_5_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_5(), true);
		log.info("enable_Status_of_questionary_Response_5 : " + survey.enable_Status_of_questionary_Response_5());
	}

	@Test(priority = 124)
	public void Tab_on_questionary_Response_5_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_5_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_5_And_Select_Reponse_Value");
	}

	@Test(priority = 125)
	public void display_Status_of_questionary_Response_6_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_6(), true);
		log.info("display_Status_of_questionary_Response_6 : " + survey.display_Status_of_questionary_Response_6());
	}

	@Test(priority = 126)
	public void enable_Status_of_questionary_Response_6_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_6(), true);
		log.info("enable_Status_of_questionary_Response_6 : " + survey.enable_Status_of_questionary_Response_6());
	}

	@Test(priority = 127)
	public void Tab_on_questionary_Response_6_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_6_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_6_And_Select_Reponse_Value");
	}

	@Test(priority = 128)
	public void display_Status_of_questionary_Response_7_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_7(), true);
		log.info("display_Status_of_questionary_Response_7 : " + survey.display_Status_of_questionary_Response_7());
	}

	@Test(priority = 129)
	public void enable_Status_of_questionary_Response_7_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_7(), true);
		log.info("enable_Status_of_questionary_Response_7 : " + survey.enable_Status_of_questionary_Response_7());
	}

	@Test(priority = 130)
	public void Tab_on_questionary_Response_7_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_7_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_7_And_Select_Reponse_Value");
	}

	@Test(priority = 131)
	public void display_Status_of_questionary_Response_8_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_8(), true);
		log.info("display_Status_of_questionary_Response_8 : " + survey.display_Status_of_questionary_Response_8());
	}

	@Test(priority = 132)
	public void enable_Status_of_questionary_Response_8_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_8(), true);
		log.info("enable_Status_of_questionary_Response_8 : " + survey.enable_Status_of_questionary_Response_8());
	}

	@Test(priority = 133)
	public void Tab_on_questionary_Response_8_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_8_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_8_And_Select_Reponse_Value");
	}

	@Test(priority = 134)
	public void display_Status_of_questionary_Response_9_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_9(), true);
		log.info("display_Status_of_questionary_Response_9 : " + survey.display_Status_of_questionary_Response_9());
	}

	@Test(priority = 135)
	public void enable_Status_of_questionary_Response_9_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_9(), true);
		log.info("enable_Status_of_questionary_Response_9 : " + survey.enable_Status_of_questionary_Response_9());
	}

	@Test(priority = 136)
	public void Tab_on_questionary_Response_9_And_Select_Reponse_Value_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_9_And_Select_Reponse_Value();
		log.info("Tab_on_questionary_Response_9_And_Select_Reponse_Value");
	}

	@Test(priority = 137)
	public void display_Status_of_Back_Test() {
		Assert.assertEquals(survey.display_Status_of_Back(), true);
		log.info("display_Status_of_Back : " + survey.display_Status_of_Back());
	}

	@Test(priority = 138)
	public void enable_Status_of_Back_Test() {
		Assert.assertEquals(survey.enable_Status_of_Back(), true);
		log.info("enable_Status_of_Back : " + survey.enable_Status_of_Back());
	}

//	@Test(priority = 139)
//	public void Tab_on_Back_Test() throws InterruptedException {
//		survey.Tab_on_Back();
//	log.info("Tab_on_Back");
//	}
	@Test(priority = 140)
	public void display_Status_of_Save_Test() {
		Assert.assertEquals(survey.display_Status_of_Save(), true);
		log.info("display_Status_of_Save : " + survey.display_Status_of_Save());
	}

	@Test(priority = 141)
	public void enable_Status_of_Save_Test() {
		Assert.assertEquals(survey.enable_Status_of_Save(), true);
		log.info("enable_Status_of_Save : " + survey.enable_Status_of_Save());
	}

//	@Test(priority = 142)
	public void Tab_on_Save_Test() throws InterruptedException {
		survey.Tab_on_Save();
		log.info("Tab_on_Save");
	}

	@Test(priority = 142)
	public void Tab_on_Back_Test() throws InterruptedException {
		survey.Tab_on_Back();
		log.info("Tab_on_Back");
	}

	@Test(priority = 143)
	public void display_Status_of_General_Configuration_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration(), true);
		log.info("display_Status_of_General_Configuration : " + survey.display_Status_of_General_Configuration());
	}

	@Test(priority = 144)
	public void enable_Status_of_General_Configuration_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration(), true);
		log.info("enable_Status_of_General_Configuration : " + survey.enable_Status_of_General_Configuration());
	}

	@Test(priority = 145)
	public void Tab_on_General_Configuration_Test() throws InterruptedException {
		survey.Tab_on_General_Configuration();
		log.info("Tab_on_General_Configuration");
	}

	@Test(priority = 146)
	public void display_Status_of_General_Configuration_Number_of_Tries_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Number_of_Tries(), true);
		log.info("display_Status_of_General_Configuration_Number_of_Tries : " + survey.display_Status_of_General_Configuration_Number_of_Tries());
	}

	@Test(priority = 147)
	public void enable_Status_of_General_Configuration_Number_of_Tries_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Number_of_Tries(), true);
		log.info("enable_Status_of_General_Configuration_Number_of_Tries : " + survey.enable_Status_of_General_Configuration_Number_of_Tries());
	}

	@Test(priority = 148)
	public void Enter_data_in_General_Configuration_Number_of_Tries_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_Number_of_Tries();
		log.info("Enter_data_in_General_Configuration_Number_of_Tries");
	}

	@Test(priority = 149)
	public void display_Status_of_General_Configuration_Max_Time_out_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Max_Time_out(), true);
		log.info("display_Status_of_General_Configuration_Max_Time_out : " + survey.display_Status_of_General_Configuration_Max_Time_out());
	}

	@Test(priority = 150)
	public void enable_Status_of_General_Configuration_Max_Time_out_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Max_Time_out(), true);
		log.info("enable_Status_of_General_Configuration_Max_Time_out : " + survey.enable_Status_of_General_Configuration_Max_Time_out());
	}

	@Test(priority = 151)
	public void Enter_data_in_General_Configuration_Max_Time_out_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_Max_Time_out();
		log.info("Enter_data_in_General_Configuration_Max_Time_out");
	}

	@Test(priority = 152)
	public void display_Status_of_General_Configuration_Prompt_Path_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Prompt_Path(), true);
		log.info("display_Status_of_General_Configuration_Prompt_Path : " + survey.display_Status_of_General_Configuration_Prompt_Path());
	}

	@Test(priority = 153)
	public void enable_Status_of_General_Configuration_Prompt_Path_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Prompt_Path(), true);
		log.info("enable_Status_of_General_Configuration_Prompt_Path : " + survey.enable_Status_of_General_Configuration_Prompt_Path());
	}

	@Test(priority = 154)
	public void Enter_data_in_General_Configuration_Prompt_Path_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_Prompt_Path();
		log.info("Enter_data_in_General_Configuration_Prompt_Path");
	}

	@Test(priority = 155)
	public void display_Status_of_General_Configuration_Prompt_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Prompt_File_Name(), true);
		log.info("display_Status_of_General_Configuration_Prompt_File_Name : " + survey.display_Status_of_General_Configuration_Prompt_File_Name());
	}

	@Test(priority = 156)
	public void enable_Status_of_General_Configuration_Prompt_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Prompt_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_Prompt_File_Name : " + survey.enable_Status_of_General_Configuration_Prompt_File_Name());
	}

	@Test(priority = 157)
	public void Enter_data_in_General_Configuration_Prompt_File_Name_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_Prompt_File_Name();
		log.info("Enter_data_in_General_Configuration_Prompt_File_Name");
	}

	@Test(priority = 158)
	public void display_Status_of_General_Configuration_SurveyDiscription_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_SurveyDiscription_File_Name(), true);
		log.info("display_Status_of_General_Configuration_SurveyDiscription_File_Name : " + survey.display_Status_of_General_Configuration_SurveyDiscription_File_Name());
	}

	@Test(priority = 159)
	public void enable_Status_of_General_Configuration_SurveyDiscription_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_SurveyDiscription_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_SurveyDiscription_File_Name : " + survey.enable_Status_of_General_Configuration_SurveyDiscription_File_Name());
	}

	@Test(priority = 160)
	public void Enter_data_in_General_Configuration_SurveyDiscription_File_Name_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_SurveyDiscription_File_Name();
		log.info("Enter_data_in_General_Configuration_SurveyDiscription_File_Name");
	}

	@Test(priority = 161)
	public void display_Status_of_General_Configuration_Wlcm_msg_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Wlcm_msg_File_Name(), true);
		log.info("display_Status_of_General_Configuration_Wlcm_msg_File_Name : " + survey.display_Status_of_General_Configuration_Wlcm_msg_File_Name());
	}

	@Test(priority = 162)
	public void enable_Status_of_General_Configuration_Wlcm_msg_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Wlcm_msg_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_Wlcm_msg_File_Name : " + survey.enable_Status_of_General_Configuration_Wlcm_msg_File_Name());
	}

	@Test(priority = 163)
	public void Enter_data_in_General_Configuration_Wlcm_msg_File_Name_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_Wlcm_msg_File_Name();
		log.info("Enter_data_in_General_Configuration_Wlcm_msg_File_Name");
	}

	@Test(priority = 164)
	public void display_Status_of_General_Configuration_thankYou_msg_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_thankYou_msg_File_Name(), true);
		log.info("display_Status_of_General_Configuration_thankYou_msg_File_Name : " + survey.display_Status_of_General_Configuration_thankYou_msg_File_Name());
	}

	@Test(priority = 165)
	public void enable_Status_of_General_Configuration_thankYou_msg_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_thankYou_msg_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_thankYou_msg_File_Name : " + survey.enable_Status_of_General_Configuration_thankYou_msg_File_Name());
	}

	@Test(priority = 166)
	public void Enter_data_in_General_Configuration_thankYou_msg_File_Name_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_thankYou_msg_File_Name();
		log.info("Enter_data_in_General_Configuration_thankYou_msg_File_Name");
	}

	@Test(priority = 167)
	public void display_Status_of_General_Configuration_No_Input_msg_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_No_Input_msg_File_Name(), true);
		log.info("display_Status_of_General_Configuration_No_Input_msg_File_Name : " + survey.display_Status_of_General_Configuration_No_Input_msg_File_Name());
	}

	@Test(priority = 168)
	public void enable_Status_of_General_Configuration_No_Input_msg_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_No_Input_msg_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_No_Input_msg_File_Name : " + survey.enable_Status_of_General_Configuration_No_Input_msg_File_Name());
	}

	@Test(priority = 169)
	public void Enter_data_in_General_Configuration_No_Input_msg_File_Name_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_No_Input_msg_File_Name();
		log.info("Enter_data_in_General_Configuration_No_Input_msg_File_Name");
	}

	@Test(priority = 170)
	public void display_Status_of_General_Configuration_No_match_msg_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_No_match_msg_File_Name(), true);
		log.info("display_Status_of_General_Configuration_No_match_msg_File_Name : " + survey.display_Status_of_General_Configuration_No_match_msg_File_Name());
	}

	@Test(priority = 171)
	public void enable_Status_of_General_Configuration_No_match_msg_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_No_match_msg_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_No_match_msg_File_Name : " + survey.enable_Status_of_General_Configuration_No_match_msg_File_Name());
	}

	@Test(priority = 172)
	public void Enter_data_in_General_Configuration_No_match_msg_File_Name_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_No_match_msg_File_Name();
		log.info("Enter_data_in_General_Configuration_No_match_msg_File_Name");
	}

	@Test(priority = 173)
	public void display_Status_of_General_Configuration_Max_error_prompt_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Max_error_prompt(), true);
		log.info("display_Status_of_General_Configuration_Max_error_prompt : " + survey.display_Status_of_General_Configuration_Max_error_prompt());
	}

	@Test(priority = 174)
	public void enable_Status_of_General_Configuration_Max_error_prompt_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Max_error_prompt(), true);
		log.info("enable_Status_of_General_Configuration_Max_error_prompt : " + survey.enable_Status_of_General_Configuration_Max_error_prompt());
	}

	@Test(priority = 175)
	public void Enter_data_in_General_Configuration_Max_error_prompt_Test() throws InterruptedException {
		survey.Enter_data_in_General_Configuration_Max_error_prompt();
		log.info("Enter_data_in_General_Configuration_Max_error_prompt");
	}
	@Test(priority = 176)
	public void display_Status_of_close_Test() {
		Assert.assertEquals(survey.display_Status_of_close(), true);
		log.info("display_Status_of_close : " + survey.display_Status_of_close());
	}
	@Test(priority = 177)
	public void enable_Status_of_close_Test() {
		Assert.assertEquals(survey.enable_Status_of_close(), true);
		log.info("enable_Status_of_close : " + survey.enable_Status_of_close());
	}
//	@Test(priority = 178)
//	public void Tab_on_close_Tets() throws InterruptedException {
//		survey.Tab_on_close();
//		lof.info("Tab_on_close");
//	}
	@Test(priority = 179)
	public void display_Status_of_save_Test() {
		Assert.assertEquals(survey.display_Status_of_save(), true);
		log.info("display_Status_of_save : " + survey.display_Status_of_save());
	}
	@Test(priority = 180)
	public void enable_Status_of_save_Test() {
		Assert.assertEquals(survey.enable_Status_of_save(), true);
		log.info("enable_Status_of_save : " + survey.enable_Status_of_save());
	}
//	@Test(priority = 181)
//	public void Tab_on_save_Test() throws InterruptedException {
//		survey.Tab_on_save();
//		log.info("Tab_on_save");
//	}
	@Test(priority = 181)
	public void Tab_on_close_Tets() throws InterruptedException {
		survey.Tab_on_close();
}
	@Test(priority = 182)
	public void display_Status_of_edit_Test() {
		Assert.assertEquals(survey.display_Status_of_edit(), true);
		log.info("display_Status_of_edit : " + survey.display_Status_of_edit());
	}
	@Test(priority = 183)
	public void enable_Status_of_edit_Test() {
		Assert.assertEquals(survey.enable_Status_of_edit(), true);
		log.info("enable_Status_of_edit : " + survey.enable_Status_of_edit());
	}

	@Test(priority = 184)
	public void Tab_on_edit_Test() throws InterruptedException {
		survey.Tab_on_edit();
		log.info("Tab_on_edit");
	}
	
	@Test(priority = 185)
	public void display_Status_of_Edit_questionary_Select_question_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Select_question(), true);
		log.info("display_Status_of_questionary_Select_question : " + survey.display_Status_of_questionary_Select_question());
	}

	@Test(priority = 186)
	public void enable_Status_of_Edit_questionary_Select_question_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Select_question(), true);
		log.info("enable_Status_of_questionary_Select_question : " + survey.enable_Status_of_questionary_Select_question());
	}

	@Test(priority = 187)
	public void display_Status_of_Edit_questionary_discription_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_discription(), true);
		log.info("display_Status_of_questionary_discription : " + survey.display_Status_of_questionary_discription());
	}

	@Test(priority = 188)
	public void enable_Status_of_Edit_questionary_discription_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_discription(), true);
		log.info("enable_Status_of_questionary_discription : " + survey.enable_Status_of_questionary_discription());
	}

	@Test(priority = 189)
	public void display_Status_of_Edit_questionary_FileName_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_FileName(), true);
		log.info("display_Status_of_questionary_FileName : " + survey.display_Status_of_questionary_FileName());
	}

	@Test(priority = 190)
	public void enable_Status_of_Edit_questionary_FileName_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_FileName(), true);
		log.info("enable_Status_of_questionary_FileName : " + survey.enable_Status_of_questionary_FileName());
	}

	@Test(priority = 191)
	public void display_Status_of_Edit_questionary_Min_Score_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Min_Score(), true);
		log.info("display_Status_of_questionary_Min_Score : " + survey.display_Status_of_questionary_Min_Score());
	}

	@Test(priority = 192)
	public void enable_Status_of_Edit_questionary_Min_Score_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Min_Score(), true);
		log.info("enable_Status_of_questionary_Min_Score : " + survey.enable_Status_of_questionary_Min_Score());
	}

	@Test(priority = 193)
	public void display_Status_of_Edit_questionary_Max_Score_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Max_Score(), true);
		log.info("display_Status_of_questionary_Max_Score : " + survey.display_Status_of_questionary_Max_Score());
	}

	@Test(priority = 194)
	public void enable_Status_of_Edit_questionary_Max_Score_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Max_Score(), true);
		log.info("enable_Status_of_questionary_Max_Score : " + survey.enable_Status_of_questionary_Max_Score());
	}

	@Test(priority = 195)
	public void display_Status_of_Edit_questionary_Response_Mapping_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_Mapping(), true);
		log.info("display_Status_of_questionary_Response_Mapping : " + survey.display_Status_of_questionary_Response_Mapping());
	}

	@Test(priority = 196)
	public void enable_Status_of_Edit_questionary_Response_Mapping_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_Mapping(), true);
		log.info("enable_Status_of_questionary_Response_Mapping : " + survey.enable_Status_of_questionary_Response_Mapping());
	}

	@Test(priority = 197)
	public void Tab_on_Edit_questionary_Response_Mapping_Test() throws InterruptedException {
		survey.Tab_on_questionary_Response_Mapping();
		log.info("Tab_on_questionary_Response_Mapping");
	}

	@Test(priority = 198)
	public void display_Status_of_Edit_questionary_Response_1_Test() throws InterruptedException {
		Thread.sleep(3000);
		Assert.assertEquals(survey.display_Status_of_questionary_Response_1(), true);
		log.info("display_Status_of_questionary_Response_1 : " + survey.display_Status_of_questionary_Response_1());
	}

	@Test(priority = 199)
	public void enable_Status_of_Edit_questionary_Response_1_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_1(), true);
		log.info("enable_Status_of_questionary_Response_1 : " + survey.enable_Status_of_questionary_Response_1());
	}

	@Test(priority = 200)
	public void display_Status_of_Edit_questionary_Response_2_Test() {
		Assert.assertEquals(survey.display_Status_of_questionary_Response_2(), true);
		log.info("display_Status_of_questionary_Response_2 : " + survey.display_Status_of_questionary_Response_2());
	}

	@Test(priority = 201)
	public void enable_Status_of_Edit_questionary_Response_2_Test() {
		Assert.assertEquals(survey.enable_Status_of_questionary_Response_2(), true);
		log.info("enable_Status_of_questionary_Response_2 : " + survey.enable_Status_of_questionary_Response_2());
	}

		@Test(priority = 202)
	public void display_Status_of_Edit_Back_Test() {
		Assert.assertEquals(survey.display_Status_of_Back(), true);
		log.info("display_Status_of_Back : " + survey.display_Status_of_Back());
	}

	@Test(priority = 203)
	public void enable_Status_of_Edit_Back_Test() {
		Assert.assertEquals(survey.enable_Status_of_Back(), true);
		log.info("enable_Status_of_Back : " + survey.enable_Status_of_Back());
	}

//	@Test(priority = 204)
//	public void Tab_on_Edit_Back_Test() throws InterruptedException {
//		survey.Tab_on_Back();
//		log.info("Tab_on_Back");
//	}
	@Test(priority = 205)
	public void display_Status_of_Edit_Save_Test() {
		Assert.assertEquals(survey.display_Status_of_Save(), true);
		log.info("display_Status_of_Save : " + survey.display_Status_of_Save());
	}

	@Test(priority = 206)
	public void enable_Status_of_Edit_Save_Test() {
		Assert.assertEquals(survey.enable_Status_of_Save(), true);
		log.info("enable_Status_of_Save : " + survey.enable_Status_of_Save());
	}

//	@Test(priority = 207)
	public void Tab_on_Edit_Save_Test() throws InterruptedException {
		survey.Tab_on_Save();
		log.info("Tab_on_Save");
	}

	@Test(priority = 207)
	public void Tab_on_Edit_Back_Test() throws InterruptedException {
		survey.Tab_on_Back();
		log.info("Tab_on_Back");
	}

	@Test(priority = 208)
	public void display_Status_of_Edit_General_Configuration_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration(), true);
		log.info("display_Status_of_General_Configuration : " + survey.display_Status_of_General_Configuration());
	}

	@Test(priority = 209)
	public void enable_Status_of_Edit_General_Configuration_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration(), true);
		log.info("enable_Status_of_General_Configuration : " + survey.enable_Status_of_General_Configuration());
	}

	@Test(priority = 210)
	public void Tab_on_General_Edit_Configuration_Test() throws InterruptedException {
		survey.Tab_on_General_Configuration();
		log.info("Tab_on_General_Configuration");
	}

	@Test(priority = 211)
	public void display_Status_of_Edit_General_Configuration_Number_of_Tries_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Number_of_Tries(), true);
		log.info("display_Status_of_General_Configuration_Number_of_Tries : " + survey.display_Status_of_General_Configuration_Number_of_Tries());
	}

	@Test(priority = 212)
	public void enable_Status_of_Edit_General_Configuration_Number_of_Tries_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Number_of_Tries(), true);
		log.info("enable_Status_of_General_Configuration_Number_of_Tries : " + survey.enable_Status_of_General_Configuration_Number_of_Tries());
	}

	@Test(priority = 213)
	public void display_Status_of_Edit_General_Configuration_Max_Time_out_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Max_Time_out(), true);
		log.info("display_Status_of_General_Configuration_Max_Time_out : " + survey.display_Status_of_General_Configuration_Max_Time_out());
	}

	@Test(priority = 214)
	public void enable_Status_of_Edit_General_Configuration_Max_Time_out_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Max_Time_out(), true);
		log.info("enable_Status_of_General_Configuration_Max_Time_out : " + survey.enable_Status_of_General_Configuration_Max_Time_out());
	}

	@Test(priority = 215)
	public void display_Status_of_Edit_General_Configuration_Prompt_Path_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Prompt_Path(), true);
		log.info("display_Status_of_General_Configuration_Prompt_Path : " + survey.display_Status_of_General_Configuration_Prompt_Path());
	}

	@Test(priority = 216)
	public void enable_Status_of_Edit_General_Configuration_Prompt_Path_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Prompt_Path(), true);
		log.info("enable_Status_of_General_Configuration_Prompt_Path : " + survey.enable_Status_of_General_Configuration_Prompt_Path());
	}

	@Test(priority = 217)
	public void display_Status_of_Edit_General_Configuration_Prompt_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Prompt_File_Name(), true);
		log.info("display_Status_of_General_Configuration_Prompt_File_Name : " + survey.display_Status_of_General_Configuration_Prompt_File_Name());
	}

	@Test(priority = 218)
	public void enable_Status_of_Edit_General_Configuration_Prompt_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Prompt_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_Prompt_File_Name : " + survey.enable_Status_of_General_Configuration_Prompt_File_Name());
	}

	@Test(priority = 219)
	public void display_Status_of_Edit_General_Configuration_SurveyDiscription_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_SurveyDiscription_File_Name(), true);
		log.info("display_Status_of_General_Configuration_SurveyDiscription_File_Name : " + survey.display_Status_of_General_Configuration_SurveyDiscription_File_Name());
	}

	@Test(priority = 220)
	public void enable_Status_of_Edit_General_Configuration_SurveyDiscription_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_SurveyDiscription_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_SurveyDiscription_File_Name : " + survey.enable_Status_of_General_Configuration_SurveyDiscription_File_Name());
	}

	@Test(priority = 221)
	public void display_Status_of_Edit_General_Configuration_Wlcm_msg_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Wlcm_msg_File_Name(), true);
		log.info("display_Status_of_General_Configuration_Wlcm_msg_File_Name : " + survey.display_Status_of_General_Configuration_Wlcm_msg_File_Name());
	}

	@Test(priority = 222)
	public void enable_Status_of_Edit_General_Configuration_Wlcm_msg_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Wlcm_msg_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_Wlcm_msg_File_Name : " + survey.enable_Status_of_General_Configuration_Wlcm_msg_File_Name());
	}

	@Test(priority = 223)
	public void display_Status_of_Edit_General_Configuration_thankYou_msg_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_thankYou_msg_File_Name(), true);
		log.info("display_Status_of_General_Configuration_thankYou_msg_File_Name : " + survey.display_Status_of_General_Configuration_thankYou_msg_File_Name());
	}

	@Test(priority = 224)
	public void enable_Status_of_Edit_General_Configuration_thankYou_msg_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_thankYou_msg_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_thankYou_msg_File_Name : " + survey.enable_Status_of_General_Configuration_thankYou_msg_File_Name());
	}

	@Test(priority = 225)
	public void display_Status_of_Edit_General_Configuration_No_Input_msg_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_No_Input_msg_File_Name(), true);
		log.info("display_Status_of_General_Configuration_No_Input_msg_File_Name : " + survey.display_Status_of_General_Configuration_No_Input_msg_File_Name());
	}

	@Test(priority = 226)
	public void enable_Status_of_Edit_General_Configuration_No_Input_msg_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_No_Input_msg_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_No_Input_msg_File_Name : " + survey.enable_Status_of_General_Configuration_No_Input_msg_File_Name());
	}

	@Test(priority = 227)
	public void display_Status_of_Edit_General_Configuration_No_match_msg_File_Name_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_No_match_msg_File_Name(), true);
		log.info("display_Status_of_General_Configuration_No_match_msg_File_Name : " + survey.display_Status_of_General_Configuration_No_match_msg_File_Name());
	}

	@Test(priority = 228)
	public void enable_Status_of_Edit_General_Configuration_No_match_msg_File_Name_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_No_match_msg_File_Name(), true);
		log.info("enable_Status_of_General_Configuration_No_match_msg_File_Name : " + survey.enable_Status_of_General_Configuration_No_match_msg_File_Name());
	}

	@Test(priority = 229)
	public void display_Status_of_Edit_General_Configuration_Max_error_prompt_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration_Max_error_prompt(), true);
		log.info("display_Status_of_General_Configuration_Max_error_prompt : " + survey.display_Status_of_General_Configuration_Max_error_prompt());
	}

	@Test(priority = 230)
	public void enable_Status_of_Edit_General_Configuration_Max_error_prompt_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration_Max_error_prompt(), true);
		log.info("enable_Status_of_General_Configuration_Max_error_prompt : " + survey.enable_Status_of_General_Configuration_Max_error_prompt());
	}
	@Test(priority = 231)
	public void display_Status_of_Edit_close_Test() {
		Assert.assertEquals(survey.display_Status_of_close(), true);
		log.info("display_Status_of_close : " + survey.display_Status_of_close());
	}
	
	@Test(priority = 232)
	public void enable_Status_of_Edit_close_Test() {
		Assert.assertEquals(survey.enable_Status_of_close(), true);
		log.info("enable_Status_of_close : " + survey.enable_Status_of_close());
	}
	@Test(priority = 233)
	public void Tab_on_Edit_close_Test() throws InterruptedException {
		survey.Tab_on_close();
		log.info("Tab_on_close");
	}
	@Test(priority = 234)
	public void display_Status_of_view_Test() {
		Assert.assertEquals(survey.display_Status_of_view(), true);
		log.info("display_Status_of_view : " + survey.display_Status_of_view());
	}
	
	@Test(priority = 235)
	public void enable_Status_of_view_Test() {
		Assert.assertEquals(survey.enable_Status_of_view(), true);
		log.info("enable_Status_of_view : " + survey.enable_Status_of_view());
	}
	@Test(priority = 236)
	public void Tab_on_view() throws InterruptedException {
		survey.Tab_on_view();
		log.info("Tab_on_view");
	}
	@Test(priority = 237)
	public void display_Status_of_View_General_Configuration_Test() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration(), true);
		log.info("display_Status_of_General_Configuration : " + survey.display_Status_of_General_Configuration());
	}
	
	@Test(priority = 238)
	public void enable_Status_of_View_General_Configuration_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration(), true);
		log.info("enable_Status_of_General_Configuration : " + survey.enable_Status_of_General_Configuration());
	}
	@Test(priority = 239)
	public void Tab_on_View_General_Configuration_Test() throws InterruptedException {
		survey.Tab_on_General_Configuration();
		log.info("Tab_on_General_Configuration");
	}
	@Test(priority = 240)
	public void display_Status_of_close_view_Test() {
		Assert.assertEquals(survey.display_Status_of_close_view(), true);
		log.info("display_Status_of_close_view : " + survey.display_Status_of_close_view());
	}
	
	@Test(priority = 241)
	public void enable_Status_of_close_view_Test() {
		Assert.assertEquals(survey.enable_Status_of_close_view(), true);
		log.info("enable_Status_of_close_view : " + survey.enable_Status_of_close_view());
	}
	@Test(priority = 242)
	public void Tab_on_close_view_Test() throws InterruptedException {
		survey.Tab_on_close_view();
		log.info("Tab_on_close_view");
	}
	@Test(priority = 243)
	public void display_Status_of_Next_Test() {
		Assert.assertEquals(survey.display_Status_of_Next(), true);
		log.info("display_Status_of_Next : " + survey.display_Status_of_Next());
	}
	
	@Test(priority = 244)
	public void enable_Status_of_Next_Test() {
		Assert.assertEquals(survey.enable_Status_of_Next(), true);
		log.info("enable_Status_of_Next : " + survey.enable_Status_of_Next());
	}
	@Test(priority = 245)
	public void Tab_on_Next_Test() throws InterruptedException {
		survey.Tab_on_Next();
		log.info("Tab_on_Next");
	}
	@Test(priority = 246)
	public void display_Status_of_previous_Test() {
		Assert.assertEquals(survey.display_Status_of_previous(), true);
		log.info("display_Status_of_previous : " + survey.display_Status_of_previous());
	}
	
	@Test(priority = 247)
	public void enable_Status_of_previous_Test() {
		Assert.assertEquals(survey.enable_Status_of_previous(), true);
		log.info("enable_Status_of_previous : " + survey.enable_Status_of_previous());
	}
	@Test(priority = 248)
	public void Tab_on_previous_Test() throws InterruptedException {
		survey.Tab_on_previous();
		log.info("Tab_on_previous");
	}
	@Test(priority = 249)
	public void display_Status_of_Survey_Form_Mapping_Test() {
		Assert.assertEquals(survey.display_Status_of_Survey_Form_Mapping(), true);
		log.info("display_Status_of_Survey_Form_Mapping : " + survey.display_Status_of_Survey_Form_Mapping());
	}
	
	@Test(priority = 250)
	public void enable_Status_of_Survey_Form_Mapping_Test() {
		Assert.assertEquals(survey.enable_Status_of_Survey_Form_Mapping(), true);
		log.info("enable_Status_of_Survey_Form_Mapping : " + survey.enable_Status_of_Survey_Form_Mapping());
	}
	@Test(priority = 251)
	public void Tab_on_Survey_Form_Mapping_Test() throws InterruptedException {
		survey.Tab_on_Survey_Form_Mapping();
		log.info("Tab_on_Survey_Form_Mapping");
	}
	@Test(priority = 252)
	public void display_Status_of_select_survey_Test() {
		Assert.assertEquals(survey.display_Status_of_select_survey(), true);
		log.info("display_Status_of_select_survey : " + survey.display_Status_of_select_survey());
	}
	
	@Test(priority = 253)
	public void enable_Status_of_select_survey_Test() {
		Assert.assertEquals(survey.enable_Status_of_select_survey(), true);
		log.info("enable_Status_of_select_survey : " + survey.enable_Status_of_select_survey());
	}
	@Test(priority = 254)
	public void Tab_on_select_survey_Test() throws InterruptedException {
		survey.Tab_on_select_survey();
		log.info("Tab_on_select_survey");
	}
	@Test(priority = 255)
	public void display_Status_of_General_survey_Test() {
		Assert.assertEquals(survey.display_Status_of_General_survey(), true);
		log.info("display_Status_of_General_survey : " + survey.display_Status_of_General_survey());
	}
	
	@Test(priority = 256)
	public void enable_Status_of_General_survey_Test() {
		Assert.assertEquals(survey.enable_Status_of_General_survey(), true);
		log.info("enable_Status_of_General_survey : " + survey.enable_Status_of_General_survey());
	}
	@Test(priority = 257)
	public void Tab_on_General_survey_Test() throws InterruptedException {
		survey.Tab_on_General_survey();
		log.info("Tab_on_General_survey");
	}
	@Test(priority = 258)
	public void display_Status_of_survey_template_name_Test() {
		Assert.assertEquals(survey.display_Status_of_survey_template_name(), true);
		log.info("display_Status_of_survey_template_name : " + survey.display_Status_of_survey_template_name());
	}
	
	@Test(priority = 259)
	public void enable_Status_of_survey_template_name_Test() {
		Assert.assertEquals(survey.enable_Status_of_survey_template_name(), true);
		log.info("enable_Status_of_survey_template_name : " + survey.enable_Status_of_survey_template_name());
	}
	@Test(priority = 260)
	public void Tab_on_survey_template_name_Test() throws InterruptedException {
		survey.Tab_on_survey_template_name();
		log.info("Tab_on_survey_template_name");
	}
	@Test(priority = 261)
	public void display_Status_of_loan_agency_survey_Test() {
		Assert.assertEquals(survey.display_Status_of_loan_agency_survey(), true);
		log.info("display_Status_of_loan_agency_survey : " + survey.display_Status_of_loan_agency_survey());
	}
	
	@Test(priority = 262)
	public void enable_Status_of_loan_agency_survey_Test() {
		Assert.assertEquals(survey.enable_Status_of_loan_agency_survey(), true);
		log.info("enable_Status_of_loan_agency_survey : " + survey.enable_Status_of_loan_agency_survey());
	}
	@Test(priority = 263)
	public void Tab_on_loan_agency_survey_Test() throws InterruptedException {
		survey.Tab_on_loan_agency_survey();
		log.info("Tab_on_loan_agency_survey");
	}
	@Test(priority = 264)
	public void display_Status_of_Survey_Form_Mapping_Update_Test() {
		Assert.assertEquals(survey.display_Status_of_Survey_Form_Mapping_Update(), true);
		log.info("display_Status_of_Survey_Form_Mapping_Update : " + survey.display_Status_of_Survey_Form_Mapping_Update());
	}
	
	@Test(priority = 265)
	public void enable_Status_of_Survey_Form_Mapping_Update_Test() {
		Assert.assertEquals(survey.enable_Status_of_Survey_Form_Mapping_Update(), true);
		log.info("enable_Status_of_Survey_Form_Mapping_Update : " + survey.enable_Status_of_Survey_Form_Mapping_Update());
	}
//	@Test(priority = 266)
	public void Tab_on_Survey_Form_Mapping_Update_Test() throws InterruptedException {
		survey.Tab_on_Survey_Form_Mapping_Update();
		log.info("Tab_on_Survey_Form_Mapping_Update");
	}
	@Test(priority = 267)
	public void display_Status_of_Mapped_Survey_Forms_Test() {
		Assert.assertEquals(survey.display_Status_of_Mapped_Survey_Forms(), true);
		log.info("display_Status_of_Mapped_Survey_Forms : " + survey.display_Status_of_Mapped_Survey_Forms());
	}
	
	@Test(priority = 268)
	public void enable_Status_of_Mapped_Survey_Forms_Test() {
		Assert.assertEquals(survey.enable_Status_of_Mapped_Survey_Forms(), true);
		log.info("enable_Status_of_Mapped_Survey_Forms : " + survey.enable_Status_of_Mapped_Survey_Forms());
	}
	@Test(priority = 269)
	public void Tab_on_Mapped_Survey_Forms_Test() throws InterruptedException {
		survey.Tab_on_Mapped_Survey_Forms();
		log.info("Tab_on_Mapped_Survey_Forms");
	}
	@Test(priority = 270)
	public void display_Status_of_replace_Test() {
		Assert.assertEquals(survey.display_Status_of_replace(), true);
		log.info("display_Status_of_replace : " + survey.display_Status_of_replace());
	}
	
	@Test(priority = 271)
	public void enable_Status_of_replace_Test() {
		Assert.assertEquals(survey.enable_Status_of_replace(), true);
		log.info("enable_Status_of_replace : " + survey.enable_Status_of_replace());
	}
	@Test(priority = 272)
	public void Tab_on_replace_Test() throws InterruptedException {
		survey.Tab_on_replace();
		log.info("Tab_on_replace");
	}
	@Test(priority = 273)
	public void display_Status_of_template_name_Test() {
		Assert.assertEquals(survey.display_Status_of_template_name(), true);
		log.info("display_Status_of_template_name : " + survey.display_Status_of_template_name());
	}
	
	@Test(priority = 274)
	public void enable_Status_of_template_name_Test() {
		Assert.assertEquals(survey.enable_Status_of_template_name(), true);
		log.info("enable_Status_of_template_name : " + survey.enable_Status_of_template_name());
	}
	@Test(priority = 275)
	public void Tab_on_template_name_Test() throws InterruptedException {
		survey.Tab_on_template_name();
		log.info("Tab_on_template_name");
	}
	@Test(priority = 276)
	public void display_Status_of_Loan_agency_survey_Test() {
		Assert.assertEquals(survey.display_Status_of_Loan_agency_survey(), true);
		log.info("display_Status_of_Loan_agency_survey : " + survey.display_Status_of_Loan_agency_survey());
	}
	
	@Test(priority = 277)
	public void enable_Status_of_Loan_agency_survey_Test() {
		Assert.assertEquals(survey.enable_Status_of_Loan_agency_survey(), true);
		log.info("enable_Status_of_Loan_agency_survey : " + survey.enable_Status_of_Loan_agency_survey());
	}
	@Test(priority = 278)
	public void Tab_on_Loan_agency_survey_Test() throws InterruptedException {
		survey.Tab_on_Loan_agency_survey();
		log.info("Tab_on_Loan_agency_survey");
	}
	@Test(priority = 279)
	public void display_Status_of_replace_template_Test() {
		Assert.assertEquals(survey.display_Status_of_replace_template(), true);
		log.info("display_Status_of_replace_template : " + survey.display_Status_of_replace_template());
	}
	
	@Test(priority = 280)
	public void enable_Status_of_replace_template_Test() {
		Assert.assertEquals(survey.enable_Status_of_replace_template(), true);
		log.info("enable_Status_of_replace_template : " + survey.enable_Status_of_replace_template());
	}
//	@Test(priority = 281)
	public void Tab_on_replace_template_Test() throws InterruptedException {
		survey.Tab_on_replace_template();
		log.info("Tab_on_replace_template");
	}
	@Test(priority = 282)
	public void display_Status_of_close_reassigned_template_Test() {
		Assert.assertEquals(survey.display_Status_of_close_reassigned_template(), true);
		log.info("display_Status_of_close_reassigned_template : " + survey.display_Status_of_close_reassigned_template());
	}
	
	@Test(priority = 283)
	public void enable_Status_of_close_reassigned_template_Test() {
		Assert.assertEquals(survey.enable_Status_of_close_reassigned_template(), true);
		log.info("enable_Status_of_close_reassigned_template : " + survey.enable_Status_of_close_reassigned_template());
	}
	@Test(priority = 284)
	public void Tab_on_close_reassigned_template_Test() throws InterruptedException {
		survey.Tab_on_close_reassigned_template();
		log.info("Tab_on_close_reassigned_template");
	}
	@Test(priority = 285)
	public void display_Status_of_view_mapped_survey_form_Test() {
		Assert.assertEquals(survey.display_Status_of_view_mapped_survey_form(), true);
		log.info("display_Status_of_view_mapped_survey_form : " + survey.display_Status_of_view_mapped_survey_form());
	}
	
	@Test(priority = 286)
	public void enable_Status_of_view_mapped_survey_form_Test() {
		Assert.assertEquals(survey.enable_Status_of_view_mapped_survey_form(), true);
		log.info("enable_Status_of_view_mapped_survey_form : " + survey.enable_Status_of_view_mapped_survey_form());
	}
	@Test(priority = 287)
	public void Tab_on_view_mapped_survey_form_Test() throws InterruptedException {
		survey.Tab_on_view_mapped_survey_form();
		log.info("Tab_on_view_mapped_survey_form");
	}
	@Test(priority = 288)
	public void display_Status_of_General_Configuration_Test2() {
		Assert.assertEquals(survey.display_Status_of_General_Configuration(), true);
		log.info("display_Status_of_General_Configuration : " + survey.display_Status_of_General_Configuration());
	}
	
	@Test(priority = 289)
	public void enable_Status_of_General_Configuration_Test2() {
		Assert.assertEquals(survey.enable_Status_of_General_Configuration(), true);
		log.info("enable_Status_of_General_Configuration : " + survey.enable_Status_of_General_Configuration());
	}
	@Test(priority = 290)
	public void Tab_on_General_Configuration_Test2() throws InterruptedException {
		survey.Tab_on_General_Configuration();
		log.info("Tab_on_General_Configuration");
	}
	@Test(priority = 291)
	public void display_Status_of_close_view_template_Test() {
		Assert.assertEquals(survey.display_Status_of_close_view_template(), true);
		log.info("display_Status_of_close_view_template : " + survey.display_Status_of_close_view_template());
	}
	
	@Test(priority = 292)
	public void enable_Status_of_close_view_template_Test() {
		Assert.assertEquals(survey.enable_Status_of_close_view_template(), true);
		log.info("enable_Status_of_close_view_template : " + survey.enable_Status_of_close_view_template());
	}
	@Test(priority = 293)
	public void Tab_on_close_view_template_Test() throws InterruptedException {
		survey.Tab_on_close_view_template();
		log.info("Tab_on_close_view_template");
	}
	@Test(priority = 294)
	public void display_Status_of_IVR_Extensions_Mapping_Test() {
		Assert.assertEquals(survey.display_Status_of_IVR_Extensions_Mapping(), true);
		log.info("display_Status_of_IVR_Extensions_Mapping : " + survey.display_Status_of_IVR_Extensions_Mapping());
	}
	
	@Test(priority = 295)
	public void enable_Status_of_IVR_Extensions_Mapping_Test() {
		Assert.assertEquals(survey.enable_Status_of_IVR_Extensions_Mapping(), true);
		log.info("enable_Status_of_IVR_Extensions_Mapping : " + survey.enable_Status_of_IVR_Extensions_Mapping());
	}
	@Test(priority = 296)
	public void Tab_on_close_IVR_Extensions_Mapping_Test() throws InterruptedException {
		survey.Tab_on_close_IVR_Extensions_Mapping();
		log.info("Tab_on_close_IVR_Extensions_Mapping");
	}
	@Test(priority = 297)
	public void display_Status_of_IVR_Extensions_Mapping_edit_Test() {
		Assert.assertEquals(survey.display_Status_of_IVR_Extensions_Mapping_edit(), true);
		log.info("display_Status_of_IVR_Extensions_Mapping_edit : " + survey.display_Status_of_IVR_Extensions_Mapping_edit());
	}
	
	@Test(priority = 298)
	public void enable_Status_of_IVR_Extensions_Mapping_edit_Test() {
		Assert.assertEquals(survey.enable_Status_of_IVR_Extensions_Mapping_edit(), true);
		log.info("enable_Status_of_IVR_Extensions_Mapping_edit : " + survey.enable_Status_of_IVR_Extensions_Mapping_edit());
	}
	@Test(priority = 299)
	public void Tab_on_close_IVR_Extensions_Mapping_edit_Test() throws InterruptedException {
		survey.Tab_on_close_IVR_Extensions_Mapping_edit();
		log.info("Tab_on_close_IVR_Extensions_Mapping_edit");
	}
	@Test(priority = 300)
	public void display_Status_of_IVR_Extensions_Mapping_Number1_Test() {
		Assert.assertEquals(survey.display_Status_of_IVR_Extensions_Mapping_Number1(), true);
		log.info("display_Status_of_IVR_Extensions_Mapping_Number1 : " + survey.display_Status_of_IVR_Extensions_Mapping_Number1());
	}
	
	@Test(priority = 301)
	public void enable_Status_of_IVR_Extensions_Mapping_Number1_Test() {
		Assert.assertEquals(survey.enable_Status_of_IVR_Extensions_Mapping_Number1(), true);
		log.info("enable_Status_of_IVR_Extensions_Mapping_Number1 : " + survey.enable_Status_of_IVR_Extensions_Mapping_Number1());
	}
	@Test(priority = 302)
	public void Tab_on_IVR_Extensions_Mapping_Number1_cut_and_paste_Test() throws InterruptedException {
		survey.Tab_on_IVR_Extensions_Mapping_Number1_cut_and_paste();
		log.info("Tab_on_IVR_Extensions_Mapping_Number1_cut_and_paste");
	}
	@Test(priority = 303)
	public void display_Status_of_IVR_Extensions_Mapping_Number2_Test() throws InterruptedException {
		Assert.assertEquals(survey.display_Status_of_IVR_Extensions_Mapping_Number2(), true);
		log.info("display_Status_of_IVR_Extensions_Mapping_Number2 : " + survey.display_Status_of_IVR_Extensions_Mapping_Number2());
	}
	
	@Test(priority = 304)
	public void enable_Status_of_IVR_Extensions_Mapping_Number2_Test() {
		Assert.assertEquals(survey.enable_Status_of_IVR_Extensions_Mapping_Number2(), true);
		log.info("enable_Status_of_IVR_Extensions_Mapping_Number2 : " + survey.enable_Status_of_IVR_Extensions_Mapping_Number2());
	}
	@Test(priority = 305)
	public void Tab_on_IVR_Extensions_Mapping_Number2_cut_and_paste_Test() throws InterruptedException {
		survey.Tab_on_IVR_Extensions_Mapping_Number2_cut_and_paste();
		log.info("Tab_on_IVR_Extensions_Mapping_Number2_cut_and_paste");
	}
	@Test(priority = 306)
	public void display_Status_of_IVR_Extensions_Mapping_Save_Test() throws InterruptedException {
		Assert.assertEquals(survey.display_Status_of_IVR_Extensions_Mapping_Save(), true);
		log.info("display_Status_of_IVR_Extensions_Mapping_Save : " + survey.display_Status_of_IVR_Extensions_Mapping_Save());
	}
	
	@Test(priority = 307)
	public void enable_Status_of_IVR_Extensions_Mapping_Save_Test() {
		Assert.assertEquals(survey.enable_Status_of_IVR_Extensions_Mapping_Save(), true);
		log.info("enable_Status_of_IVR_Extensions_Mapping_Save : " + survey.enable_Status_of_IVR_Extensions_Mapping_Save());
	}
//	@Test(priority = 308)
	public void Tab_on_IVR_Extensions_Mapping_Save_Test() throws InterruptedException {
		survey.Tab_on_IVR_Extensions_Mapping_Save();
		log.info("Tab_on_IVR_Extensions_Mapping_Save");
	}
}
