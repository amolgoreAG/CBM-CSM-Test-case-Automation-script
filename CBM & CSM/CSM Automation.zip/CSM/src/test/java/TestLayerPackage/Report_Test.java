package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CSM;
import PageLayerPackage.Report;

public class Report_Test extends Base_Class_CSM{

	private static final Logger log = Logger.getLogger(Report_Test.class);
	
	public static Report report ;
	
	@Test(priority = 309)
	public void display_Status_of_Report_Test() {
		report = new Report();
		Assert.assertEquals(report.display_Status_of_Report(), true);
		log.info("display_Status_of_Report : " + report.display_Status_of_Report());
	}
	
	@Test(priority = 310)
	public void enable_Status_of_Report_Test() {
		Assert.assertEquals(report.enable_Status_of_Report(), true);
		log.info("enable_Status_of_Report : " + report.enable_Status_of_Report());
	}
	
	@Test(priority = 311)
	public void Tab_on_click_on_Report() {
		report.click_on_Report();
		log.info("click_on_Report");
	}
	@Test(priority = 312)
	public void display_Status_of_From_Date_Test() {
		Assert.assertEquals(report.display_Status_of_From_Date(), true);
		log.info("display_Status_of_From_Date : " + report.display_Status_of_From_Date());
	}
	
	@Test(priority = 313)
	public void enable_Status_of_From_Date_Test() {
		Assert.assertEquals(report.enable_Status_of_From_Date(), true);
		log.info("enable_Status_of_From_Date : " + report.enable_Status_of_From_Date());
	}
	
	@Test(priority = 314)
	public void click_on_From_Date_Test() {
		report.click_on_From_Date();
		log.info("click_on_From_Date");
	}
	
	@Test(priority = 315)
	public void select_the_from_date_Test() {
		report.select_the_from_date();
		log.info("select_the_from_date");
	}
	@Test(priority = 316)
	public void display_Status_of_To_Date_Test() {
		Assert.assertEquals(report.display_Status_of_To_Date(), true);
		log.info("display_Status_of_To_Date : " + report.display_Status_of_To_Date());
	}
	
	@Test(priority = 317)
	public void enable_Status_of_To_Date_Test() {
		Assert.assertEquals(report.enable_Status_of_To_Date(), true);
		log.info("enable_Status_of_To_Date : " + report.enable_Status_of_To_Date());
	}
	
	@Test(priority = 318)
	public void click_on_To_Date_Test() {
		report.click_on_To_Date();
		log.info("click_on_To_Date");
	}
	
	@Test(priority = 319)
	public void select_the_to_date_Test() {
		report.select_the_to_date();
		log.info("select_the_to_date");
	}
	@Test(priority = 320)
	public void display_Status_of_customer_Number_Test() {
		Assert.assertEquals(report.display_Status_of_customer_Number(), true);
		log.info("display_Status_of_customer_Number : " + report.display_Status_of_customer_Number());
	}
	
	@Test(priority = 321)
	public void enable_Status_of_customer_Number_Test() {
		Assert.assertEquals(report.enable_Status_of_customer_Number(), true);
		log.info("enable_Status_of_customer_Number : " + report.enable_Status_of_customer_Number());
	}
	
	@Test(priority = 322)
	public void enter_data_in_customer_Number_Test() {
		report.enter_data_in_customer_Number();
		log.info("enter_data_in_customer_Number");
	}
	@Test(priority = 323)
	public void display_Status_of_Language_Drop_Down_Test() {
		Assert.assertEquals(report.display_Status_of_Language_Drop_Down(), true);
		log.info("display_Status_of_Language_Drop_Down : " + report.display_Status_of_Language_Drop_Down());
	}
	
	@Test(priority = 324)
	public void enable_Status_of_Language_Drop_Down_Test() {
		Assert.assertEquals(report.enable_Status_of_Language_Drop_Down(), true);
		log.info("enable_Status_of_Language_Drop_Down : " + report.enable_Status_of_Language_Drop_Down());
	}
	
	@Test(priority = 325)
	public void tab_on_Language_Drop_Down_Test() throws InterruptedException {
		report.tab_on_Language_Drop_Down();
		log.info("tab_on_Language_Drop_Down");
	}
	
	@Test(priority = 326)
	public void select_the_language_Test() throws InterruptedException {
		report.select_the_language();
		log.info("select_the_language");
	}
	@Test(priority = 327)
	public void display_Status_of_Survey_Type_Test() {
		Assert.assertEquals(report.display_Status_of_Survey_Type(), true);
		log.info("display_Status_of_Survey_Type : " + report.display_Status_of_Survey_Type());
	}
	
	@Test(priority = 328)
	public void enable_Status_of_Survey_Type_Test() {
		Assert.assertEquals(report.enable_Status_of_Survey_Type(), true);
		log.info("enable_Status_of_Survey_Type : " + report.enable_Status_of_Survey_Type());
	}
	
	@Test(priority = 329)
	public void tab_on_Survey_Type_Test() throws InterruptedException {
		report.tab_on_Survey_Type();
		log.info("tab_on_Survey_Type");
	}
	
	@Test(priority = 330)
	public void select_the_Survey_Type_General_Survey_Test() throws InterruptedException {
		report.select_the_Survey_Type_General_Survey();
		log.info("select_the_Survey_Type_General_Survey");
	}
//	@Test(priority = 331)
//	public void display_Status_of_Agent_ID_Test() {
//		Assert.assertEquals(report.display_Status_of_Agent_ID(), true);
//		log.info("display_Status_of_Agent_ID : " + report.display_Status_of_Agent_ID());
//	}
//	
//	@Test(priority = 332)
//	public void enable_Status_of_Agent_ID_Test() {
//		Assert.assertEquals(report.enable_Status_of_Agent_ID(), true);
//		log.info("enable_Status_of_Agent_ID : " + report.enable_Status_of_Agent_ID());
//	}
//	
//	@Test(priority = 333)
//	public void Enter_Agent_ID_Test() throws InterruptedException {
//		report.Enter_Agent_ID();
//		log.info("Enter_Agent_ID");
//	}
//	@Test(priority = 334)
//	public void display_Status_of_Agent_Name_Test() {
//		Assert.assertEquals(report.display_Status_of_Agent_Name(), true);
//		log.info("display_Status_of_Agent_Name : " + report.display_Status_of_Agent_Name());
//	}
//	
//	@Test(priority = 335)
//	public void enable_Status_of_Agent_Name_Test() {
//		Assert.assertEquals(report.enable_Status_of_Agent_Name(), true);
//		log.info("enable_Status_of_Agent_Name : " + report.enable_Status_of_Agent_Name());
//	}
//	
//	@Test(priority = 336)
//	public void Enter_Agent_Name_Test() throws InterruptedException {
//		report.Enter_Agent_Name();
//		log.info("Enter_Agent_Name");
//	}
//	@Test(priority = 337)
//	public void display_Status_of_Agent_Extension_Test() {
//		Assert.assertEquals(report.display_Status_of_Agent_Extension(), true);
//		log.info("display_Status_of_Agent_Extension : " + report.display_Status_of_Agent_Extension());
//	}
//	
//	@Test(priority = 338)
//	public void enable_Status_of_Agent_Extension_Test() {
//		Assert.assertEquals(report.enable_Status_of_Agent_Extension(), true);
//		log.info("enable_Status_of_Agent_Extension : " + report.enable_Status_of_Agent_Extension());
//	}
//	
//	@Test(priority = 339)
//	public void Enter_Agent_Extension_Test() throws InterruptedException {
//		report.Enter_Agent_Extension();
//		log.info("Enter_Agent_Extension");
//	}
	@Test(priority = 340)
	public void display_Status_of_Search_Test() {
		Assert.assertEquals(report.display_Status_of_Search(), true);
		log.info("display_Status_of_Search : " + report.display_Status_of_Search());
	}
	
	@Test(priority = 341)
	public void enable_Status_of_Search_Test() {
		Assert.assertEquals(report.enable_Status_of_Search(), true);
		log.info("enable_Status_of_Search : " + report.enable_Status_of_Search());
	}
	
	@Test(priority = 342)
	public void tab_on_Search_Test() throws InterruptedException {
		report.tab_on_Search();
		log.info("tab_on_Search");
	}
	@Test(priority = 343)
	public void display_Status_of_Download_Report_Test() {
		Assert.assertEquals(report.display_Status_of_Download_Report(), true);
		log.info("display_Status_of_Download_Report : " + report.display_Status_of_Download_Report());
	}
	
	@Test(priority = 344)
	public void enable_Status_of_Download_Report_Test() {
		Assert.assertEquals(report.enable_Status_of_Download_Report(), true);
		log.info("enable_Status_of_Download_Report : " + report.enable_Status_of_Download_Report());
	}
	
	@Test(priority = 345)
	public void display_Status_of_Clear_Test() {
		Assert.assertEquals(report.display_Status_of_Clear(), true);
		log.info("display_Status_of_Clear : " + report.display_Status_of_Clear());
	}
	
	@Test(priority = 346)
	public void enable_Status_of_Clear_Test() {
		Assert.assertEquals(report.enable_Status_of_Clear(), true);
		log.info("enable_Status_of_Clear : " + report.enable_Status_of_Clear());
	}
	
	@Test(priority = 347)
	public void Tab_on_Clear_Test() throws InterruptedException {
		report.Tab_on_Clear();
		log.info("Tab_on_Clear");
	}
	@Test(priority = 348)
	public void display_Status_of_Summary_Report_Test() {
		Assert.assertEquals(report.display_Status_of_Summary_Report(), true);
		log.info("display_Status_of_Summary_Report : " + report.display_Status_of_Summary_Report());
	}
	
	@Test(priority = 349)
	public void enable_Status_of_Summary_Report_Test() {
		Assert.assertEquals(report.enable_Status_of_Summary_Report(), true);
		log.info("enable_Status_of_Summary_Report : " + report.enable_Status_of_Summary_Report());
	}
	
	@Test(priority = 350)
	public void Tab_on_Summary_Report_Test() throws InterruptedException {
		report.Tab_on_Summary_Report();
		log.info("Tab_on_Summary_Report");
	}
	@Test(priority = 351)
	public void display_Status_of_Summary_Report_FromDate_Test() {
		Assert.assertEquals(report.display_Status_of_Summary_Report_FromDate(), true);
		log.info("display_Status_of_Summary_Report_FromDate : " + report.display_Status_of_Summary_Report_FromDate());
	}
	
	@Test(priority = 352)
	public void enable_Status_of_Summary_Report_FromDate_Test() {
		Assert.assertEquals(report.enable_Status_of_Summary_Report_FromDate(), true);
		log.info("enable_Status_of_Summary_Report_FromDate : " + report.enable_Status_of_Summary_Report_FromDate());
	}
	
	@Test(priority = 353)
	public void click_on_Summary_Report_FromDate_Test() throws InterruptedException {
		report.click_on_Summary_Report_FromDate();
		log.info("click_on_Summary_Report_FromDate");
	}
	@Test(priority = 354)
	public void select_the_fromdate_Test() throws InterruptedException {
		report.select_the_fromdate();
		log.info("select_the_fromdate");
	}
	@Test(priority = 355)
	public void display_Status_of_Summary_Report_ToDate_Test() {
		Assert.assertEquals(report.display_Status_of_Summary_Report_ToDate(), true);
		log.info("display_Status_of_Summary_Report_ToDate : " + report.display_Status_of_Summary_Report_ToDate());
	}
	
	@Test(priority = 356)
	public void enable_Status_of_Summary_Report_ToDate_Test() {
		Assert.assertEquals(report.enable_Status_of_Summary_Report_ToDate(), true);
		log.info("enable_Status_of_Summary_Report_ToDate : " + report.enable_Status_of_Summary_Report_ToDate());
	}
	
	@Test(priority = 357)
	public void click_on_Summary_Report_ToDate_Test() throws InterruptedException {
		report.click_on_Summary_Report_ToDate();
		log.info("click_on_Summary_Report_ToDate");
	}
	@Test(priority = 358)
	public void select_the_todate_Test() throws InterruptedException {
		report.select_the_todate();
		log.info("select_the_todate");
	}
	@Test(priority = 359)
	public void display_Status_of_Summary_Report_Survey_Type_Test() {
		Assert.assertEquals(report.display_Status_of_Summary_Report_Survey_Type(), true);
		log.info("display_Status_of_Summary_Report_Survey_Type : " + report.display_Status_of_Summary_Report_Survey_Type());
	}
	
	@Test(priority = 360)
	public void enable_Status_of_Summary_Report_Survey_Type_Test() {
		Assert.assertEquals(report.enable_Status_of_Summary_Report_Survey_Type(), true);
		log.info("enable_Status_of_Summary_Report_Survey_Type : " + report.enable_Status_of_Summary_Report_Survey_Type());
	}
	
	@Test(priority = 361)
	public void click_on_Summary_Report_Survey_Type_Test() throws InterruptedException {
		report.click_on_Summary_Report_Survey_Type();
		log.info("click_on_Summary_Report_Survey_Type");
	}
	@Test(priority = 362)
	public void select_Summary_Report_Survey_Type_General_Survey_Test() throws InterruptedException {
		report.select_Summary_Report_Survey_Type_General_Survey();
		log.info("select_Summary_Report_Survey_Type_General_Survey");
	}
	@Test(priority = 363)
	public void display_Status_of_Generate_Report_Test() {
		Assert.assertEquals(report.display_Status_of_Generate_Report(), true);
		log.info("display_Status_of_Generate_Report : " + report.display_Status_of_Generate_Report());
	}
	
	@Test(priority = 364)
	public void enable_Status_of_Generate_Report_Test() {
		Assert.assertEquals(report.enable_Status_of_Generate_Report(), true);
		log.info("enable_Status_of_Generate_Report : " + report.enable_Status_of_Generate_Report());
	}
	
	@Test(priority = 365)
	public void click_on_Generate_Report_Test() throws InterruptedException {
		report.click_on_Generate_Report();
		log.info("click_on_Generate_Report");
	}
	@Test(priority = 366)
	public void display_Status_of_Download_Report_Test2() {
		Assert.assertEquals(report.display_Status_of_Download_Report(), true);
		log.info("display_Status_of_Download_Report : " + report.display_Status_of_Download_Report());
	}
	
	@Test(priority = 367)
	public void enable_Status_of_Download_Report_Test2() {
		Assert.assertEquals(report.enable_Status_of_Download_Report(), true);
		log.info("enable_Status_of_Download_Report : " + report.enable_Status_of_Download_Report());
	}
	@Test(priority = 368)
	public void display_Status_of_Generate_Graph_Test() {
		Assert.assertEquals(report.display_Status_of_Generate_Graph(), true);
		log.info("display_Status_of_Generate_Graph : " + report.display_Status_of_Generate_Graph());
	}
	
	@Test(priority = 369)
	public void enable_Status_of_Generate_Graph_Test() {
		Assert.assertEquals(report.enable_Status_of_Generate_Graph(), true);
		log.info("enable_Status_of_Generate_Graph : " + report.enable_Status_of_Generate_Graph());
	}
	
	@Test(priority = 370)
	public void click_on_Generate_Graph_Test() throws InterruptedException {
		report.click_on_Generate_Graph();
		log.info("click_on_Generate_Graph");
	}
}
