package UtilsLayerPackage;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import BaseLayerPackage.Base_Class_CSM;

public class CSM_Extents_Report extends Base_Class_CSM {

	public static ExtentReports extend;

	public static ExtentReports report() {
		ExtentSparkReporter sparkReporter = new ExtentSparkReporter(
				"C:\\Users\\cognicx\\eclipse-workspace\\CSM\\CSM_Report");
		extend = new ExtentReports();
		extend.attachReporter(sparkReporter);
		sparkReporter.config().setDocumentTitle("CSM");
		sparkReporter.config().setTheme(Theme.DARK);
		return extend;
	}
	
	public static String getPassScreenshot(String screenshotName) throws IOException {
		File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		String dist = System.getProperty("user.dir")+ "\\Report passScreenshot\\" + screenshotName + getDate() + ".png";
		FileUtils.copyFile(f, new File(dist));
		return dist ; 
	}
	public static String getFailScreenshot(String screenshotName) throws IOException {
		File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String dist = System.getProperty("user.dir")+ "\\Report FailScreenshot\\" + screenshotName + getDate() + ".png";
		FileUtils.copyFile(f, new File(dist));
		return dist ; 
	}
	
	public static String getDate() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}
}
