package BaseLayerPackage;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Base_Class_CSM {
	public static WebDriver driver;
	public static ChromeOptions option;

	public static void CSM() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\cognicx\\eclipse-workspace\\CSM\\Driver\\chromedriver.exe");
		option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(45));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(45));
		driver.manage().window().maximize();
		driver.get("http://150.242.13.125:8080/CSM/#/CSM/");
}
	}