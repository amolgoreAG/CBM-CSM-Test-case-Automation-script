package PageLayerPackage;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CSM;

public class CSM_Login extends Base_Class_CSM{

	private static final Logger log = Logger.getLogger(CSM_Login.class);

	@FindBy(xpath = "//input[@id='id']")
	WebElement Username ;
	
	@FindBy(xpath = "//input[@id='password']")
	WebElement Password ;
	
	@FindBy(xpath = "//button[text()='Login']")
	WebElement Login ;
	
	public  CSM_Login() {
		PageFactory.initElements(driver, this);
	}
	public boolean display_Status_of_Username() {
		return Username.isDisplayed();
	}
	public boolean enable_Status_of_Username() {
		return Username.isEnabled();
	}
	public void enter_username() {
		Username.sendKeys("SuperAdmin");
		log.info("Enter Username : " + Username.getAttribute("Value"));
	}
	public boolean display_Status_of_Password() {
		return Password.isDisplayed();
	}
	public boolean enable_Status_of_Password() {
		return Password.isEnabled();
	}
	public void enter_Password() {
		Password.sendKeys("Welcome@123");
		log.info("Enter Password : " + Password.getAttribute("Value"));
	}
	public boolean display_Status_of_Login() {
		return Login.isDisplayed();
	}
	public boolean enable_Status_of_Login() {
		return Login.isEnabled();
	}
	public void tab_on_login() {
		Login.click();
		log.info("Tab on login");
	}
}
