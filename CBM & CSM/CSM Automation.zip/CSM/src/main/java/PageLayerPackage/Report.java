package PageLayerPackage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CSM;

public class Report extends Base_Class_CSM{


	@FindBy(xpath = "//div[@class='sidenav _homePage']//li[2]/a")
	WebElement Report;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[5]/div/input")
	WebElement From_Date;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[8]/input")
	WebElement To_Date;
	
	@FindBy(xpath = "//button[text()='Previous Month']")
	WebElement Previous_Month;
	
	@FindBy(xpath = "//button[text()='Next Month']")
	WebElement Next_Month;
	
	@FindBy(xpath = "//div[@class='react-datepicker__header']/div[1]")
	WebElement Month_Year;
	
	@FindBy(xpath = "//div[text()='3']")
	WebElement From_date;
	
	@FindBy(xpath = "//div[text()='3']")
	WebElement date;
	
	@FindBy(xpath = "//input[@id='CustomerNumber']")
	WebElement customer_Number;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[15]/div")
	WebElement Language_Drop_Down;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[20]/span[3]")
	WebElement Language_English;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[22]/div")
	WebElement Survey_Type;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[27]/span")
	WebElement Survey_Type_General_Survey;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[29]/input")
	WebElement Agent_ID;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[31]/input")
	WebElement Agent_Name;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-SEARCH_SURVEY']//div)[33]/input")
	WebElement Agent_Extension;
	
	@FindBy(xpath = "//button[text()='Search']")
	WebElement Search;
	
	@FindBy(xpath = "//button[text()='Clear']")
	WebElement Clear;
	
	@FindBy(xpath = "//button[text()='Download Report']")
	WebElement Download_Report;
	
	@FindBy(xpath = "//a[@id='noanim-tab-example-tab-REPORTS']")
	WebElement Summary_Report;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-REPORTS']//div)[4]/div/div/input")
	WebElement Summary_Report_FromDate;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-REPORTS']//div)[7]/div/div/input")
	WebElement Summary_Report_ToDate;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-REPORTS']//div)[11]/div/div[3]")
	WebElement Summary_Report_Survey_Type;
	
	@FindBy(xpath = "//div[@role='list']/span[1]")
	WebElement Summary_Report_Survey_Type_General_Survey;
	
	@FindBy(xpath = "//button[text()='Generate Report']")
	WebElement Generate_Report;
	
	@FindBy(xpath = "//button[text()='Generate Graph']")
	WebElement Generate_Graph;
	
	
	public Report() {
		PageFactory.initElements(driver, this);
	}
	public boolean display_Status_of_Report() {
		new Actions(driver).moveToElement(Report).build().perform();
		return Report.isDisplayed();
	}

	public boolean enable_Status_of_Report() {
		return Report.isEnabled();
	}

	public void click_on_Report() {
		try {
			Report.click();
		} catch (Exception e) {
			new Actions(driver).click(Report).build().perform();
		}
	}
	public boolean display_Status_of_From_Date() {
		new Actions(driver).moveToElement(From_Date).build().perform();
		return From_Date.isDisplayed();
	}
	
	public boolean enable_Status_of_From_Date() {
		return From_Date.isEnabled();
	}
	
	public void click_on_From_Date() {
		try {
			From_Date.click();
		} catch (Exception e) {
			new Actions(driver).click(From_Date).build().perform();
		}
	}
	public void select_the_from_date() {
		Month_Year.getText();
		System.out.println("Month_Year : " + Month_Year.getText());
		while(true) {
			if(Month_Year.getText().contains("November 2023")) {
				break;
			}else {
				Previous_Month.click();
			}
		}
		From_date.click();
	}
	public boolean display_Status_of_To_Date() {
		new Actions(driver).moveToElement(To_Date).build().perform();
		return To_Date.isDisplayed();
	}
	
	public boolean enable_Status_of_To_Date() {
		return To_Date.isEnabled();
	}
	
	public void click_on_To_Date() {
		try {
			To_Date.click();
		} catch (Exception e) {
			new Actions(driver).click(To_Date).build().perform();
		}
	}
	public void select_the_to_date() {
		System.out.println("Month_Year : " + Month_Year.getText());
		while(true) {
			if(Month_Year.getText().contains("December 2023")) {
				break;
			}else {
				Next_Month.click();
			}
		}
		date.click();
	}
	public boolean display_Status_of_customer_Number() {
		new Actions(driver).moveToElement(customer_Number).build().perform();
		return customer_Number.isDisplayed();
	}
	
	public boolean enable_Status_of_customer_Number() {
		return customer_Number.isEnabled();
	}
	public void enter_data_in_customer_Number() {
		customer_Number.sendKeys("543840");
	}
	public boolean display_Status_of_Language_Drop_Down() {
		new Actions(driver).moveToElement(Language_Drop_Down).build().perform();
		return Language_Drop_Down.isDisplayed();
	}
	
	public boolean enable_Status_of_Language_Drop_Down() {
		return Language_Drop_Down.isEnabled();
	}
	public void tab_on_Language_Drop_Down() throws InterruptedException {
		Language_Drop_Down.click();
	}
	public void select_the_language() throws InterruptedException {
		Language_English.click();
	}
	public boolean display_Status_of_Survey_Type() {
		new Actions(driver).moveToElement(Survey_Type).build().perform();
		return Survey_Type.isDisplayed();
	}
	
	public boolean enable_Status_of_Survey_Type() {
		return Survey_Type.isEnabled();
	}
	public void tab_on_Survey_Type() throws InterruptedException {
		Survey_Type.click();
	}
	public void select_the_Survey_Type_General_Survey() throws InterruptedException {
		Survey_Type_General_Survey.click();
	}
	public boolean display_Status_of_Agent_ID() {
		new Actions(driver).moveToElement(Agent_ID).build().perform();
		return Agent_ID.isDisplayed();
	}
	
	public boolean enable_Status_of_Agent_ID() {
		return Agent_ID.isEnabled();
	}
	public void Enter_Agent_ID() throws InterruptedException {
		Agent_ID.sendKeys("5001");
	}
	public boolean display_Status_of_Agent_Name() {
		new Actions(driver).moveToElement(Agent_Name).build().perform();
		return Agent_Name.isDisplayed();
	}
	
	public boolean enable_Status_of_Agent_Name() {
		return Agent_Name.isEnabled();
	}
	public void Enter_Agent_Name() throws InterruptedException {
		Agent_Name.sendKeys("Selvan");
	}
	public boolean display_Status_of_Agent_Extension() {
		new Actions(driver).moveToElement(Agent_Extension).build().perform();
		return Agent_Extension.isDisplayed();
	}
	
	public boolean enable_Status_of_Agent_Extension() {
		return Agent_Extension.isEnabled();
	}
	public void Enter_Agent_Extension() throws InterruptedException {
		Agent_Extension.sendKeys("58505");
	}
	public boolean display_Status_of_Search() {
		new Actions(driver).moveToElement(Search).build().perform();
		return Search.isDisplayed();
	}
	
	public boolean enable_Status_of_Search() {
		return Search.isEnabled();
	}
	public void tab_on_Search() throws InterruptedException {
		Search.click();
	}
	public boolean display_Status_of_Download_Report() {
		new Actions(driver).moveToElement(Download_Report).build().perform();
		return Download_Report.isDisplayed();
	}
	
	public boolean enable_Status_of_Download_Report() {
		return Download_Report.isEnabled();
	}
	public boolean display_Status_of_Clear() {
		new Actions(driver).moveToElement(Clear).build().perform();
		return Clear.isDisplayed();
	}
	
	public boolean enable_Status_of_Clear() {
		return Clear.isEnabled();
	}
	
	public void Tab_on_Clear() {
		try {
			Clear.clear();
		} catch (Exception e) {
			new Actions(driver).click(Clear).build().perform();
		}
	}
	public boolean display_Status_of_Summary_Report() {
		new Actions(driver).moveToElement(Summary_Report).build().perform();
		return Summary_Report.isDisplayed();
	}
	
	public boolean enable_Status_of_Summary_Report() {
		return Summary_Report.isEnabled();
	}
	
	public void Tab_on_Summary_Report() {
		try {
			Summary_Report.clear();
		} catch (Exception e) {
			new Actions(driver).click(Summary_Report).build().perform();
		}
	}
	public boolean display_Status_of_Summary_Report_FromDate() {
		new Actions(driver).moveToElement(Summary_Report_FromDate).build().perform();
		return Summary_Report_FromDate.isDisplayed();
	}
	
	public boolean enable_Status_of_Summary_Report_FromDate() {
		return Summary_Report_FromDate.isEnabled();
	}
	
	public void click_on_Summary_Report_FromDate() {
		try {
			Summary_Report_FromDate.click();
		} catch (Exception e) {
			new Actions(driver).click(Summary_Report_FromDate).build().perform();
		}
	}
	public void select_the_fromdate() {
		Month_Year.getText();
		System.out.println("Month_Year : " + Month_Year.getText());
		while(true) {
			if(Month_Year.getText().contains("November 2023")) {
				break;
			}else {
				Previous_Month.click();
			}
		}
		From_date.click();
	}
	public boolean display_Status_of_Summary_Report_ToDate() {
		new Actions(driver).moveToElement(Summary_Report_ToDate).build().perform();
		return Summary_Report_ToDate.isDisplayed();
	}
	
	public boolean enable_Status_of_Summary_Report_ToDate() {
		return Summary_Report_ToDate.isEnabled();
	}
	
	public void click_on_Summary_Report_ToDate() {
		try {
			Summary_Report_ToDate.click();
		} catch (Exception e) {
			new Actions(driver).click(Summary_Report_ToDate).build().perform();
		}
	}
	public void select_the_todate() {
		System.out.println("Month_Year : " + Month_Year.getText());
		while(true) {
			if(Month_Year.getText().contains("December 2023")) {
				break;
			}else {
				Next_Month.click();
			}
		}
		date.click();
	}
	public boolean display_Status_of_Summary_Report_Survey_Type() {
		new Actions(driver).moveToElement(Summary_Report_Survey_Type).build().perform();
		return Summary_Report_Survey_Type.isDisplayed();
	}
	
	public boolean enable_Status_of_Summary_Report_Survey_Type() {
		return Summary_Report_Survey_Type.isEnabled();
	}
	
	public void click_on_Summary_Report_Survey_Type() {
		try {
			Summary_Report_Survey_Type.click();
		} catch (Exception e) {
			new Actions(driver).click(Summary_Report_Survey_Type).build().perform();
		}
	}
	public void select_Summary_Report_Survey_Type_General_Survey() {
		try {
			Summary_Report_Survey_Type_General_Survey.click();
		} catch (Exception e) {
			new Actions(driver).click(Summary_Report_Survey_Type_General_Survey).build().perform();
		}
	}
	public boolean display_Status_of_Generate_Report() {
		new Actions(driver).moveToElement(Generate_Report).build().perform();
		return Generate_Report.isDisplayed();
	}
	
	public boolean enable_Status_of_Generate_Report() {
		return Generate_Report.isEnabled();
	}
	
	public void click_on_Generate_Report() {
		try {
			Generate_Report.click();
		} catch (Exception e) {
			new Actions(driver).click(Generate_Report).build().perform();
		}
	}
	
	public boolean display_Status_of_Generate_Graph() {
		new Actions(driver).moveToElement(Generate_Graph).build().perform();
		return Generate_Graph.isDisplayed();
	}
	
	public boolean enable_Status_of_Generate_Graph() {
		return Generate_Graph.isEnabled();
	}
	
	public void click_on_Generate_Graph() {
		try {
			Generate_Graph.click();
		} catch (Exception e) {
			new Actions(driver).click(Generate_Graph).build().perform();
		}
	}
	

}
