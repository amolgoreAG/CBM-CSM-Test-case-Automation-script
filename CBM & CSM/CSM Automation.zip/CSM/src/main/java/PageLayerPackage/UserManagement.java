package PageLayerPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CSM;

public class UserManagement extends Base_Class_CSM{

	@FindBy(xpath = "//div[@class='sidenav _homePage']//li[3]/a")
	WebElement UserManagement;
	
	@FindBy(xpath = "//button[text()='Add New Users']")
	WebElement Add_New_User;
	
	@FindBy(xpath = "//input[@id='employeeId']")
	WebElement Employe_ID;
	
	@FindBy(xpath = "//input[@id='password']")
	WebElement password;
	
	@FindBy(xpath = "//input[@id='firstName']")
	WebElement firstName;
	
	@FindBy(xpath = "//input[@id='lastName']")
	WebElement lastName;
	
	@FindBy(xpath = "//input[@id='email']")
	WebElement email;
	
	@FindBy(xpath = "//input[@id='email']//following::div[5]")
	WebElement Role_DP;
	
	@FindBy(xpath = "//div[@role='list']/span[1]")
	WebElement Role_DP_Admin;
	
	@FindBy(xpath = "//input[@id='mobileNumber']")
	WebElement mobile_number;
	
	@FindBy(xpath = "//input[@id='email']//following::div[16]")
	WebElement Survey_Type_DP;
	
	@FindBy(xpath = "//input[@id='email']//following::div[13]")
	WebElement Edit_Survey_Type_DP;
	
	@FindBy(xpath = "//div[@role='list']/span[1]")
	WebElement Survey_Type_DP_Value;
	
	@FindBy(xpath = "//button[text()='Save']")
	WebElement Add_User_save;
	
	@FindBy(xpath = "//button[text()='Close']")
	WebElement Add_User_Close;
	
	@FindBy(xpath = "((//div[@id='root']//div)[9]/table//tr)[2]/td[5]/i")
	WebElement edit;
	
	@FindBy(xpath = "//button[text()='Close']")
	WebElement edit_Close;
	
	@FindBy(xpath = "//button[text()='Update']")
	WebElement edit_Update;
	
	@FindBy(xpath = "(//input[@type='checkbox'])[2]")
	WebElement change_pass_checkbox;
	
	@FindBy(xpath = "//a[@id='collasible-nav-dropdown']/i")
	WebElement option;
	
	@FindBy(xpath = "//a[text()='Sign Out']")
	WebElement sign_out;
	
	public UserManagement() {
		PageFactory.initElements(driver, this);
	}
	public boolean display_Status_of_UserManagement() {
		new Actions(driver).moveToElement(UserManagement).build().perform();
		return UserManagement.isDisplayed();
	}

	public boolean enable_Status_of_UserManagement() {
		return UserManagement.isEnabled();
	}

	public void click_on_UserManagement() {
		try {
			UserManagement.click();
		} catch (Exception e) {
			new Actions(driver).click(UserManagement).build().perform();
		}
	}
	public boolean display_Status_of_Add_New_User() {
		new Actions(driver).moveToElement(Add_New_User).build().perform();
		return Add_New_User.isDisplayed();
	}
	
	public boolean enable_Status_of_Add_New_User() {
		return Add_New_User.isEnabled();
	}
	
	public void click_on_Add_New_User() {
		try {
			Add_New_User.click();
		} catch (Exception e) {
			new Actions(driver).click(Add_New_User).build().perform();
		}
	}
	public boolean display_Status_of_Employe_ID() throws InterruptedException {
		Thread.sleep(5000);
		new Actions(driver).moveToElement(Employe_ID).build().perform();
		return Employe_ID.isDisplayed();
	}
	
	public boolean enable_Status_of_Employe_ID() {
		return Employe_ID.isEnabled();
	}
	
	public void enter_Employe_ID() {
		Employe_ID.sendKeys("5010");
	}
	public boolean display_Status_of_password() {
		new Actions(driver).moveToElement(password).build().perform();
		return password.isDisplayed();
	}
	
	public boolean enable_Status_of_password() {
		return password.isEnabled();
	}
	
	public void enter_password() {
		password.sendKeys("123456789");
	}
	public boolean display_Status_of_firstName() {
		new Actions(driver).moveToElement(firstName).build().perform();
		return firstName.isDisplayed();
	}
	
	public boolean enable_Status_of_firstName() {
		return firstName.isEnabled();
	}
	
	public void enter_firstName() {
		firstName.sendKeys("Amol");
	}
	public boolean display_Status_of_lastName() {
		new Actions(driver).moveToElement(lastName).build().perform();
		return lastName.isDisplayed();
	}
	
	public boolean enable_Status_of_lastName() {
		return lastName.isEnabled();
	}
	
	public void enter_lastName() {
		lastName.sendKeys("Gore");
	}
	public boolean display_Status_of_email() {
		new Actions(driver).moveToElement(email).build().perform();
		return email.isDisplayed();
	}
	
	public boolean enable_Status_of_email() {
		return email.isEnabled();
	}
	
	public void enter_email() {
		email.sendKeys("amolgore707@gmail.com");
	}
	public boolean display_Status_of_Role_DP() {
		new Actions(driver).moveToElement(Role_DP).build().perform();
		return Role_DP.isDisplayed();
	}
	
	public boolean enable_Status_of_Role_DP() {
		return Role_DP.isEnabled();
	}
	
	public void tab_on_Role_DP_And_select_Admin() {
		try {
			Role_DP.click();
		} catch (Exception e) {
			new Actions(driver).click(Role_DP).build().perform();
		}	
		try {
			Role_DP_Admin.click();
		} catch (Exception e) {
			new Actions(driver).click(Role_DP_Admin).build().perform();
		}	
	}
	public boolean display_Status_of_mobile_number() {
		new Actions(driver).moveToElement(mobile_number).build().perform();
		return mobile_number.isDisplayed();
	}
	
	public boolean enable_Status_of_mobile_number() {
		return mobile_number.isEnabled();
	}
	
	public void enter_mobile_number() {
		mobile_number.sendKeys("9876543210");
	}
	public boolean display_Status_of_Survey_Type_DP() {
		new Actions(driver).moveToElement(Survey_Type_DP).build().perform();
		return Survey_Type_DP.isDisplayed();
	}
	
	public boolean enable_Status_of_Survey_Type_DP() {
		return Survey_Type_DP.isEnabled();
	}
	
	public void tab_on_Survey_Type_DP() throws InterruptedException {
		try {
			Survey_Type_DP.click();
		} catch (Exception e) {
			new Actions(driver).click(Survey_Type_DP).build().perform();
		}
		Thread.sleep(2000);
		Survey_Type_DP_Value.click();
	}
	public boolean display_Status_of_Add_User_save() {
		new Actions(driver).moveToElement(Add_User_save).build().perform();
		return Add_User_save.isDisplayed();
	}
	
	public boolean enable_Status_of_Add_User_save() {
		return Add_User_save.isEnabled();
	}
	
	public void tab_on_Add_User_save() throws InterruptedException {
		try {
			Add_User_save.click();
		} catch (Exception e) {
			new Actions(driver).click(Add_User_save).build().perform();
		}
	}
	public boolean display_Status_of_Add_User_Close() {
		new Actions(driver).moveToElement(Add_User_Close).build().perform();
		return Add_User_Close.isDisplayed();
	}
	
	public boolean enable_Status_of_Add_User_Close() {
		return Add_User_Close.isEnabled();
	}
	
	public void tab_on_Add_User_Close() throws InterruptedException {
		try {
			Add_User_Close.click();
		} catch (Exception e) {
			new Actions(driver).click(Add_User_Close).build().perform();
		}
	}
	public boolean display_Status_of_edit() {
		new Actions(driver).moveToElement(edit).build().perform();
		return edit.isDisplayed();
	}
	
	public boolean enable_Status_of_edit() {
		return edit.isEnabled();
	}
	
	public void tab_on_edit() throws InterruptedException {
		try {
			edit.click();
		} catch (Exception e) {
			new Actions(driver).click(edit).build().perform();
		}
	}
	public boolean display_Status_of_edit_Employe_ID() {
		new Actions(driver).moveToElement(Employe_ID).build().perform();
		return Employe_ID.isDisplayed();
	}
	
	public boolean enable_Status_of_edit_Employe_ID() {
		return Employe_ID.isEnabled();
	}
	
	public void tab_on_edit_Employe_ID() throws InterruptedException {
		try {
			Employe_ID.click();
		} catch (Exception e) {
			new Actions(driver).click(Employe_ID).build().perform();
		}
	}
	public boolean display_Status_of_edit_mobile_number() throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).moveToElement(mobile_number).build().perform();
		return mobile_number.isDisplayed();
	}
	
	public boolean enable_Status_of_edit_mobile_number() {
		return mobile_number.isEnabled();
	}
	
	public void tab_on_edit_mobile_number() throws InterruptedException {
		new Actions(driver).click(mobile_number).keyDown(Keys.CONTROL).sendKeys("A").sendKeys("x").build().perform();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("V").sendKeys("x").build().perform();
	}
	public boolean display_Status_of_edit_firstName() {
		new Actions(driver).moveToElement(firstName).build().perform();
		return firstName.isDisplayed();
	}
	
	public boolean enable_Status_of_edit_firstName() {
		return firstName.isEnabled();
	}
	
	public void tab_on_edit_firstName() throws InterruptedException {
		new Actions(driver).click(firstName).keyDown(Keys.CONTROL).sendKeys("A").sendKeys("x").build().perform();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("V").sendKeys("x").build().perform();
	}
	public boolean display_Status_of_edit_lastName() {
		new Actions(driver).moveToElement(lastName).build().perform();
		return lastName.isDisplayed();
	}
	
	public boolean enable_Status_of_edit_lastName() {
		return lastName.isEnabled();
	}
	
	public void tab_on_edit_lastName() throws InterruptedException {
		new Actions(driver).click(lastName).keyDown(Keys.CONTROL).sendKeys("A").sendKeys("x").build().perform();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("V").sendKeys("x").build().perform();
	}
	public boolean display_Status_of_edit_email() {
		new Actions(driver).moveToElement(email).build().perform();
		return lastName.isDisplayed();
	}
	
	public boolean enable_Status_of_edit_email() {
		return email.isEnabled();
	}
	
	public void tab_on_edit_email() throws InterruptedException {
		new Actions(driver).click(email).keyDown(Keys.CONTROL).sendKeys("A").sendKeys("x").build().perform();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("V").sendKeys("x").build().perform();
	}
	public boolean display_Status_of_edit_Role_DP() {
		new Actions(driver).moveToElement(Role_DP).build().perform();
		return lastName.isDisplayed();
	}
	
	public boolean enable_Status_of_edit_Role_DP() {
		return Role_DP.isEnabled();
	}
	
	public void tab_on_edit_Role_DP_and_Select_Dp_value() throws InterruptedException {
		try {
			Role_DP.click();
		} catch (Exception e) {
			new Actions(driver).click(Role_DP).build().perform();
		}
		Thread.sleep(2000);
		try {
			Role_DP_Admin.click();
		} catch (Exception e) {
			new Actions(driver).click(Role_DP_Admin).build().perform();
		}
	}
	public boolean display_Status_of_Edit_Survey_Type_DP() {
		new Actions(driver).moveToElement(Edit_Survey_Type_DP).build().perform();
		return Edit_Survey_Type_DP.isDisplayed();
	}
	
	public boolean enable_Status_of_Edit_Survey_Type_DP() {
		return Edit_Survey_Type_DP.isEnabled();
	}
	
	public void tab_on_Edit_Survey_Type_DP_and_select_dp_value() throws InterruptedException {
		try {
			Edit_Survey_Type_DP.click();
		} catch (Exception e) {
			new Actions(driver).click(Edit_Survey_Type_DP).build().perform();
		}
		Thread.sleep(2000);
		try {
			Survey_Type_DP_Value.click();
		} catch (Exception e) {
			new Actions(driver).click(Survey_Type_DP_Value).build().perform();
		}
	}
	public boolean display_Status_of_Edit_change_pass_checkbox() {
		new Actions(driver).moveToElement(change_pass_checkbox).build().perform();
		return change_pass_checkbox.isDisplayed();
	}
	
	public boolean enable_Status_of_Edit_change_pass_checkbox() {
		return change_pass_checkbox.isEnabled();
	}
	
	public void tab_on_change_pass_checkbox() throws InterruptedException {
		try {
			change_pass_checkbox.click();
		} catch (Exception e) {
			new Actions(driver).click(change_pass_checkbox).build().perform();
		}
	}
	public boolean display_Status_of_Edit_password() throws InterruptedException {
		Thread.sleep(5000);
		new Actions(driver).moveToElement(password).build().perform();
		return password.isDisplayed();
	}
	
	public boolean enable_Status_of_Edit_password() {
		return password.isEnabled();
	}
	
	public void Enter_Edit_password() throws InterruptedException {
		password.click();
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		 jse.executeScript("arguments[0].value='Cognicx@123';", password);
	}
	public boolean display_Status_of_edit_Update() throws InterruptedException {
		Thread.sleep(5000);
		new Actions(driver).moveToElement(edit_Update).build().perform();
		return edit_Update.isDisplayed();
	}
	
	public boolean enable_Status_of_edit_Update() {
		return edit_Update.isEnabled();
	}
	
	public void tab_on_edit_Update() throws InterruptedException {
		try {
			edit_Update.click();
		} catch (Exception e) {
			new Actions(driver).click(edit_Update).build().perform();
		}
	}
	public boolean display_Status_of_edit_Close() throws InterruptedException {
		Thread.sleep(5000);
		new Actions(driver).moveToElement(edit_Close).build().perform();
		return edit_Close.isDisplayed();
	}
	
	public boolean enable_Status_of_edit_Close() {
		return edit_Close.isEnabled();
	}
	
	public void tab_on_edit_Close() throws InterruptedException {
		try {
			edit_Close.click();
		} catch (Exception e) {
			new Actions(driver).click(edit_Close).build().perform();
		}
	}
	public boolean display_Status_of_option() throws InterruptedException {
		Thread.sleep(5000);
		new Actions(driver).moveToElement(option).build().perform();
		return option.isDisplayed();
	}
	
	public boolean enable_Status_of_option() {
		return option.isEnabled();
	}
	
	public void tab_on_option() throws InterruptedException {
		try {
			option.click();
		} catch (Exception e) {
			new Actions(driver).click(option).build().perform();
		}
	}
	public boolean display_Status_of_sign_out() throws InterruptedException {
		Thread.sleep(5000);
		new Actions(driver).moveToElement(sign_out).build().perform();
		return sign_out.isDisplayed();
	}
	
	public boolean enable_Status_of_sign_out() {
		return sign_out.isEnabled();
	}
	
	public void tab_on_sign_out() throws InterruptedException {
		try {
			sign_out.click();
		} catch (Exception e) {
			new Actions(driver).click(sign_out).build().perform();
		}
	}
}
