package PageLayerPackage;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import BaseLayerPackage.Base_Class_CSM;

public class Survey extends Base_Class_CSM {

	@FindBy(xpath = "//div[@class='sidenav _homePage']/ul/li[1]/a/span/i")
	WebElement Survey;

	@FindBy(xpath = "//a[@id='noanim-tab-example-tab-SURVEY_ELEMENTS']")
	WebElement Survey_Element;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[1]/div[1]")
	WebElement Response;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[1]/i")
	WebElement Add_response;

	@FindBy(xpath = "//input[@id='Response']")
	WebElement Enter_response;

	@FindBy(xpath = "//span[text()='Add']")
	WebElement Save_response;

	@FindBy(xpath = "(//div[@class='card-body'])[1]/div[12]/i")
	WebElement Delete_response;

	@FindBy(xpath = "(//div[@class='card-body'])[1]/div[12]/li/i")
	WebElement Edit_response;

	@FindBy(xpath = "(//div[@class='card-body'])[1]/div[12]/li/input")
	WebElement change_response;

	@FindBy(xpath = "//div[text()='Assessed Skill']")
	WebElement assessed_Skill;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[2]/i")
	WebElement Add_assessed_Skill;

	@FindBy(xpath = "//input[@id='Questions']")
	WebElement Enter_assessed_Skill;

	@FindBy(xpath = "//div[@class='collapse show']/div/div/div/span")
	WebElement Save_assessed_Skill;

	@FindBy(xpath = "(//div[@class='card-body'])[2]/div[9]/i")
	WebElement Delete_assessed_Skill;

	@FindBy(xpath = "(//div[@class='card-body'])[2]/div[9]/li/i")
	WebElement Edit_assessed_Skill;

	@FindBy(xpath = "(//div[@class='card-body'])[2]/div[9]/li/input")
	WebElement change_assessed_Skill;

	@FindBy(xpath = "//div[text()='SurveyTypes']")
	WebElement survey_Type;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[3]/i")
	WebElement Add_survey_Type;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[3]/div[2]/div/div[1]/input")
	WebElement Enter_survey_Type;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[3]/div[2]/div/div[1]/div/span")
	WebElement Save_survey_Type;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[3]/div[2]/div/div[5]/i")
	WebElement Delete_survey_Type;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[3]/div[2]/div/div[5]/li/i")
	WebElement Edit_survey_Type;

	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-SURVEY_ELEMENTS']/div/div[3]/div[2]/div/div[5]/li/input")
	WebElement change_survey_Type;

	@FindBy(xpath = "//button[text()='SAVE']")
	WebElement Save_Survey_Element;

	@FindBy(xpath = "//a[@id='noanim-tab-example-tab-SURVEY_TEMPLATE']")
	WebElement Save_Survey_Template;

	@FindBy(xpath = "//button[text()='Create Template']")
	WebElement create_Template;

	@FindBy(xpath = "(//select[@id='Questions'])[1]")
	WebElement questionary_Select_question;

	@FindBy(xpath = "(//textarea[@id='description'])[1]")
	WebElement questionary_discription;

	@FindBy(xpath = "((//table[@class='table table-sm table-bordered']//tr)[2]/td[3]/input)[1]")
	WebElement questionary_FileName;

	@FindBy(xpath = "((//table[@class='table table-sm table-bordered']//tr)[2]/td[4]/div/div/label[1]/input)[1]")
	WebElement questionary_Min_Score;

	@FindBy(xpath = "((//table[@class='table table-sm table-bordered']//tr)[2]/td[4]/div/div/label[2]/input)[1]")
	WebElement questionary_Max_Score;

	@FindBy(xpath = "((//table[@class='table table-sm table-bordered']//tr)[2]/td[5]/center/b)[1]")
	WebElement questionary_Response_Mapping;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[5]/input")
	WebElement questionary_Response_1;

	@FindBy(xpath = "//div[@role='list']/span[1]")
	WebElement questionary_Response_1_Excellent;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[10]/input")
	WebElement questionary_Response_2;

	@FindBy(xpath = "//div[@role='list']/span[2]")
	WebElement questionary_Response_2_Good;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[15]/input")
	WebElement questionary_Response_3;

	@FindBy(xpath = "//div[@role='list']/span[3]")
	WebElement questionary_Response_3_Very_Good;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[20]/input")
	WebElement questionary_Response_4;

	@FindBy(xpath = "//div[@role='list']/span[4]")
	WebElement questionary_Response_4_Poor;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[25]/input")
	WebElement questionary_Response_5;

	@FindBy(xpath = "//div[@role='list']/span[5]")
	WebElement questionary_Response_5_Very_Poor;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[30]/input")
	WebElement questionary_Response_6;

	@FindBy(xpath = "//div[@role='list']/span[8]")
	WebElement questionary_Response_6_Satisfied;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[35]/input")
	WebElement questionary_Response_7;

	@FindBy(xpath = "//div[@role='list']/span[9]")
	WebElement questionary_Response_7_Not_Stisfied;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[40]/input")
	WebElement questionary_Response_8;

	@FindBy(xpath = "//div[@role='list']/span[10]")
	WebElement questionary_Response_8_Fabulous;

	@FindBy(xpath = "(//div[@class='modal-body']//div)[45]/input")
	WebElement questionary_Response_9;

	@FindBy(xpath = "//div[@role='list']/span[11]")
	WebElement questionary_Response_1_Very_Very_Bad;

	@FindBy(xpath = "//button[text()='BACK']")
	WebElement Back;

	@FindBy(xpath = "//button[text()='Save']")
	WebElement Save;

	@FindBy(xpath = "//b[text()='GENERAL CONFIGURATIONS']")
	WebElement General_Configuration;

	@FindBy(xpath = "(//input[@data-test='input'])[1]")
	WebElement General_Configuration_Number_of_Tries;

	@FindBy(xpath = "(//input[@data-test='input'])[2]")
	WebElement General_Configuration_Max_Time_out;

	@FindBy(xpath = "(//input[@data-test='input'])[3]")
	WebElement General_Configuration_Prompt_Path;

	@FindBy(xpath = "(//input[@data-test='input'])[4]")
	WebElement General_Configuration_Prompt_File_Name;

	@FindBy(xpath = "(//input[@data-test='input'])[5]")
	WebElement General_Configuration_SurveyDiscription_File_Name;

	@FindBy(xpath = "(//input[@data-test='input'])[6]")
	WebElement General_Configuration_Wlcm_msg_File_Name;

	@FindBy(xpath = "(//input[@data-test='input'])[7]")
	WebElement General_Configuration_thankYou_msg_File_Name;

	@FindBy(xpath = "(//input[@data-test='input'])[8]")
	WebElement General_Configuration_No_Input_msg_File_Name;

	@FindBy(xpath = "(//input[@data-test='input'])[9]")
	WebElement General_Configuration_No_match_msg_File_Name;

	@FindBy(xpath = "(//input[@data-test='input'])[10]")
	WebElement General_Configuration_Max_error_prompt;
	
	@FindBy(xpath = "//button[text()='Close']")
	WebElement close;
	
	@FindBy(xpath = "//button[text()='SAVE']")
	WebElement save;
	
	@FindBy(xpath = "(//div[@class='table-responsive']//i)[1]")
	WebElement edit;
	
	@FindBy(xpath = "(//div[@class='table-responsive']//i)[2]")
	WebElement view;
	
	@FindBy(xpath = "(//div[@class='table-responsive']//i)[2]")
	WebElement close_view;
	
	@FindBy(xpath = "(//span[text()='Next'])[1]")
	WebElement Next;
	
	@FindBy(xpath = "(//span[text()='Previous'])[1]")
	WebElement previous;
	
	@FindBy(xpath = "//a[text()='Survey Form Mapping']")
	WebElement Survey_Form_Mapping;
	
	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-FORM_MAPPING']/div[1]/div[1]/div[2]/div/div/div[3]")
	WebElement select_survey;
	
	@FindBy(xpath = "//div[@role='list']/span")
	WebElement General_survey;
	
	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-FORM_MAPPING']/div[1]/div[2]/div[2]/div/div/div[3]")
	WebElement survey_template_name;
	
	@FindBy(xpath = "//div[@role='list']/span[2]")
	WebElement loan_agency_survey;
	
	@FindBy(xpath = "//button[text()='UPDATE']")
	WebElement Survey_Form_Mapping_Update;
	
	@FindBy(xpath = "//a[text()='Mapped Survey Forms']")
	WebElement Mapped_Survey_Forms;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-MAPPED_FORMS']//div)[6]//tr/td[4]/i")
	WebElement replace;
	
	@FindBy(xpath = "//div[@class='margingap']/div[2]/div[2]//div/div[3]")
	WebElement template_name;
	
	@FindBy(xpath = "//div[@role='list']/span[2]")
	WebElement Loan_agency_survey;
	
	@FindBy(xpath = "//button[text()='Replace Template']")
	WebElement replace_template;
	
	@FindBy(xpath = "//span[text()='Close']")
	WebElement close_reassigned_template;
	
	@FindBy(xpath = "(//div[@id='noanim-tab-example-tabpane-MAPPED_FORMS']//div)[6]//tr/td[3]/i")
	WebElement view_mapped_survey_form;
	
	@FindBy(xpath = "//span[text()='Close']")
	WebElement close_view_template;
	
	@FindBy(xpath = "//a[text()='IVR Extensions Mapping']")
	WebElement IVR_Extensions_Mapping;
	
	@FindBy(xpath = "//div[@id='noanim-tab-example-tabpane-IVR_EXTENSION_MAPPING']/div/span/i")
	WebElement IVR_Extensions_Mapping_edit;
	
	@FindBy(xpath = "//input[@id='ivrExtensionsValue'][1]")
	WebElement IVR_Extensions_Mapping_Number1;
	
	@FindBy(xpath = "(//input[@id='ivrExtensionsValue'])[2]")
	WebElement IVR_Extensions_Mapping_Number2;
	
	@FindBy(xpath = "//button[text()='Save']")
	WebElement IVR_Extensions_Mapping_Save;
	

	public Survey() {
		PageFactory.initElements(driver, this);
	}

	public boolean display_Status_of_Survey() {
		return Survey.isDisplayed();
	}

	public boolean enable_Status_of_Survey() {
		return Survey.isEnabled();
	}

	public void click_on_Survey() {
		Survey.click();
	}

	public boolean display_Status_of_Survey_Element() {
		return Survey_Element.isDisplayed();
	}

	public boolean enable_Status_of_Survey_Element() {
		return Survey_Element.isEnabled();
	}

	public void click_on_Survey_Element() {
		Survey_Element.click();
	}

	public boolean display_Status_of_Response() {
		return Response.isDisplayed();
	}

	public boolean enable_Status_of_Response() {
		return Response.isEnabled();
	}

	public void click_on_Response() {
		Response.click();
	}

	public boolean display_Status_of_Add_response() throws InterruptedException {
		return Add_response.isDisplayed();
	}

	public boolean enable_Status_of_Add_response() {
		return Add_response.isEnabled();
	}

	public void click_on_Add_response() {
		Add_response.click();
	}

	public boolean display_Status_of_Enter_response() {
		return Enter_response.isDisplayed();
	}

	public boolean enable_Status_of_Enter_response() {
		return Enter_response.isEnabled();
	}

	public void Enter_response(String enter_response) {
		Enter_response.sendKeys(enter_response);
	}

	public boolean display_Status_of_Save_response() {
		return Save_response.isDisplayed();
	}

	public boolean enable_Status_of_Save_response() {
		return Save_response.isEnabled();
	}

	public void Tab_on_Save_response() {
		Save_response.click();
	}

	public boolean display_Status_of_Edit_response() {
		new Actions(driver).moveToElement(Edit_response).build().perform();
		return Edit_response.isDisplayed();
	}

	public boolean enable_Status_of_Edit_response() {
		return Edit_response.isEnabled();
	}

	public void Tab_on_Edit_response() throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).click(Edit_response).build().perform();
	}

	public boolean display_Status_of_change_response() {
		return change_response.isDisplayed();
	}

	public boolean enable_Status_of_change_response() {
		return change_response.isEnabled();
	}

	public void Tab_on_change_response_and_change_text(String response) throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).click(change_response).build().perform();
		Thread.sleep(2000);
		change_response.clear();
		Thread.sleep(2000);
		change_response.sendKeys(response);
	}

	public boolean display_Status_of_Delete_response() {
		return Delete_response.isDisplayed();
	}

	public boolean enable_Status_of_Delete_response() {
		return Delete_response.isEnabled();
	}

	public void Tab_on_Delete_response() throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).click(Delete_response).build().perform();
		Thread.sleep(2000);
		new Actions(driver).click(Delete_response).build().perform();
	}

	public boolean display_Status_of_assessed_Skill() {
		return assessed_Skill.isDisplayed();
	}

	public boolean enable_Status_of_assessed_Skill() {
		return assessed_Skill.isEnabled();
	}

	public void Tab_on_assessed_Skill() throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).click(assessed_Skill).build().perform();
	}

	public boolean display_Status_of_Add_assessed_Skill() {
		new Actions(driver).moveToElement(Add_assessed_Skill).build().perform();
		return Add_assessed_Skill.isDisplayed();
	}

	public boolean enable_Status_of_Add_assessed_Skill() {
		return Add_assessed_Skill.isEnabled();
	}

	public void Tab_on_Add_assessed_Skill() throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).click(Add_assessed_Skill).build().perform();
	}

	public boolean display_Status_of_Enter_assessed_Skill() {
		return Enter_assessed_Skill.isDisplayed();
	}

	public boolean enable_Status_of_Enter_assessed_Skill() {
		return Enter_assessed_Skill.isEnabled();
	}

	public void Enter_assessed_Skill(String enter_assessed_Skill) throws InterruptedException {
		Thread.sleep(2000);
		Enter_assessed_Skill.sendKeys(enter_assessed_Skill);
	}

	public boolean display_Status_of_Save_assessed_Skill() {
		return Save_assessed_Skill.isDisplayed();
	}

	public boolean enable_Status_of_Save_assessed_Skill() {
		return Save_assessed_Skill.isEnabled();
	}

	public void Tab_On_Save_assessed_Skill() throws InterruptedException {
		Thread.sleep(2000);
		Save_assessed_Skill.click();
	}

	public boolean display_Status_of_Edit_assessed_Skill() {
		return Edit_assessed_Skill.isDisplayed();
	}

	public boolean enable_Status_of_Edit_assessed_Skill() {
		return Edit_assessed_Skill.isEnabled();
	}

	public void Tab_On_Edit_assessed_Skill() throws InterruptedException {
		Thread.sleep(2000);
		Edit_assessed_Skill.click();
	}

	public boolean display_Status_of_change_assessed_Skill() {
		return change_assessed_Skill.isDisplayed();
	}

	public boolean enable_Status_of_change_assessed_Skill() {
		return change_assessed_Skill.isEnabled();
	}

	public void Tab_On_change_assessed_Skill_clear_and_again_enter() throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).click(change_assessed_Skill).keyDown(Keys.CONTROL).sendKeys("A").sendKeys("C")
				.keyUp(Keys.CONTROL).build().perform();
		Thread.sleep(2000);
		change_assessed_Skill.clear();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).build().perform();
	}

	public boolean display_Status_of_Delete_assessed_Skill() {
		return Delete_assessed_Skill.isDisplayed();
	}

	public boolean enable_Status_of_Delete_assessed_Skill() {
		return Delete_assessed_Skill.isEnabled();
	}

	public void Tab_on_Delete_assessed_Skill() throws InterruptedException {
		Delete_assessed_Skill.click();
		Thread.sleep(2000);
		Delete_assessed_Skill.click();
	}

	public boolean display_Status_of_survey_Type() {
		return survey_Type.isDisplayed();
	}

	public boolean enable_Status_of_survey_Type() {
		return survey_Type.isEnabled();
	}

	public void Tab_on_survey_Type() throws InterruptedException {
		survey_Type.click();
	}

	public boolean display_Status_of_Add_survey_Type() {
		new Actions(driver).moveToElement(Add_survey_Type).build().perform();
		return Add_survey_Type.isDisplayed();
	}

	public boolean enable_Status_of_Add_survey_Type() {
		return Add_survey_Type.isEnabled();
	}

	public void Tab_on_Add_survey_Type() throws InterruptedException {
		Add_survey_Type.click();
	}

	public boolean display_Status_of_Enter_survey_Type() throws InterruptedException {
		Thread.sleep(2000);
		return Enter_survey_Type.isDisplayed();
	}

	public boolean enable_Status_of_Enter_survey_Type() {
		return Enter_survey_Type.isEnabled();
	}

	public void Enter_survey_Type(String enter_survey_Type) throws InterruptedException {
		Enter_survey_Type.sendKeys(enter_survey_Type);
	}

	public boolean display_Status_of_Save_survey_Type() {
		return Save_survey_Type.isDisplayed();
	}

	public boolean enable_Status_of_Save_survey_Type() {
		return Save_survey_Type.isEnabled();
	}

	public void Tab_on_Save_survey_Type() throws InterruptedException {
		Save_survey_Type.click();
	}

	public boolean display_Status_of_Edit_survey_Type() {
		new Actions(driver).moveToElement(Edit_survey_Type).build().perform();
		return Edit_survey_Type.isDisplayed();
	}

	public boolean enable_Status_of_Edit_survey_Type() {
		return Edit_survey_Type.isEnabled();
	}

	public void Tab_on_Edit_survey_Type() throws InterruptedException {
		Edit_survey_Type.click();
	}

	public boolean display_Status_of_change_survey_Type() {
		return change_survey_Type.isDisplayed();
	}

	public boolean enable_Status_of_change_survey_Type() {
		return change_survey_Type.isEnabled();
	}

	public void Enter_change_survey_Type() throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).click(change_survey_Type).keyDown(Keys.CONTROL).sendKeys("A").sendKeys("C")
				.keyUp(Keys.CONTROL).build().perform();
		Thread.sleep(2000);
		change_survey_Type.clear();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).build().perform();
	}

	public boolean display_Status_of_Delete_survey_Type() {
		return Delete_survey_Type.isDisplayed();
	}

	public boolean enable_Status_of_Delete_survey_Type() {
		return Delete_survey_Type.isEnabled();
	}

	public void Tab_on_Delete_survey_Type() throws InterruptedException {
		Thread.sleep(2000);
		Delete_survey_Type.click();
		Thread.sleep(2000);
		Delete_survey_Type.click();
	}

	public boolean display_Status_of_Save_Survey_Element() {
		return Save_Survey_Element.isDisplayed();
	}

	public boolean enable_Status_of_Save_Survey_Element() {
		return Save_Survey_Element.isEnabled();
	}

	public void Tab_on_Save_Survey_Element() throws InterruptedException {
		Thread.sleep(2000);
		Save_Survey_Element.click();
	}

	public boolean display_Status_of_Save_Survey_Template() {
		return Save_Survey_Template.isDisplayed();
	}

	public boolean enable_Status_of_Save_Survey_Template() {
		return Save_Survey_Template.isEnabled();
	}

	public void Tab_on_Save_Survey_Template() throws InterruptedException {
		Thread.sleep(2000);
		Save_Survey_Template.click();
	}

	public boolean display_Status_of_create_Template() {
		new Actions(driver).moveToElement(create_Template).build().perform();
		return create_Template.isDisplayed();
	}

	public boolean enable_Status_of_create_Template() throws InterruptedException {
		Thread.sleep(5000);
		return create_Template.isEnabled();
	}

	public void Tab_on_create_Template() throws InterruptedException {
		Thread.sleep(2000);
		create_Template.click();
	}

	public boolean display_Status_of_questionary_Select_question() {
		return questionary_Select_question.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Select_question() {
		return questionary_Select_question.isEnabled();
	}

	public void Tab_on_questionary_Select_question_and_select_question() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Select_question.click();
		Thread.sleep(2000);
		new Select(questionary_Select_question).selectByIndex(5);
		Thread.sleep(2000);
		questionary_Select_question.click();
	}

	public boolean display_Status_of_questionary_discription() {
		return questionary_discription.isDisplayed();
	}

	public boolean enable_Status_of_questionary_discription() {
		return questionary_discription.isEnabled();
	}

	public void Tab_on_questionary_discription_and_enter_data(String Questionary_discription)
			throws InterruptedException {
		Thread.sleep(2000);
		questionary_discription.click();
		Thread.sleep(2000);
		questionary_discription.sendKeys(Questionary_discription);
	}

	public boolean display_Status_of_questionary_FileName() {
		return questionary_FileName.isDisplayed();
	}

	public boolean enable_Status_of_questionary_FileName() {
		return questionary_FileName.isEnabled();
	}

	public void Tab_on_questionary_FileName_and_enter_FileName(String Questionary_FileName)
			throws InterruptedException {
		Thread.sleep(2000);
		questionary_FileName.click();
		Thread.sleep(2000);
		questionary_FileName.sendKeys(Questionary_FileName);
	}

	public boolean display_Status_of_questionary_Min_Score() {
		return questionary_Min_Score.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Min_Score() {
		return questionary_Min_Score.isEnabled();
	}

	public void Tab_on_questionary_Min_Score_and_enter_questionary_Min_Score(String Questionary_Min_Score)
			throws InterruptedException {
		Thread.sleep(2000);
		questionary_Min_Score.click();
		Thread.sleep(2000);
		questionary_Min_Score.sendKeys(Questionary_Min_Score);
	}

	public boolean display_Status_of_questionary_Max_Score() {
		return questionary_Max_Score.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Max_Score() {
		return questionary_Max_Score.isEnabled();
	}

	public void Tab_on_questionary_Max_Score_and_enter_questionary_Max_Score(String Questionary_Max_Score)
			throws InterruptedException {
		Thread.sleep(2000);
		questionary_Max_Score.click();
		Thread.sleep(1000);
		questionary_Max_Score.clear();
		Thread.sleep(2000);
		questionary_Max_Score.sendKeys(Questionary_Max_Score);
	}

	public boolean display_Status_of_questionary_Response_Mapping() {
		return questionary_Response_Mapping.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_Mapping() {
		return questionary_Response_Mapping.isEnabled();
	}

	public void Tab_on_questionary_Response_Mapping() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_Mapping.click();
	}

	public boolean display_Status_of_questionary_Response_1() {
		return questionary_Response_1.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_1() {
		return questionary_Response_1.isEnabled();
	}

	public void Tab_on_questionary_Response_1_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_1.click();
		Thread.sleep(2000);
		questionary_Response_1_Excellent.click();
	}

	public boolean display_Status_of_questionary_Response_2() {
		return questionary_Response_2.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_2() {
		return questionary_Response_2.isEnabled();
	}

	public void Tab_on_questionary_Response_2_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_2.click();
		Thread.sleep(2000);
		questionary_Response_2_Good.click();
	}

	public boolean display_Status_of_questionary_Response_3() {
		return questionary_Response_3.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_3() {
		return questionary_Response_3.isEnabled();
	}

	public void Tab_on_questionary_Response_3_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_3.click();
		Thread.sleep(2000);
		questionary_Response_3_Very_Good.click();
	}

	public boolean display_Status_of_questionary_Response_4() {
		return questionary_Response_4.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_4() {
		return questionary_Response_4.isEnabled();
	}

	public void Tab_on_questionary_Response_4_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_4.click();
		Thread.sleep(2000);
		questionary_Response_4_Poor.click();
	}

	public boolean display_Status_of_questionary_Response_5() {
		return questionary_Response_5.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_5() {
		return questionary_Response_5.isEnabled();
	}

	public void Tab_on_questionary_Response_5_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_5.click();
		Thread.sleep(2000);
		questionary_Response_5_Very_Poor.click();
	}

	public boolean display_Status_of_questionary_Response_6() {
		return questionary_Response_6.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_6() {
		return questionary_Response_6.isEnabled();
	}

	public void Tab_on_questionary_Response_6_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_6.click();
		Thread.sleep(2000);
		questionary_Response_6_Satisfied.click();
	}

	public boolean display_Status_of_questionary_Response_7() {
		return questionary_Response_7.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_7() {
		return questionary_Response_7.isEnabled();
	}

	public void Tab_on_questionary_Response_7_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_7.click();
		Thread.sleep(2000);
		questionary_Response_7_Not_Stisfied.click();
	}

	public boolean display_Status_of_questionary_Response_8() {
		return questionary_Response_8.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_8() {
		return questionary_Response_8.isEnabled();
	}

	public void Tab_on_questionary_Response_8_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_8.click();
		Thread.sleep(2000);
		questionary_Response_8_Fabulous.click();
	}

	public boolean display_Status_of_questionary_Response_9() {
		return questionary_Response_9.isDisplayed();
	}

	public boolean enable_Status_of_questionary_Response_9() {
		return questionary_Response_9.isEnabled();
	}

	public void Tab_on_questionary_Response_9_And_Select_Reponse_Value() throws InterruptedException {
		Thread.sleep(2000);
		questionary_Response_9.click();
		Thread.sleep(2000);
		questionary_Response_1_Very_Very_Bad.click();
	}

	public boolean display_Status_of_Back() {
		new Actions(driver).moveToElement(Back).build().perform();
		return Back.isDisplayed();
	}

	public boolean enable_Status_of_Back() {
		return Back.isEnabled();
	}

	public void Tab_on_Back() throws InterruptedException {
		Thread.sleep(2000);
		Back.click();
	}

	public boolean display_Status_of_Save() {
		new Actions(driver).moveToElement(Save).build().perform();
		return Save.isDisplayed();
	}

	public boolean enable_Status_of_Save() {
		return Save.isEnabled();
	}

	public void Tab_on_Save() throws InterruptedException {
		Thread.sleep(2000);
		Save.click();
	}

	public boolean display_Status_of_General_Configuration() {
		new Actions(driver).moveToElement(General_Configuration).build().perform();
		return General_Configuration.isDisplayed();
	}

	public boolean enable_Status_of_General_Configuration() {
		return General_Configuration.isEnabled();
	}

	public void Tab_on_General_Configuration() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration.click();
	}
	public boolean display_Status_of_General_Configuration_Number_of_Tries() {
		return General_Configuration_Number_of_Tries.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_Number_of_Tries() {
		return General_Configuration_Number_of_Tries.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_Number_of_Tries() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_Number_of_Tries.sendKeys("5");
	}
	public boolean display_Status_of_General_Configuration_Max_Time_out() {
		return General_Configuration_Max_Time_out.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_Max_Time_out() {
		return General_Configuration_Max_Time_out.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_Max_Time_out() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_Max_Time_out.sendKeys("5");
	}
	public boolean display_Status_of_General_Configuration_Prompt_Path() {
		return General_Configuration_Prompt_Path.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_Prompt_Path() {
		return General_Configuration_Prompt_Path.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_Prompt_Path() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_Prompt_Path.sendKeys("File Path");
	}
	public boolean display_Status_of_General_Configuration_Prompt_File_Name() {
		return General_Configuration_Prompt_File_Name.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_Prompt_File_Name() {
		return General_Configuration_Prompt_File_Name.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_Prompt_File_Name() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_Prompt_File_Name.sendKeys("Prompt.wav");
	}
	public boolean display_Status_of_General_Configuration_SurveyDiscription_File_Name() {
		return General_Configuration_SurveyDiscription_File_Name.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_SurveyDiscription_File_Name() {
		return General_Configuration_SurveyDiscription_File_Name.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_SurveyDiscription_File_Name() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_SurveyDiscription_File_Name.sendKeys("Survey_Discription.wav");
	}
	public boolean display_Status_of_General_Configuration_Wlcm_msg_File_Name() {
		return General_Configuration_Wlcm_msg_File_Name.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_Wlcm_msg_File_Name() {
		return General_Configuration_Wlcm_msg_File_Name.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_Wlcm_msg_File_Name() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_Wlcm_msg_File_Name.sendKeys("Welcome.wav");
	}
	public boolean display_Status_of_General_Configuration_thankYou_msg_File_Name() {
		return General_Configuration_thankYou_msg_File_Name.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_thankYou_msg_File_Name() {
		return General_Configuration_thankYou_msg_File_Name.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_thankYou_msg_File_Name() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_thankYou_msg_File_Name.sendKeys("Thank_You.wav");
	}
	public boolean display_Status_of_General_Configuration_No_Input_msg_File_Name() {
		return General_Configuration_No_Input_msg_File_Name.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_No_Input_msg_File_Name() {
		return General_Configuration_No_Input_msg_File_Name.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_No_Input_msg_File_Name() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_No_Input_msg_File_Name.sendKeys("No_Input.wav");
	}
	public boolean display_Status_of_General_Configuration_No_match_msg_File_Name() {
		return General_Configuration_No_match_msg_File_Name.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_No_match_msg_File_Name() {
		return General_Configuration_No_match_msg_File_Name.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_No_match_msg_File_Name() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_No_match_msg_File_Name.sendKeys("No_Match.wav");
	}
	public boolean display_Status_of_General_Configuration_Max_error_prompt() {
		return General_Configuration_Max_error_prompt.isDisplayed();
	}
	
	public boolean enable_Status_of_General_Configuration_Max_error_prompt() {
		return General_Configuration_Max_error_prompt.isEnabled();
	}
	
	public void Enter_data_in_General_Configuration_Max_error_prompt() throws InterruptedException {
		Thread.sleep(5000);
		General_Configuration_Max_error_prompt.sendKeys("Max_Error.wav");
	}
	public boolean display_Status_of_close() {
		return close.isDisplayed();
	}
	
	public boolean enable_Status_of_close() {
		return close.isEnabled();
	}
	
	public void Tab_on_close() throws InterruptedException {
		Thread.sleep(5000);
		close.click();
	}
	public boolean display_Status_of_save() {
		return save.isDisplayed();
	}
	
	public boolean enable_Status_of_save() {
		return save.isEnabled();
	}
	
	public void Tab_on_save() throws InterruptedException {
		Thread.sleep(5000);
		save.click();
	}
	public boolean display_Status_of_edit() {
		return edit.isDisplayed();
	}
	
	public boolean enable_Status_of_edit() {
		return edit.isEnabled();
	}
	
	public void Tab_on_edit() throws InterruptedException {
		Thread.sleep(5000);
		edit.click();
	}
	public boolean display_Status_of_view() {
		return view.isDisplayed();
	}
	
	public boolean enable_Status_of_view() {
		return view.isEnabled();
	}
	
	public void Tab_on_view() throws InterruptedException {
		Thread.sleep(5000);
		view.click();
	}
	public boolean display_Status_of_close_view() {
		new Actions(driver).moveToElement(close_view).build().perform();
		return close_view.isDisplayed();
	}
	
	public boolean enable_Status_of_close_view() {
		return close_view.isEnabled();
	}
	
	public void Tab_on_close_view() throws InterruptedException {
		Thread.sleep(5000);
		try {
			close_view.click();
		} catch (Exception e) {
			new Actions(driver).click(close_view).build().perform();
		}
	}
	public boolean display_Status_of_Next() {
		new Actions(driver).moveToElement(Next).build().perform();
		return Next.isDisplayed();
	}
	
	public boolean enable_Status_of_Next() {
		return Next.isEnabled();
	}
	
	public void Tab_on_Next() throws InterruptedException {
		Thread.sleep(5000);
		try {
			Next.click();
		} catch (Exception e) {
			new Actions(driver).click(Next).build().perform();
		}
	}
	public boolean display_Status_of_previous() {
		new Actions(driver).moveToElement(previous).build().perform();
		return previous.isDisplayed();
	}
	
	public boolean enable_Status_of_previous() {
		return previous.isEnabled();
	}
	
	public void Tab_on_previous() throws InterruptedException {
		Thread.sleep(5000);
		try {
			previous.click();
		} catch (Exception e) {
			new Actions(driver).click(previous).build().perform();
		}
	}
	public boolean display_Status_of_Survey_Form_Mapping() {
		new Actions(driver).moveToElement(Survey_Form_Mapping).build().perform();
		return Survey_Form_Mapping.isDisplayed();
	}
	
	public boolean enable_Status_of_Survey_Form_Mapping() {
		return Survey_Form_Mapping.isEnabled();
	}
	
	public void Tab_on_Survey_Form_Mapping() throws InterruptedException {
		Thread.sleep(5000);
		try {
			Survey_Form_Mapping.click();
		} catch (Exception e) {
			new Actions(driver).click(Survey_Form_Mapping).build().perform();
		}
	}
	public boolean display_Status_of_select_survey() {
		new Actions(driver).moveToElement(select_survey).build().perform();
		return select_survey.isDisplayed();
	}
	
	public boolean enable_Status_of_select_survey() {
		return select_survey.isEnabled();
	}
	
	public void Tab_on_select_survey() throws InterruptedException {
		Thread.sleep(5000);
		try {
			select_survey.click();
		} catch (Exception e) {
			new Actions(driver).click(select_survey).build().perform();
		}
	}
	public boolean display_Status_of_General_survey() {
		new Actions(driver).moveToElement(General_survey).build().perform();
		return General_survey.isDisplayed();
	}
	
	public boolean enable_Status_of_General_survey() {
		return General_survey.isEnabled();
	}
	
	public void Tab_on_General_survey() throws InterruptedException {
		Thread.sleep(5000);
		try {
			General_survey.click();
		} catch (Exception e) {
			new Actions(driver).click(General_survey).build().perform();
		}
	}
	public boolean display_Status_of_survey_template_name() {
		new Actions(driver).moveToElement(survey_template_name).build().perform();
		return survey_template_name.isDisplayed();
	}
	
	public boolean enable_Status_of_survey_template_name() {
		return survey_template_name.isEnabled();
	}
	
	public void Tab_on_survey_template_name() throws InterruptedException {
		Thread.sleep(5000);
		try {
			survey_template_name.click();
		} catch (Exception e) {
			new Actions(driver).click(survey_template_name).build().perform();
		}
	}
	public boolean display_Status_of_loan_agency_survey() {
		new Actions(driver).moveToElement(loan_agency_survey).build().perform();
		return loan_agency_survey.isDisplayed();
	}
	
	public boolean enable_Status_of_loan_agency_survey() {
		return loan_agency_survey.isEnabled();
	}
	
	public void Tab_on_loan_agency_survey() throws InterruptedException {
		Thread.sleep(5000);
		try {
			loan_agency_survey.click();
		} catch (Exception e) {
			new Actions(driver).click(loan_agency_survey).build().perform();
		}
	}
	public boolean display_Status_of_Survey_Form_Mapping_Update() {
		new Actions(driver).moveToElement(Survey_Form_Mapping_Update).build().perform();
		return Survey_Form_Mapping_Update.isDisplayed();
	}
	
	public boolean enable_Status_of_Survey_Form_Mapping_Update() {
		return Survey_Form_Mapping_Update.isEnabled();
	}
	
	public void Tab_on_Survey_Form_Mapping_Update() throws InterruptedException {
		Thread.sleep(5000);
		try {
			Survey_Form_Mapping_Update.click();
		} catch (Exception e) {
			new Actions(driver).click(Survey_Form_Mapping_Update).build().perform();
		}
	}
	public boolean display_Status_of_Mapped_Survey_Forms() {
		new Actions(driver).moveToElement(Mapped_Survey_Forms).build().perform();
		return Mapped_Survey_Forms.isDisplayed();
	}
	
	public boolean enable_Status_of_Mapped_Survey_Forms() {
		return Mapped_Survey_Forms.isEnabled();
	}
	
	public void Tab_on_Mapped_Survey_Forms() throws InterruptedException {
		Thread.sleep(5000);
		try {
			Mapped_Survey_Forms.click();
		} catch (Exception e) {
			new Actions(driver).click(Mapped_Survey_Forms).build().perform();
		}
	}
	public boolean display_Status_of_replace() {
		new Actions(driver).moveToElement(replace).build().perform();
		return replace.isDisplayed();
	}
	
	public boolean enable_Status_of_replace() {
		return replace.isEnabled();
	}
	
	public void Tab_on_replace() throws InterruptedException {
		Thread.sleep(5000);
		try {
			replace.click();
		} catch (Exception e) {
			new Actions(driver).click(replace).build().perform();
		}
	}
	public boolean display_Status_of_template_name() {
		new Actions(driver).moveToElement(template_name).build().perform();
		return template_name.isDisplayed();
	}
	
	public boolean enable_Status_of_template_name() {
		return template_name.isEnabled();
	}
	
	public void Tab_on_template_name() throws InterruptedException {
		Thread.sleep(5000);
		try {
			template_name.click();
		} catch (Exception e) {
			new Actions(driver).click(template_name).build().perform();
		}
	}
	public boolean display_Status_of_Loan_agency_survey() {
		new Actions(driver).moveToElement(Loan_agency_survey).build().perform();
		return Loan_agency_survey.isDisplayed();
	}
	
	public boolean enable_Status_of_Loan_agency_survey() {
		return Loan_agency_survey.isEnabled();
	}
	
	public void Tab_on_Loan_agency_survey() throws InterruptedException {
		Thread.sleep(5000);
		try {
			Loan_agency_survey.click();
		} catch (Exception e) {
			new Actions(driver).click(Loan_agency_survey).build().perform();
		}
	}
	public boolean display_Status_of_replace_template() {
		new Actions(driver).moveToElement(replace_template).build().perform();
		return replace_template.isDisplayed();
	}
	
	public boolean enable_Status_of_replace_template() {
		return replace_template.isEnabled();
	}
	
	public void Tab_on_replace_template() throws InterruptedException {
		Thread.sleep(5000);
		try {
			replace_template.click();
		} catch (Exception e) {
			new Actions(driver).click(replace_template).build().perform();
		}
	}
	public boolean display_Status_of_close_reassigned_template() {
		new Actions(driver).moveToElement(close_reassigned_template).build().perform();
		return close_reassigned_template.isDisplayed();
	}
	
	public boolean enable_Status_of_close_reassigned_template() {
		return close_reassigned_template.isEnabled();
	}
	
	public void Tab_on_close_reassigned_template() throws InterruptedException {
		Thread.sleep(5000);
		try {
			close_reassigned_template.click();
		} catch (Exception e) {
			new Actions(driver).click(close_reassigned_template).build().perform();
		}
	}
	public boolean display_Status_of_view_mapped_survey_form() {
		new Actions(driver).moveToElement(view_mapped_survey_form).build().perform();
		return view_mapped_survey_form.isDisplayed();
	}
	
	public boolean enable_Status_of_view_mapped_survey_form() {
		return view_mapped_survey_form.isEnabled();
	}
	
	public void Tab_on_view_mapped_survey_form() throws InterruptedException {
		Thread.sleep(5000);
		try {
			view_mapped_survey_form.click();
		} catch (Exception e) {
			new Actions(driver).click(view_mapped_survey_form).build().perform();
		}
	}
	public boolean display_Status_of_close_view_template() {
		new Actions(driver).moveToElement(close_view_template).build().perform();
		return close_view_template.isDisplayed();
	}
	
	public boolean enable_Status_of_close_view_template() {
		return close_view_template.isEnabled();
	}
	
	public void Tab_on_close_view_template() throws InterruptedException {
		Thread.sleep(5000);
		try {
			close_view_template.click();
		} catch (Exception e) {
			new Actions(driver).click(close_view_template).build().perform();
		}
	}
	public boolean display_Status_of_IVR_Extensions_Mapping() {
		new Actions(driver).moveToElement(IVR_Extensions_Mapping).build().perform();
		return IVR_Extensions_Mapping.isDisplayed();
	}
	
	public boolean enable_Status_of_IVR_Extensions_Mapping() {
		return IVR_Extensions_Mapping.isEnabled();
	}
	
	public void Tab_on_close_IVR_Extensions_Mapping() throws InterruptedException {
		Thread.sleep(5000);
		try {
			IVR_Extensions_Mapping.click();
		} catch (Exception e) {
			new Actions(driver).click(IVR_Extensions_Mapping).build().perform();
		}
	}
	public boolean display_Status_of_IVR_Extensions_Mapping_edit() {
		new Actions(driver).moveToElement(IVR_Extensions_Mapping_edit).build().perform();
		return IVR_Extensions_Mapping_edit.isDisplayed();
	}
	
	public boolean enable_Status_of_IVR_Extensions_Mapping_edit() {
		return IVR_Extensions_Mapping_edit.isEnabled();
	}
	
	public void Tab_on_close_IVR_Extensions_Mapping_edit() throws InterruptedException {
		Thread.sleep(5000);
		try {
			IVR_Extensions_Mapping_edit.click();
		} catch (Exception e) {
			new Actions(driver).click(IVR_Extensions_Mapping_edit).build().perform();
		}
	}
	public boolean display_Status_of_IVR_Extensions_Mapping_Number1() {
		new Actions(driver).moveToElement(IVR_Extensions_Mapping_Number1).build().perform();
		return IVR_Extensions_Mapping_Number1.isDisplayed();
	}
	
	public boolean enable_Status_of_IVR_Extensions_Mapping_Number1() {
		return IVR_Extensions_Mapping_Number1.isEnabled();
	}
	
	public void Tab_on_IVR_Extensions_Mapping_Number1_cut_and_paste() throws InterruptedException {
		Thread.sleep(3000);
		try {
			IVR_Extensions_Mapping_Number1.click();
		} catch (Exception e) {
			new Actions(driver).click(IVR_Extensions_Mapping_Number1).build().perform();
		}
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").sendKeys("x").keyUp(Keys.CONTROL).build().perform();
		Thread.sleep(3000);
		new Actions(driver).click(IVR_Extensions_Mapping_Number1).keyDown(Keys.CONTROL).sendKeys("v").keyUp(Keys.CONTROL).build().perform();
		Thread.sleep(3000);
	}
	public boolean display_Status_of_IVR_Extensions_Mapping_Number2() throws InterruptedException {
		new Actions(driver).moveToElement(IVR_Extensions_Mapping_Number2).build().perform();
		Thread.sleep(3000);
		return IVR_Extensions_Mapping_Number2.isDisplayed();
	}
	
	public boolean enable_Status_of_IVR_Extensions_Mapping_Number2() {
		return IVR_Extensions_Mapping_Number2.isEnabled();
	}
	
	public void Tab_on_IVR_Extensions_Mapping_Number2_cut_and_paste() throws InterruptedException {
		Thread.sleep(3000);
		try {
			IVR_Extensions_Mapping_Number2.click();
		} catch (Exception e) {
			new Actions(driver).click(IVR_Extensions_Mapping_Number2).build().perform();
		}
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").sendKeys("x").keyUp(Keys.CONTROL).build().perform();
		Thread.sleep(3000);
		new Actions(driver).click(IVR_Extensions_Mapping_Number2).keyDown(Keys.CONTROL).sendKeys("v").keyUp(Keys.CONTROL).build().perform();
	}
	public boolean display_Status_of_IVR_Extensions_Mapping_Save() throws InterruptedException {
		new Actions(driver).moveToElement(IVR_Extensions_Mapping_Save).build().perform();
		Thread.sleep(3000);
		return IVR_Extensions_Mapping_Save.isDisplayed();
	}
	
	public boolean enable_Status_of_IVR_Extensions_Mapping_Save() {
		return IVR_Extensions_Mapping_Save.isEnabled();
	}
	
	public void Tab_on_IVR_Extensions_Mapping_Save() throws InterruptedException {
		Thread.sleep(2000);
		try {
			IVR_Extensions_Mapping_Save.click();
		} catch (Exception e) {
			new Actions(driver).click(IVR_Extensions_Mapping_Save).build().perform();
		}
	}
}
