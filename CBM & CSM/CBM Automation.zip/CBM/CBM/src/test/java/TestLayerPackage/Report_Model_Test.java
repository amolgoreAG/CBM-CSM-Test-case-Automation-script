package TestLayerPackage;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CBM;
import PageLayerPackage.Report_Model;

public class Report_Model_Test extends Base_Class_CBM {
	
	private static final Logger log = Logger.getLogger(Report_Model_Test.class);

	private static Report_Model rm;
	
	@Test(priority = 164)
	public void display_Status_of_Report_Test() {
		 rm = new Report_Model();
		Assert.assertEquals(rm.display_Status_of_Report(), true);
	}
	
	@Test(priority = 165)
	public void enable_Status_of_Report_Test() {
		Assert.assertEquals(rm.enable_Status_of_Report(), true);
	}
	
	@Test(priority = 165)
	public void tab_ob_Report() {
		try {
			rm.tab_ob_Report();
			log.info("Tab On Report");
		} catch (Exception e) {
			log.error("Not able to Tab On Report");
		}
	}
	@Test(priority = 166)
	public void display_Status_of_Report_Type_Test() {
		Assert.assertEquals(rm.display_Status_of_Report_Type(), true);
	}
	
	@Test(priority = 167)
	public void enable_Status_of_Report_Type_Test() {
		Assert.assertEquals(rm.enable_Status_of_Report_Type(), true);
	}
	
	@Test(priority = 168)
	public void tab_ob_Report_Type_Test() {
		try {
			rm.tab_ob_Report_Type();
			log.info("Tab on Report Type");
		} catch (Exception e) {
			log.error("Not able to Tab on Report Type");
		}
	}
	@Test(priority = 169)
	public void display_Status_of_Filter_Test() {
		Assert.assertEquals(rm.display_Status_of_Filter(), true);
	}
	
	@Test(priority = 170)
	public void enable_Status_of_Filter_Test() {
		Assert.assertEquals(rm.enable_Status_of_Filter(), true);
	}
	
	@Test(priority = 171)
	public void tab_ob_Filter_and_enetr_data_Test() throws InterruptedException {
		try {
			rm.tab_ob_Filter_and_enetr_data("Summary");
			log.info("Tab on Filter and Enter Text");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Filter and Enter Text");
		}
	}
	@Test(priority = 172)
	public void display_Status_of_firstOption_Test() {
		Assert.assertEquals(rm.display_Status_of_firstOption(), true);
	}
	
	@Test(priority = 173)
	public void enable_Status_of_firstOption_Test() {
		Assert.assertEquals(rm.enable_Status_of_firstOption(), true);
	}
	
	@Test(priority = 174)
	public void tab_ob_firstOption_Test() {
		try {
			rm.tab_ob_firstOption();
			log.info("Select the Opetion");
		} catch (Exception e) {
			log.error("Not able to Select the Opetion");
		}
	}
	@Test(priority = 175)
	public void display_Status_of_Campaign_Name_Test() {
		Assert.assertEquals(rm.display_Status_of_Campaign_Name(), true);
	}
	
	@Test(priority = 176)
	public void enable_Status_of_Campaign_Name_Test() {
		Assert.assertEquals(rm.enable_Status_of_Campaign_Name(), true);
	}
	
	@Test(priority = 177)
	public void tab_ob_Campaign_Name_Test() {
		try {
			rm.tab_ob_Campaign_Name();
			log.info("Tab on Campaign Name");
		} catch (Exception e) {
			log.error("Not able to Tab on Campaign Name");
		}
	}
	@Test(priority = 178)
	public void display_Status_of_Campaign_Name_Filter_Test() {
		Assert.assertEquals(rm.display_Status_of_Campaign_Name_Filter(), true);
	}
	
	@Test(priority = 179)
	public void enable_Status_of_Campaign_Name_Filter_Test() {
		Assert.assertEquals(rm.enable_Status_of_Campaign_Name_Filter(), true);
	}
	
	@Test(priority = 180)
	public void tab_ob_Campaign_Name_Filter_and_enter_campaign_name_Test() throws InterruptedException {
		try {
			rm.tab_ob_Campaign_Name_Filter_and_enter_campaign_name("orthopediology");
			log.info("Tab on Filter and Enter the Campaign Name");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Filter and Enter the Campaign Name");
		}
	}
	@Test(priority = 181)
	public void display_Status_of_Campaign_Name_Filter_First_Option_Test() {
		Assert.assertEquals(rm.display_Status_of_Campaign_Name_Filter_First_Option(), true);
	}
	
	@Test(priority = 182)
	public void enable_Status_of_Campaign_Name_Filter_First_Option_Test() {
		Assert.assertEquals(rm.enable_Status_of_Campaign_Name_Filter_First_Option(), true);
	}
	
	@Test(priority = 183)
	public void tab_ob_Campaign_Name_Filter_First_Option_Test() {
		try {
			rm.tab_ob_Campaign_Name_Filter_First_Option();
			log.info("Select the Option");
		} catch (Exception e) {
			log.error("Not able to Select the Option");
		}
	}
	@Test(priority = 184)
	public void display_Status_of_fromCalender_Test() {
		Assert.assertEquals(rm.display_Status_of_fromCalender(), true);
	}
	
	@Test(priority = 185)
	public void enable_Status_of_fromCalender_Test() {
		Assert.assertEquals(rm.enable_Status_of_fromCalender(), true);
	}
	
	@Test(priority = 186)
	public void tab_ob_fromCalender_Test() {
		try {
			rm.tab_ob_fromCalender();
			log.info("Tab on From Calender");
		} catch (Exception e) {
			log.error("Not able to Tab on From Calender");
		}
	}
	
	@Test(priority = 187)
	public void select_the_From_date_Test() throws InterruptedException {
		try {
			rm.select_the_From_date();
			log.info("Select the From Date");
		} catch (InterruptedException e) {
			log.error("Not able to Select the From Date");
		}
	}
	@Test(priority = 188)
	public void display_Status_of_toCalender_Test() {
		Assert.assertEquals(rm.display_Status_of_toCalender(), true);
	}
	
	@Test(priority = 189)
	public void enable_Status_of_toCalender_Test() {
		Assert.assertEquals(rm.enable_Status_of_toCalender(), true);
	}
	
	@Test(priority = 190)
	public void tab_ob_toCalender_Test() {
		try {
			rm.tab_ob_toCalender();
			log.info("Tab on To calender");
		} catch (Exception e) {
			log.error("Not able to Tab on To calender");
		}
	}
	
	@Test(priority = 191)
	public void select_the_to_date_Test() throws InterruptedException {
		try {
			rm.select_the_To_date();
			log.info("Select The To Date");
		} catch (InterruptedException e) {
			log.error("Not able to Select The To Date");
		}
	}
	@Test(priority = 192)
	public void display_Status_of_Generate_Report_Test() {
		Assert.assertEquals(rm.display_Status_of_Generate_Report(), true);
	}
	
	@Test(priority = 193)
	public void enable_Status_of_Generate_Report_Test() {
		Assert.assertEquals(rm.enable_Status_of_Generate_Report(), true);
	}
	
	@Test(priority = 194)
	public void tab_ob_Generate_Report_Test() {
		try {
			rm.tab_ob_Generate_Report();
			log.info("Tab on Generate Report");
		} catch (Exception e) {
			log.error("Not able to Tab on Generate Report");
		}
	}
	@Test(priority = 195)
	public void display_Status_of_Download_Report_Test() {
		Assert.assertEquals(rm.display_Status_of_Download_Report(), true);
	}
	
	@Test(priority = 196)
	public void enable_Status_of_Download_Report_Test() {
		Assert.assertEquals(rm.enable_Status_of_Download_Report(), true);
	}
	
//	@Test(priority = 197)
	public void tab_ob_Download_Report_Test() {
		try {
			rm.tab_ob_Download_Report();
			log.info("Tab on Download Report");
		} catch (Exception e) {
			log.error("Not able to Tab on Download Report");
		}
	}
	@Test(priority = 198)
	public void display_Status_of_Report_Typ_Tets() {
		Assert.assertEquals(rm.display_Status_of_Report_Typ(), true);
	}
	
	@Test(priority = 199)
	public void enable_Status_of_Report_Typ_Test() {
		Assert.assertEquals(rm.enable_Status_of_Report_Typ(), true);
	}
	
	@Test(priority = 200)
	public void tab_ob_Report_Typ_Test() {
		try {
			rm.tab_ob_Report_Typ();
			log.info("Tab on Report Type");
		} catch (Exception e) {
			log.error("Not able to Tab on Report Type");
		}
	}
	@Test(priority = 201)
	public void display_Status_of_Detail_Report_Test() {
		Assert.assertEquals(rm.display_Status_of_Detail_Report(), true);
	}
	
	@Test(priority = 202)
	public void enable_Status_of_Detail_Report_Test() {
		Assert.assertEquals(rm.enable_Status_of_Detail_Report(), true);
	}
	
	@Test(priority = 203)
	public void tab_ob_Detail_Report_Test() {
		try {
			rm.tab_ob_Detail_Report();
			log.info("Tab on Details Report");
		} catch (Exception e) {
			log.error("Not able to Tab on Details Report");
		}
	}
	@Test(priority = 204)
	public void display_Status_of_Campaign_Name_DR_Test() {
		Assert.assertEquals(rm.display_Status_of_Campaign_Name(), true);
	}
	
	@Test(priority = 205)
	public void enable_Status_of_Campaign_Name_DR_Test() {
		Assert.assertEquals(rm.enable_Status_of_Campaign_Name(), true);
	}
	
	@Test(priority = 206)
	public void tab_ob_Campaign_Name_DR_Test() {
		try {
			rm.tab_ob_Campaign_Name();
			log.info("Tab On Campaign name");
		} catch (Exception e) {
			log.error("Not able to Tab On Campaign Name");
		}
	}
	@Test(priority = 207)
	public void display_Status_of_Campaign_Name_Filter_DR_Test() {
		Assert.assertEquals(rm.display_Status_of_Campaign_Name_Filter(), true);
	}
	
	@Test(priority = 208)
	public void enable_Status_of_Campaign_Name_Filter_DR_Test() {
		Assert.assertEquals(rm.enable_Status_of_Campaign_Name_Filter(), true);
	}
	
	@Test(priority = 209)
	public void tab_ob_Campaign_Name_Filter_and_enter_DR_campaign_name_Test() throws InterruptedException {
		try {
			rm.tab_ob_Campaign_Name_Filter_and_enter_campaign_name("orthopediology");
			log.info("Tab on Campaign_Name_Filter and Enter campaign name");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Campaign_Name_Filter and Enter campaign name");
		}
	}
	@Test(priority = 210)
	public void display_Status_of_Campaign_Name_Filter_First_Option_DR_Test() {
		Assert.assertEquals(rm.display_Status_of_Campaign_Name_Filter_First_Option(), true);
	}
	
	@Test(priority = 211)
	public void enable_Status_of_Campaign_Name_Filter_First_Option_DR_Test() {
		Assert.assertEquals(rm.enable_Status_of_Campaign_Name_Filter_First_Option(), true);
	}
	
	@Test(priority = 212)
	public void tab_ob_Campaign_Name_Filter_First_Option_DR_Test() {
		try {
			rm.tab_ob_Campaign_Name_Filter_First_Option();
			log.info("select the Campaign");
		} catch (Exception e) {
			log.error("Not able to select the Campaign");
		}
	}
	@Test(priority = 213)
	public void display_Status_of_fromCalender_DR_Test() {
		Assert.assertEquals(rm.display_Status_of_fromCalender(), true);
	}
	
	@Test(priority = 214)
	public void enable_Status_of_fromCalender_DR_Test() {
		Assert.assertEquals(rm.enable_Status_of_fromCalender(), true);
	}
	
	@Test(priority = 215)
	public void tab_ob_fromCalender_DR_Test() {
		try {
			rm.tab_ob_fromCalender();
			log.info("Tab on From Calender");
		} catch (Exception e) {
			log.error("Not able to Tab on From Calender");
		}
	}
	
	@Test(priority = 216)
	public void select_the_From_date_DR_Test() throws InterruptedException {
		try {
			rm.select_the_From_date();
			log.info("Select the from date");
		} catch (InterruptedException e) {
			log.error("Not able to Select the from date");
		}
	}
	@Test(priority = 217)
	public void display_Status_of_toCalender_DR_Test() {
		Assert.assertEquals(rm.display_Status_of_toCalender(), true);
	}
	
	@Test(priority = 218)
	public void enable_Status_of_toCalender_DR_Test() {
		Assert.assertEquals(rm.enable_Status_of_toCalender(), true);
	}
	
	@Test(priority = 219)
	public void tab_ob_toCalender_DR_Test() {
		try {
			rm.tab_ob_toCalender();
			log.info("Tab on To Calender");
		} catch (Exception e) {
			log.error("Not able to Tab on To Calender");
		}
	}
	
	@Test(priority = 220)
	public void select_the_to_date_DR_Test() throws InterruptedException {
		try {
			rm.select_the_To_date();
			log.info("Select the To Date");
		} catch (InterruptedException e) {
			log.error("Not able to Select the To Date");
		}
	}

	@Test(priority = 221)
	public void display_Status_of_Caller_Choice_Test() {
		Assert.assertEquals(rm.display_Status_of_Caller_Choice(), true);
	}
	
	@Test(priority = 222)
	public void enable_Status_of_Caller_Choice_Test() {
		Assert.assertEquals(rm.enable_Status_of_Caller_Choice(), true);
	}
	
	@Test(priority = 223)
	public void tab_ob_Caller_Choice_and_select_value_Test() throws InterruptedException {
		try {
			rm.tab_ob_Caller_Choice_and_select_value("No Response");
			log.info("Tab on Caller_Choice , Enter data and select the option");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Caller_Choice , Enter data and select the option");
		}
	}
	@Test(priority = 224)
	public void display_Status_of_Generate_Report_DR_Test() {
		Assert.assertEquals(rm.display_Status_of_Generate_Report(), true);
	}
	
	@Test(priority = 225)
	public void enable_Status_of_Generate_Report_DR_Test() {
		Assert.assertEquals(rm.enable_Status_of_Generate_Report(), true);
	}
	
	@Test(priority = 226)
	public void tab_ob_Generate_Report_DR_Test() {
		try {
			rm.tab_ob_Generate_Report();
			log.info("Tab on Generate Report");
		} catch (Exception e) {
			log.error("Not able to Tab on Generate Report");		}
	}
}
