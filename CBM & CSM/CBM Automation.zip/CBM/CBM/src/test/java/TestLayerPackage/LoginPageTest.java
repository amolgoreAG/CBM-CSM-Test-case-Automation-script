package TestLayerPackage;



import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CBM;
import PageLayerPackage.LoginPage;


public class LoginPageTest extends Base_Class_CBM {
	public static LoginPage login;

	@Test(priority = 1)
	public void user_is_on_login_page_Test() {
		Base_Class_CBM.CBM();
	}

	@Test(priority = 2)
	public void check_display_status_of_username_Test() throws InterruptedException {
		login = new LoginPage();
		login.dispaly_status_of_Username();
	}

	@Test(priority = 3)
	public void check_enable_status_of_username_Test() {
		login.enable_Status_of_username();
	}

	@Test(priority = 4)
	public void enter_username_Test_Test(){
		login.enter_username("Admin");
	}

	@Test(priority = 5)
	public void check_display_status_of_password_Test() throws InterruptedException {
		login.dispaly_status_of_Password();
	}

	@Test(priority = 6)
	public void check_enable_status_of_password_Test() {
		login.enable_Status_of_Password();
	}

	@Test(priority = 7)
	public void enter_password_Test() {
		login.enter_Password("Welcome@123");
	}

	@Test(priority = 8)
	public void tab_on_loginpage_Test() throws InterruptedException {
		login.clickOnLoginbtn();
	}
}
