package TestLayerPackage;


import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BaseLayerPackage.Base_Class_CBM;
import PageLayerPackage.compaign_management_module;

public class Compaign_managementTests extends Base_Class_CBM {
	
	private static final Logger log = Logger.getLogger(Compaign_managementTests.class);

	public static compaign_management_module cmm;

	@Test(priority = 9)
	public void user_on_compaign_management() throws InterruptedException {
		cmm = new compaign_management_module();
		Assert.assertEquals(cmm.user_on_compaign_management(), true);
	}

//	@Test(priority = 10)
	public void display_Status_Of_add_compaign_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_Of_add_compaign(), true);
	}

//	@Test(priority = 11)
	public void Enable_Status_Of_add_compaign_Test() throws InterruptedException {
		cmm.addcomapaign();
		Assert.assertEquals(cmm.Enable_Status_Of_add_compaign(), true);
	}

	@Test(priority = 12)
	public void user_tab_on_add_compaign() throws InterruptedException {
		cmm.addcomapaign();
	}

	@Test(priority = 13)
	public void first_check_display_status_of_compaign_name() {
		Assert.assertEquals(cmm.first_check_display_status_of_compaign_name(), true);
	}

	@Test(priority = 14)
	public void check_enable_status_of_compaign_name() {
		Assert.assertEquals(cmm.check_enable_status_of_compaign_name(), true);
	}

	@Test(priority = 15)
	public void enter_name_of_the_compaign_Name() throws InterruptedException {
		cmm.enter_name_of_the_compaign_Name("Diwali");

	}

	@Test(priority = 16)
	public void check_display_status_of_compaign_type() throws InterruptedException {
		Assert.assertEquals(cmm.check_display_status_of_compaign_type(), true);
	}

	@Test(priority = 17)
	public void check_enable_status_of_compaign_type() {
		Assert.assertEquals(cmm.check_enable_status_of_compaign_type(), true);
	}

	@Test(priority = 18)
	public void it_will_select_ivr_base_cbm_from_drop_down() throws InterruptedException {
		cmm.it_will_select_ivr_base_cbm_from_drop_down();
	}

	@Test(priority = 19)
	public void display_Status_of_fromCalender_Test() {
		Assert.assertEquals(cmm.display_Status_of_fromCalender(), true);
	}

	@Test(priority = 20)
	public void enable_Status_of_fromCalender_Test() {
		cmm.open_from_calender();
		Assert.assertEquals(cmm.enable_Status_of_fromCalender(), true);
	}

	@Test(priority = 21)
	public void open_from_calender() {
		cmm.open_from_calender();
	}

	@Test(priority = 22)
	public void select_the_date() throws InterruptedException {
		cmm.select_the_From_date();
	}

	@Test(priority = 23)
	public void display_Status_of_From_Date_Time_Test() throws InterruptedException {
		cmm.display_Status_of_From_Date_Time();
	}

	@Test(priority = 24)
	public void enable_status_of_From_Date_Time_Test() throws InterruptedException {
		cmm.enable_status_of_From_Date_Time();
	}

	@Test(priority = 25)
	public void open_the_from_date_time() throws InterruptedException {
		cmm.open_the_from_date_time();
	}

	@Test(priority = 26)
	public void select_the_time() throws InterruptedException {
		cmm.select_the_time();
	}

	@Test(priority = 27)
	public void display_Status_Of_toCalender_Test() {
		Assert.assertEquals(cmm.display_Status_Of_toCalender(), true);
	}

	@Test(priority = 28)
	public void enable_Status_Of_toCalender_Test() {
		cmm.enable_Status_Of_toCalender();
		Assert.assertEquals(cmm.enable_Status_Of_toCalender(), true);
	}

	@Test(priority = 29)
	public void open_to_calender() {
		cmm.open_to_calender();
	}

	@Test(priority = 30)
	public void select_the_dates() throws InterruptedException {
		cmm.select_the_To_date();
	}

	@Test(priority = 31)
	public void display_Status_To_of_Date_Time_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_To_of_Date_Time(), true);
	}

	@Test(priority = 32)
	public void enabele_Status_of_To_Date_Time_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enabele_Status_of_To_Date_Time(), true);
	}

	@Test(priority = 33)
	public void open_the_To_date_time_Test() throws InterruptedException {
		cmm.open_the_To_date_time();
	}

	@Test(priority = 34)
	public void display_Status_of_Call_Before_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Call_Before(), true);
	}

	@Test(priority = 35)
	public void enable_Status_of_Call_Before_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_Call_Before(), true);
	}

	@Test(priority = 36)
	public void open_the_call_before_drop_down_and_select_the_day() throws InterruptedException {
		cmm.open_the_call_before_drop_down_and_select_the_day();
	}

	@Test(priority = 37)
	public void display_status_of_concurrent_call_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_concurrent_call(), true);
	}

	@Test(priority = 38)
	public void enabel_status_of_concurrent_call_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enabel_status_of_concurrent_call(), true);
	}

	@Test(priority = 39)
	public void enter_concurrent_call_count_in_Test() {
		cmm.enter_concurrent_call_count_in();
	}

	@Test(priority = 40)
	public void enter_Max_Adv_notice_hrs_and_minutes_Test() throws InterruptedException {
		cmm.enter_Max_Adv_notice_hrs_and_minutes("08", "00");
	}

	@Test(priority = 42)
	public void enter_Retry_Delay_hrs_and_minutes_Test() throws InterruptedException {
		cmm.enter_Retry_Delay_hrs_and_minutes("01", "15");
	}

	@Test(priority = 43)
	public void enter_retry_count_Test() {
		cmm.enter_retry_count();
	}

	@Test(priority = 44)
	public void display_Status_of_week_day_conf_Test() {
		Assert.assertEquals(cmm.display_Status_of_week_day_conf(), true);
	}

	@Test(priority = 45)
	public void enable_Status_of_week_day_conf_Test() {
		Assert.assertEquals(cmm.enable_Status_of_week_day_conf(), true);
	}

	@Test(priority = 46)
	public void open_week_day_conf_Test() {
			cmm.open_week_day_conf();
	}

	@Test(priority = 47)
	public void display_Status_of_Sunday_CheckBox_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Sunday_CheckBox(), true);
	}

	@Test(priority = 48)
	public void enable_Status_of_Sunday_CheckBox_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_Sunday_CheckBox(), true);
	}

	@Test(priority = 49)
	public void selected_Status_of_Sunday_CheckBox_before_select_checkbox_Test() throws InterruptedException {
		Assert.assertEquals(cmm.selected_Status_of_Sunday_CheckBox_before_select_checkbox(), false);
	}

	@Test(priority = 50)
	public void Select_Sunday_CheckBox_Test() throws InterruptedException {
		try {
			cmm.Select_Sunday_CheckBox();
			log.info("Select the Sunday check box");
		} catch (InterruptedException e) {
			log.error("Not able to Select the Sunday check box");
		}
	}

	@Test(priority = 50)
	public void selected_Status_of_Sunday_CheckBox_after_select_checkbox_Test() throws InterruptedException {
		Assert.assertEquals(cmm.selected_Status_of_Sunday_CheckBox_after_select_checkbox(), true);
	}

	@Test(priority = 51)
	public void display_Status_of_Sunday_Start_Time_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Sunday_Start_Time(), true);
	}

	@Test(priority = 52)
	public void enable_Status_of_Sunday_Start_Time_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_Sunday_Start_Time(), true);
	}

	@Test(priority = 53)
	public void Tab_On_Sunday_Start_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Sunday_Start_Time_And_Select_Time();
			log.info("Tab on Sunday_Start_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Sunday_Start_Time and select the Time");
		}
	}

	@Test(priority = 54)
	public void display_Status_of_Sunday_End_Time_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Sunday_End_Time(), true);
	}

	@Test(priority = 55)
	public void enable_Status_of_Sunday_End_Time_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_Sunday_End_Time(), true);
	}

	@Test(priority = 56)
	public void Tab_On_Sunday_End_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Sunday_End_Time_And_Select_Time();
			log.info("Tab on Sunday_End_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Sunday_End_Time and select the Time");
		}
	}

	@Test(priority = 57)
	public void Tab_On_Monday_Start_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Monday_Start_Time_And_Select_Time();
			log.info("Tab on Monday_Start_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Monday_Start_Time and select the Time");
			}
	}

	@Test(priority = 58)
	public void Tab_On_Monday_End_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Monday_End_Time_And_Select_Time();
			log.info("Tab on Monday_End_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Monday_End_Time and select the Time");
		}
	}

	@Test(priority = 59)
	public void Tab_On_Tuesday_Start_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Tuesday_Start_Time_And_Select_Time();
			log.info("Tab on Tuesday_Start_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Tuesday_Start_Time and select the Time");
		}
	}

	@Test(priority = 60)
	public void Tab_On_Tuesday_End_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Tuesday_End_Time_And_Select_Time();
			log.info("Tab on Tuesday_End_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Tuesday_End_Time and select the Time");
		}
	}

	@Test(priority = 61)
	public void Tab_On_Wednesday_Start_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Wednesday_Start_Time_And_Select_Time();
			log.info("Tab on Wednesday_Start_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Wednesday_Start_Time and select the Time");
		}
	}

	@Test(priority = 62)
	public void Tab_On_Wednesday_End_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Wednesday_End_Time_And_Select_Time();
			log.info("Tab on Wednesday_End_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Wednesday_End_Time and select the Time");
		}
	}

	@Test(priority = 63)
	public void Tab_On_Thursday_Start_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Thursday_Start_Time_And_Select_Time();
			log.info("Tab on Thursday_Start_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Thursday_Start_Time and select the Time");
		}
	}

	@Test(priority = 64)
	public void Tab_On_Thursday_End_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Thursday_End_Time_And_Select_Time();
			log.info("Tab on Thursday_End_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Thursday_End_Time and select the Time");
		}
	}

	@Test(priority = 65)
	public void Tab_On_Friday_Start_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Friday_Start_Time_And_Select_Time();
			log.info("Tab on Friday_Start_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Friday_Start_Time and select the Time");
		}
	}

	@Test(priority = 66)
	public void Tab_On_Friday_End_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Friday_End_Time_And_Select_Time();
			log.info("Tab on Friday_End_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Friday_End_Time and select the Time");
		}
	}

	@Test(priority = 67)
	public void Tab_On_Saturday_CheckBox_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Saturday_CheckBox();
			log.info("Select the Saturday_CheckBox");
		} catch (Exception e) {
			log.error("Not able to Select the Saturday_CheckBox");
		}
		
	}

	@Test(priority = 68)
	public void Tab_On_Saturday_Start_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Saturday_Start_Time_And_Select_Time();
			log.info("Tab on Saturday_Start_Time and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Saturday_Start_Time and select the Time");
		}
	}

	@Test(priority = 69)
	public void Tab_On_Saturday_End_Time_And_Select_Time_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Saturday_End_Time_And_Select_Time();
			log.info("Tab on Saturday_Start_End and select the Time");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Saturday_Start_End and select the Time");
		}
	}

	@Test(priority = 70)
	public void display_Status_of_Campaign_Active_Deactive_CheckBox_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Campaign_Active_Deactive_CheckBox(), true);
	}

	@Test(priority = 71)
	public void enable_Status_of_Campaign_Active_Deactive_CheckBox_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_Campaign_Active_Deactive_CheckBox(), true);
	}

	@Test(priority = 72)
	public void selected_Status_of_Campaign_Active_Deactive_CheckBox_before_select_Test() throws InterruptedException {
		Assert.assertEquals(cmm.selected_Status_of_Campaign_Active_Deactive_CheckBox_before_select(), false);
	}

	@Test(priority = 73)
	public void Tab_On_Campaign_Active_Deactive_CheckBox_Test() throws InterruptedException {
		try {
			cmm.Tab_On_Campaign_Active_Deactive_CheckBox();
			log.info("Select Campaign_Active_Deactive_CheckBox");
		} catch (InterruptedException e) {
			log.error("Not able to Select Campaign_Active_Deactive_CheckBox");
		}
	}

	@Test(priority = 74)
	public void selected_Status_of_Campaign_Active_Deactive_CheckBox_after_select_Test() throws InterruptedException {
		Assert.assertEquals(cmm.selected_Status_of_Campaign_Active_Deactive_CheckBox_after_select(), true);
	}
	@Test(priority = 75)
	public void display_status_of_Intigration_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_Intigration(), true);
	}
	@Test(priority = 76)
	public void enable_status_of_Intigration_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_status_of_Intigration(), true);
	}
	@Test(priority = 77)
	public void tab_on_Intigration_detail_update_Test() throws InterruptedException {
		try {
			cmm.tab_on_Intigration_detail_update();
			log.info("Tab on Intigration");
		} catch (Exception e) {
			log.error("Not able to Tab on Intigration");
		}
	}
	@Test(priority = 78)
	public void display_status_of_Native_Intigration_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_Native_Intigration(), true);
	}
	@Test(priority = 79)
	public void enable_status_of_Native_Intigration_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_status_of_Native_Intigration(), true);
	}
	@Test(priority = 80)
	public void check_status_of_Native_Intigration_checkbox_before_select_Test() throws InterruptedException {
		Assert.assertEquals(cmm.check_status_of_Native_Intigration_checkbox_before_select(), false);
	}
	@Test(priority = 81)
	public void select_Native_Intigration_Test() throws InterruptedException {
		try {
			cmm.select_Native_Intigration();
			log.info("select the Native_Intigration checkbox");
		} catch (Exception e) {
			log.error("Not able to select the Native_Intigration checkbox");
		}
	}
	@Test(priority = 82)
	public void check_status_of_Native_Intigration_checkbox_after_select_Test() throws InterruptedException {
		Assert.assertEquals(cmm.check_status_of_Native_Intigration_checkbox_after_select(), true);
	}
	@Test(priority = 83)
	public void Unselect_Native_Intigration_Test() throws InterruptedException {
		try {
			cmm.Unselect_Native_Intigration();
			log.info("Unselect the Native_Intigration checkbox");
		} catch (Exception e) {
			log.error("Not able to Unselect the Native_Intigration checkbox");
		}
	}
	@Test(priority = 84)
	public void display_status_of_SFTP_Location_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_SFTP_Location(), true);
		log.info("display_status_of_SFTP_Location : "+  cmm.display_status_of_SFTP_Location());  
	}
	@Test(priority = 85)
	public void enable_status_of_SFTP_Location_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_status_of_SFTP_Location(), true);
		log.info("enable_status_of_SFTP_Location : "+  cmm.enable_status_of_SFTP_Location());  

	}
	@Test(priority = 86)
	public void display_status_of_SFTP_FileName_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_SFTP_FileName(), true);
		log.info("display_status_of_SFTP_FileName : "+  cmm.display_status_of_SFTP_FileName());  
	}
	@Test(priority = 87)
	public void enable_status_of_SFTP_FileName_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_status_of_SFTP_FileName(), true);
		log.info("enable_status_of_SFTP_FileName : "+  cmm.enable_status_of_SFTP_FileName());  
	}
	@Test(priority = 88)
	public void display_status_of_SFTP_UserName_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_SFTP_UserName(), true);
		log.info("display_status_of_SFTP_UserName : "+  cmm.display_status_of_SFTP_UserName());  
	}
	@Test(priority = 89)
	public void enable_status_of_SFTP_UserName_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_status_of_SFTP_UserName(), true);
		log.info("enable_status_of_SFTP_UserName : "+  cmm.enable_status_of_SFTP_UserName());  
	}
	@Test(priority = 90)
	public void display_status_of_SFTP_Password_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_SFTP_Password(), true);
		log.info("display_status_of_SFTP_Password : "+  cmm.display_status_of_SFTP_Password());  
	}
	@Test(priority = 91)
	public void enable_status_of_SFTP_Password_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_status_of_SFTP_Password(), true);
		log.info("enable_status_of_SFTP_Password : "+  cmm.enable_status_of_SFTP_Password());  
	}
	@Test(priority = 92)
	public void display_status_of_submit_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_submit(), true);
		log.info("display_status_of_submit : "+  cmm.display_status_of_submit());  
	}
	@Test(priority = 93)
	public void enable_status_of_submit_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_status_of_submit(), true);
		log.info("enable_status_of_submit : "+  cmm.enable_status_of_submit());  
	}
	@Test(priority = 94)
	public void display_status_of_Close_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_Close(), true);
	}
	@Test(priority = 95)
	public void enable_status_of_Close_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_status_of_Close(), true);
	}
	@Test(priority = 96)
	public void tab_on_Close_btn_Test() throws InterruptedException {
		try {
			cmm.tab_on_Close_btn();
			log.info("Tab on close");
		} catch (Exception e) {
			log.error("Not able to Tab on close");
		}
	}
	@Test(priority = 97)
	public void display_Status_of_Close1_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Close1(), true);
	}
	@Test(priority = 98)
	public void enable_Status_of_Close1_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_Close1(), true);
	}
	@Test(priority = 99)
	public void display_Status_of_add_campaign_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_add_campaign(), true);
		log.info("display_Status_of_add_campaign : " + cmm.display_Status_of_add_campaign());
	}
	@Test(priority = 100)
	public void enable_Status_of_add_campaign_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_add_campaign(), true);
		log.info("enable_Status_of_add_campaign : " + cmm.enable_Status_of_add_campaign());
	}
	@Test(priority = 101)
	public void tab_on_add_campaign_Test() throws InterruptedException {
		try {
			cmm.tab_on_add_campaign();
			log.info("Tab on Add Campaign");
		} catch (Exception e) {
			log.error("Not able to Tab on Add Campaign");
		}
	}
//	@Test(priority = 101)
//	public void tab_on_close_Test() throws InterruptedException {
//		try {
//			cmm.tab_on_close();
//			log.info("tab_on_close");
//		} catch (Exception e) {
//			log.error("Not able to tab_on_close");
//		}
//	}
	@Test(priority = 102)
	public void display_Status_of_edit_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_edit(), true);
		log.info("display_Status_of_edit : " + cmm.display_Status_of_edit());
	}
	@Test(priority = 103)
	public void enable_Status_of_edit_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_edit(), true);
		log.info("enable_Status_of_edit : " + cmm.enable_Status_of_edit());
	}
	@Test(priority = 104)
	public void tab_on_edit_Test() throws InterruptedException {
		try {
			cmm.tab_on_edit();
			log.info("Tab on Edit");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Edit");
		}
	}
	@Test(priority = 105)
	public void display_Status_of_Close_in_update_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Close_in_update(), true);
		log.info("display_Status_of_Close_in_update : " + cmm.display_Status_of_Close_in_update());
	}
	@Test(priority = 106)
	public void enable_Status_of_Close_in_update_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_Close_in_update(), true);
		log.info("enable_Status_of_Close_in_update : " + cmm.enable_Status_of_Close_in_update());
	}
	@Test(priority = 107)
	public void display_Status_of_update_campaign_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_update_campaign(), true);
		log.info("display_Status_of_update_campaign : " + cmm.display_Status_of_update_campaign());
	}
	@Test(priority = 108)
	public void enable_Status_of_update_campaign_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_update_campaign(), true);
		log.info("enable_Status_of_update_campaign : " + cmm.enable_Status_of_update_campaign());
	}
	@Test(priority = 109)
	public void tab_on_update_campaign_Test() throws InterruptedException {
		try {
			cmm.tab_on_update_campaign();
			log.info("Tab on update campaign");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on update campaign");
		}
	}
//	@Test(priority = 109)
//	public void tab_on_close_campaign_Test() throws InterruptedException {
//		try {
//			cmm.tab_on_close_campaign();
//			log.info("tab_on_close_campaign");
//		} catch (InterruptedException e) {
//			log.error("Not able to tab_on_close_campaign");
//		}
//	}
//	@Test(priority = 107)
	public void display_Status_of_UploadFile_Test() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_UploadFile(), true);
	}
//	@Test(priority = 108)
	public void enable_Status_of_UploadFile_Test() throws InterruptedException {
		Assert.assertEquals(cmm.enable_Status_of_UploadFile(), true);
	}
//	@Test(priority = 109)
	public void tab_on_UploadFile_Test() throws InterruptedException {
		cmm.tab_on_UploadFile();
	}
//	@Test(priority = 110)
	public void tab_on__Attached_File_Tets() throws InterruptedException {
		cmm.tab_on__Attached_File();
	}
	@Test(priority = 111)
	public void tab_on_View_Test() throws InterruptedException {
		try {
			cmm.tab_on_View();
			log.info("Tab on View");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on View");
		}
	}
	@Test(priority = 112)
	public void first_check_display_status_of_compaign_name_in_view1() {
		Assert.assertEquals(cmm.first_check_display_status_of_compaign_name1(), true);
		log.info("check_display_status_of_compaign_name1 : " + cmm.first_check_display_status_of_compaign_name1());
	}

	@Test(priority = 113)
	public void check_enable_status_of_compaign_name_in_view1() {
		Assert.assertEquals(cmm.check_enable_status_of_compaign_name1(), true);
		log.info("check_enable_status_of_compaign_name1 : " + cmm.check_enable_status_of_compaign_name1());
	}
	@Test(priority = 114)
	public void check_display_status_of_compaign_type_in_view1() throws InterruptedException {
		Assert.assertEquals(cmm.check_display_status_of_compaign_type1(), true);
		log.info("check_display_status_of_compaign_type1 : " + cmm.check_display_status_of_compaign_type1());
	}

	@Test(priority = 115)
	public void check_enable_status_of_compaign_type_in_view1() {
		Assert.assertEquals(cmm.check_enable_status_of_compaign_type1(), false);
		new SoftAssert().assertAll();
		log.info("check_enable_status_of_compaign_type1 : " + cmm.check_enable_status_of_compaign_type1());
	}
	@Test(priority = 116)
	public void display_Status_of_fromCalender_Test_in_view1() {
		Assert.assertEquals(cmm.display_Status_of_fromCalender1(), true);
		log.info("display_Status_of_fromCalender1 : " + cmm.display_Status_of_fromCalender1());
	}

	@Test(priority = 117)
	public void enable_Status_of_fromCalender_Test_in_view1() {
		cmm.open_from_calender();
		new SoftAssert().assertEquals(cmm.enable_Status_of_fromCalender1(), false);
		new SoftAssert().assertAll();
		log.error("enable_Status_of_fromCalender1 : " + cmm.enable_Status_of_fromCalender1());
	}
	@Test(priority = 118)
	public void display_Status_of_From_Date_Time_Test_in_view1() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_From_Date_Time1(), true);
		log.info("display_Status_of_From_Date_Time1 : " + cmm.display_Status_of_From_Date_Time1());
	}

	@Test(priority = 119)
	public void enable_status_of_From_Date_Time_Test_in_view1() throws InterruptedException {
		new SoftAssert().assertEquals(cmm.enable_status_of_From_Date_Time1(), false);
		new SoftAssert().assertAll();
		log.error("enable_status_of_From_Date_Time1 : " + cmm.enable_status_of_From_Date_Time1());
	}
	
	@Test(priority = 120)
	public void display_Status_Of_toCalender_Test_in_view1() {
		Assert.assertEquals(cmm.display_Status_Of_toCalender1(), true);
		log.info("display_Status_Of_toCalender1 : " + cmm.display_Status_Of_toCalender1());
	}

	@Test(priority = 121)
	public void enable_Status_Of_toCalender_Test_in_view1() {
		new SoftAssert().assertEquals(cmm.enable_Status_Of_toCalender1(), false);
		new SoftAssert().assertAll();
		log.error("enable_Status_Of_toCalender1 : " + cmm.enable_Status_Of_toCalender1());
	}
	
	@Test(priority = 122)
	public void display_Status_To_of_Date_Time_Test_in_view() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_To_of_Date_Time1(), true);
		log.info("display_Status_To_of_Date_Time1 : " + cmm.display_Status_To_of_Date_Time1());
	}

	@Test(priority = 123)
	public void enabele_Status_of_To_Date_Time_Test_in_view1() throws InterruptedException {
		new SoftAssert().assertEquals(cmm.enabele_Status_of_To_Date_Time1(), false);
		new SoftAssert().assertAll();
		log.error("enabele_Status_of_To_Date_Time1 : " + cmm.enabele_Status_of_To_Date_Time1());
	}
	
	@Test(priority = 124)
	public void display_Status_of_Call_Before_Test_in_view1() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Call_Before1(), true);
		log.info("display_Status_of_Call_Before1 : " + cmm.display_Status_of_Call_Before1());
	}

	@Test(priority = 125)
	public void enable_Status_of_Call_Before_Test_in_view1() throws InterruptedException {
		new SoftAssert().assertEquals(cmm.enable_Status_of_Call_Before1(), false);
		new SoftAssert().assertAll();
		log.error("enable_Status_of_Call_Before1 : " + cmm.enable_Status_of_Call_Before1());
	}

	@Test(priority = 126)
	public void display_status_of_concurrent_call_Test_in_view1() throws InterruptedException {
		Assert.assertEquals(cmm.display_status_of_concurrent_call1(), true);
		log.info("display_status_of_concurrent_call1 : " + cmm.display_status_of_concurrent_call1());
	}

	@Test(priority = 127)
	public void enabel_status_of_concurrent_call_Test_in_view1() throws InterruptedException {
		new SoftAssert().assertEquals(cmm.enabel_status_of_concurrent_call1(), false);
		new SoftAssert().assertAll();
		log.error("enabel_status_of_concurrent_call1 : " + cmm.enabel_status_of_concurrent_call1());
	}

	@Test(priority = 128)
	public void display_Status_of_week_day_conf_Test_in_view() {
		Assert.assertEquals(cmm.display_Status_of_week_day_conf1(), true);
		log.info("display_Status_of_week_day_conf1 : " + cmm.display_Status_of_week_day_conf1());
	}

	@Test(priority = 129)
	public void enable_Status_of_week_day_conf_Test_in_view() {
		Assert.assertEquals(cmm.enable_Status_of_week_day_conf1(), true);
		log.info("enable_Status_of_week_day_conf1 : " + cmm.enable_Status_of_week_day_conf1());
	}

	@Test(priority = 130)
	public void open_week_day_conf_Test_in_view() throws InterruptedException {
		Thread.sleep(1500);
		try {
			cmm.open_week_day_conf1();
			log.info("Tab on week_day_conf");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on week_day_conf");
		}
	}
	
	@Test(priority = 131)
	public void display_Status_of_Sunday_Start_Time_Test_in_view1() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Sunday_Start_Time1(), true);
		log.info("display_Status_of_Sunday_Start_Time1 : " + cmm.display_Status_of_Sunday_Start_Time1());
	}

	@Test(priority = 132)
	public void enable_Status_of_Sunday_Start_Time_Test_in_view1() throws InterruptedException {
		new SoftAssert().assertEquals(cmm.enable_Status_of_Sunday_Start_Time1(), false);
		new SoftAssert().assertAll();
		log.error("enable_Status_of_Sunday_Start_Time1 : " + cmm.enable_Status_of_Sunday_Start_Time1());
	}

	@Test(priority = 133)
	public void display_Status_of_Sunday_End_Time_Test_in_view() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Sunday_End_Time1(), true);
		log.info("display_Status_of_Sunday_End_Time1 : " + cmm.display_Status_of_Sunday_End_Time1());
	}

	@Test(priority = 134)
	public void enable_Status_of_Sunday_End_Time_Test_in_view1() throws InterruptedException {
		new SoftAssert().assertEquals(cmm.enable_Status_of_Sunday_End_Time1(), false);
		new SoftAssert().assertAll();
		log.error("enable_Status_of_Sunday_End_Time1 : " + cmm.enable_Status_of_Sunday_End_Time1());
	}
	@Test(priority = 135)
	public void display_status_of_Close_Test_in_view() throws InterruptedException {
		Assert.assertEquals(cmm.display_Status_of_Close1(), true);
		log.info("display_Status_of_Close1 : " + cmm.display_Status_of_Close1());
	}
	@Test(priority = 136)
	public void enable_status_of_Close_Test_in_view() throws InterruptedException {
		new SoftAssert().assertEquals(cmm.enable_Status_of_Close1(), true);
		new SoftAssert().assertAll();
		log.info("enable_Status_of_Close1 : " + cmm.enable_Status_of_Close1());
	}
	@Test(priority = 137)
	public void tab_on_Close_btn_Test_in_view() throws InterruptedException {
		try {
			cmm.tab_on_close();
			log.info("Tab on close");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on close");
		}
	}
}
