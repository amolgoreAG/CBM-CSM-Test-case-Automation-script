package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CBM;
import PageLayerPackage.Contact_History_Model;

public class Contact_History_Model_Test extends Base_Class_CBM {

	private static final Logger log = Logger.getLogger(Contact_History_Model_Test.class);
	
	private static Contact_History_Model chm;
	
	
	
	@Test(priority = 138)
	public void dispaly_status_of_Contact_hostory_Test() throws InterruptedException {
		chm = new Contact_History_Model();
		Assert.assertEquals(chm.dispaly_status_of_Contact_hostory()	, true);
	}
	@Test(priority = 139)
	public void enable_status_of_Contact_hostory_Test() throws InterruptedException {
		Assert.assertEquals(chm.enable_status_of_Contact_hostory()	, true);
	}
	@Test(priority = 140)
	public void tab_on_Contact_hostory_Test() throws InterruptedException {
		try {
			chm.tab_on_Contact_hostory();
			log.info("Tab on Contact_history");
		} catch (Exception e) {
			log.error("Not able to Tab on Contact_history");
		}
	}
	@Test(priority = 141)
	public void display_status_of_From_Test() throws InterruptedException {
		Assert.assertEquals(chm.display_status_of_From()	, true);
	}
	@Test(priority = 142)
	public void enable_status_of_From_Test() throws InterruptedException {
		Assert.assertEquals(chm.enable_status_of_From()	, true);
	}
	@Test(priority = 143)
	public void tab_On_From_Test() throws InterruptedException {
		try {
			chm.tab_On_From();
			log.info("Tab on From Calender");
		} catch (Exception e) {
			log.error("Not able to Tab on From Calender");
		}
	}
	@Test(priority = 144)
	public void select_from_date_Test() throws InterruptedException {
		try {
			chm.select_from_date();
			log.info("select the from date");
		} catch (InterruptedException e) {
			log.error("Not able to select the from date");
		}
	}
	@Test(priority = 145)
	public void display_status_of_To_Test() throws InterruptedException {
		Assert.assertEquals(chm.display_status_of_To()	, true);
	}
	@Test(priority = 146)
	public void enable_status_of_To_Test() throws InterruptedException {
		Assert.assertEquals(chm.enable_status_of_To()	, true);
	}
	@Test(priority = 147)
	public void tab_On_To_Test() throws InterruptedException {
		try {
			chm.tab_On_To();
			log.info("Tab on To Calender");
		} catch (Exception e) {
			log.error("Not able to Tab on To Calender");
		}
	}
	@Test(priority = 148)
	public void select_to_date_Test() throws InterruptedException {
		try {
			chm.select_to_date();
			log.info("Select the to date");
		} catch (InterruptedException e) {
			log.error("Not able to Select the to date");
		}
	}
	@Test(priority = 149)
	public void display_Status_of_search_Test() throws InterruptedException {
		Assert.assertEquals(chm.display_Status_of_search()	, true);
	}
	@Test(priority = 150)
	public void enable_Status_of_search_Test() throws InterruptedException {
		Assert.assertEquals(chm.enable_Status_of_search()	, true);
	}
	@Test(priority = 151)
	public void tab_on_search_Test() throws InterruptedException {
		try {
			chm.tab_on_search();
			log.info("Tab On Search");
		} catch (Exception e) {
			log.error("Not able to Tab On Search");
		}
	}
	@Test(priority = 152)
	public void display_Status_of_delete_Test() throws InterruptedException {
		Assert.assertEquals(chm.display_Status_of_delete()	, true);
	}
	@Test(priority = 153)
	public void enable_Status_of_delete_Test() throws InterruptedException {
		Assert.assertEquals(chm.enable_Status_of_delete()	, true);
	}
	@Test(priority = 154)
	public void tab_on_delete_Test() throws InterruptedException {
		try {
			chm.tab_on_delete();
			log.info("Tab On Delete");
		} catch (Exception e) {
			log.error("Not able to Tab On Delete");
		}
	}
	@Test(priority = 155)
	public void display_Status_of_Delete_Yes_Test() throws InterruptedException {
		Assert.assertEquals(chm.display_Status_of_Delete_Yes()	, true);
	}
	@Test(priority = 156)
	public void enable_Status_of_Delete_Yes_Test() throws InterruptedException {
		Assert.assertEquals(chm.enable_Status_of_Delete_Yes()	, true);
	}
//	@Test(priority = 157)
	public void tab_on_Delete_Yes_Test() throws InterruptedException {
		try {
			chm.tab_on_Delete_Yes();
			log.info("Tab On Yes");
		} catch (Exception e) {
			log.error("Not able to Tab On Yes");
		}
	}
	@Test(priority = 158)
	public void display_Status_of_Delete_No_Test() throws InterruptedException {
		Assert.assertEquals(chm.display_Status_of_Delete_No()	, true);
	}
	@Test(priority = 159)
	public void enable_Status_of_Delete_No_Test() throws InterruptedException {
		Assert.assertEquals(chm.enable_Status_of_Delete_No()	, true);
	}
	@Test(priority = 160)
	public void tab_on_Delete_No_Test() throws InterruptedException {
		try {
			chm.tab_on_Delete_No();
			log.info("Tab On No");
		} catch (Exception e) {
			log.error("Not able to Tab On No");
		}
	}
	@Test(priority = 161)
	public void display_Status_of_Next_Page_Test() throws InterruptedException {
		Assert.assertEquals(chm.display_Status_of_Next_Page()	, true);
	}
	@Test(priority = 162)
	public void enable_Status_of_Next_Page_Test() throws InterruptedException {
		Assert.assertEquals(chm.enable_Status_of_Next_Page()	, true);
	}
	@Test(priority = 163)
	public void tab_on_Next_Page_Test() throws InterruptedException {
		try {
			chm.tab_on_Next_Page();
			log.info("Tab on Go to Last Page");
		} catch (Exception e) {
			log.error("Not able to Tab on Go to Last Page");
		}
	}
}
