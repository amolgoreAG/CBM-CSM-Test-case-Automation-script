package TestLayerPackage;

import org.junit.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CBM;
import PageLayerPackage.User_Management;

public class User_Management_Test extends Base_Class_CBM {

	private static User_Management um;

	@Test(priority = 227)
	public void display_Status_of_Report_Test() {
		um = new User_Management();
		Assert.assertEquals(um.display_Status_of_user_management(), true);
	}

	@Test(priority = 228)
	public void enable_Status_of_user_management_Test() {
		Assert.assertEquals(um.enable_Status_of_user_management(), true);
	}

	@Test(priority = 229)
	public void tab_on_user_management_Test() {
		um.tab_on_user_management();
	}
	@Test(priority = 230)
	public void display_Status_of_add_User_Test() {
		Assert.assertEquals(um.display_Status_of_add_User(), true);
	}
	
	@Test(priority = 231)
	public void enable_Status_of_add_User_Test() {
		Assert.assertEquals(um.enable_Status_of_add_User(), true);
	}
	
	@Test(priority = 232)
	public void tab_on_add_User_Test() {
		um.tab_on_add_User();
	}
	@Test(priority = 233)
	public void display_Status_of_user_ID_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_user_ID(), true);
	}
	
	@Test(priority = 234)
	public void enable_Status_of_user_ID_Test() {
		Assert.assertEquals(um.enable_Status_of_user_ID(), true);
	}
	
	@Test(priority = 235)
	public void enter_data_in_user_ID_Test() {
		um.enter_data_in_user_ID();
	}
	@Test(priority = 236)
	public void display_Status_of_mobile_Number_Test() {
		Assert.assertEquals(um.display_Status_of_mobile_Number(), true);
	}
	
	@Test(priority = 237)
	public void enable_Status_of_mobile_Number_Test() {
		Assert.assertEquals(um.enable_Status_of_mobile_Number(), true);
	}
	
	@Test(priority = 238)
	public void enter_data_in_mobile_Number_Test() {
		um.enter_data_in_mobile_Number();
	}
	@Test(priority = 239)
	public void display_Status_of_password_Test() {
		Assert.assertEquals(um.display_Status_of_password(), true);
	}
	
	@Test(priority = 240)
	public void enable_Status_of_password_Test() {
		Assert.assertEquals(um.enable_Status_of_password(), true);
	}
	
	@Test(priority = 241)
	public void enter_data_in_password_Test() {
		um.enter_data_in_password();
	}
	@Test(priority = 242)
	public void display_Status_of_first_Name_Test() {
		Assert.assertEquals(um.display_Status_of_first_Name(), true);
	}
	
	@Test(priority = 243)
	public void enable_Status_of_first_Name_Test() {
		Assert.assertEquals(um.enable_Status_of_first_Name(), true);
	}
	
	@Test(priority = 244)
	public void enter_data_in_first_Name_Test() {
		um.enter_data_in_first_Name();
	}
	@Test(priority = 245)
	public void display_Status_of_last_Name_Test() {
		Assert.assertEquals(um.display_Status_of_last_Name(), true);
	}
	
	@Test(priority = 246)
	public void enable_Status_of_last_Name_Test() {
		Assert.assertEquals(um.enable_Status_of_last_Name(), true);
	}
	
	@Test(priority = 247)
	public void enter_data_in_last_Name_Test() {
		um.enter_data_in_last_Name();
	}
	@Test(priority = 248)
	public void display_Status_of_email_Test() {
		Assert.assertEquals(um.display_Status_of_email(), true);
	}
	
	@Test(priority = 249)
	public void enable_Status_of_email_Test() {
		Assert.assertEquals(um.enable_Status_of_email(), true);
	}
	
	@Test(priority = 250)
	public void enter_data_in_email_Test() {
		um.enter_data_in_email();
	}
	@Test(priority = 251)
	public void display_Status_of_role_Test() {
		Assert.assertEquals(um.display_Status_of_role(), true);
	}
	
	@Test(priority = 252)
	public void enable_Status_of_role_Test() {
		Assert.assertEquals(um.enable_Status_of_role(), true);
	}
	
	@Test(priority = 253)
	public void tab_on_role_Test() {
		um.tab_on_role();
	}
	@Test(priority = 254)
	public void display_Status_of_role_admin_Test() {
		Assert.assertEquals(um.display_Status_of_role_admin(), true);
	}
	
	@Test(priority = 255)
	public void enable_Status_of_role_admin_Test() {
		Assert.assertEquals(um.enable_Status_of_role_admin(), true);
	}
	
	@Test(priority = 256)
	public void tab_on_role_admin_Test() {
		um.tab_on_role_admin();
	}
	@Test(priority = 257)
	public void display_Status_of_close_Test() {
		Assert.assertEquals(um.display_Status_of_close(), true);
	}
	
	@Test(priority = 258)
	public void enable_Status_of_close_Test() {
		Assert.assertEquals(um.enable_Status_of_close(), true);
	}

	@Test(priority = 259)
	public void display_Status_of_add_Users_Test() {
		Assert.assertEquals(um.display_Status_of_add_Users(), true);
	}
	
	@Test(priority = 260)
	public void enable_Status_of_add_Users_Test() {
		Assert.assertEquals(um.enable_Status_of_add_Users(), true);
	}
	
//	@Test(priority = 261)
	public void tab_on_add_Users_Test() {
		um.tab_on_add_Users();
	}
	@Test(priority = 262)
	public void tab_on_close_Test() {
		um.tab_on_close();
	}
	
	@Test(priority = 263)
	public void display_Status_of_edit_User_Test() {
		Assert.assertEquals(um.display_Status_of_edit_User(), true);
	}
	
	@Test(priority = 264)
	public void enable_Status_of_edit_User_Test() {
		Assert.assertEquals(um.enable_Status_of_edit_User(), true);
	}

	@Test(priority = 265)
	public void tab_on_edit_User_Test() {
		um.tab_on_edit_User();
	}
	@Test(priority = 266)
	public void display_Status_of_edit_user_ID_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_user_ID(), true);
	}
	
	@Test(priority = 267)
	public void enable_Status_of_edit_user_ID_Test() {
		Assert.assertEquals(um.enable_Status_of_user_ID	(), false);
	}
	@Test(priority = 268)
	public void display_Status_of_edit_mobile_Number_Test() {
		Assert.assertEquals(um.display_Status_of_mobile_Number(), true);
	}
	
	@Test(priority = 269)
	public void enable_Status_of_edit_mobile_Number_Test() {
		Assert.assertEquals(um.enable_Status_of_mobile_Number(), true);
	}
	
	@Test(priority = 270)
	public void enter_data_in_edit_mobile_Number_Test() {
		um.enter_data_in_mobile_Number();
	}

	@Test(priority = 271)
	public void display_Status_of_edit_first_Name_Test() {
		Assert.assertEquals(um.display_Status_of_first_Name(), true);
	}
	
	@Test(priority = 272)
	public void enable_Status_of_edit_first_Name_Test() {
		Assert.assertEquals(um.enable_Status_of_first_Name(), true);
	}
	
	@Test(priority = 273)
	public void enter_data_in_edit_first_Name_Test() {
		um.enter_data_in_first_Name();
	}
	@Test(priority = 274)
	public void display_Status_of_edit_last_Name_Test() {
		Assert.assertEquals(um.display_Status_of_last_Name(), true);
	}
	
	@Test(priority = 275)
	public void enable_Status_of_edit_last_Name_Test() {
		Assert.assertEquals(um.enable_Status_of_last_Name(), true);
	}
	
	@Test(priority = 276)
	public void enter_data_in_edit_last_Name_Test() {
		um.enter_data_in_last_Name();
	}
	@Test(priority = 277)
	public void display_Status_of_edit_email_Test() {
		Assert.assertEquals(um.display_Status_of_email(), true);
	}
	
	@Test(priority = 278)
	public void enable_Status_of_edit_email_Test() {
		Assert.assertEquals(um.enable_Status_of_email(), true);
	}
	
	@Test(priority = 279)
	public void enter_data_in_edit_email_Test() {
		um.enter_data_in_email();
	}
	@Test(priority = 280)
	public void display_Status_of_edit_role_Test() {
		Assert.assertEquals(um.display_Status_of_role(), true);
	}
	
	@Test(priority = 281)
	public void enable_Status_of_edit_role_Test() {
		Assert.assertEquals(um.enable_Status_of_role(), true);
	}
	
	@Test(priority = 282)
	public void tab_on_edit_role_Test() {
		um.tab_on_role();
	}
	@Test(priority = 283)
	public void display_Status_of_edit_role_user_Test() {
		Assert.assertEquals(um.display_Status_of_role_user(), true);
	}
	
	@Test(priority = 284)
	public void enable_Status_of_edit_role_user_Test() {
		Assert.assertEquals(um.enable_Status_of_role_user(), true);
	}
	
	@Test(priority = 285)
	public void tab_on_edit_role_user_Test() {
		um.tab_on_role_user();
	}
	@Test(priority = 286)
	public void display_Status_of_edit_close_Test() {
		Assert.assertEquals(um.display_Status_of_close(), true);
	}
	
	@Test(priority = 287)
	public void enable_Status_of_edit_close() {
		Assert.assertEquals(um.enable_Status_of_close(), true);
	}
	@Test(priority = 288)
	public void display_Status_of_update_User_Test() {
		Assert.assertEquals(um.display_Status_of_update_User(), true);
	}
	
	@Test(priority = 289)
	public void enable_Status_of_update_User_Test() {
		Assert.assertEquals(um.enable_Status_of_update_User(), true);
	}
//	@Test(priority = 290)
	public void tab_on_update_User_Test() {
		um.tab_on_update_User();
	}
	@Test(priority = 291)
	public void tab_on_edit_close() {
		um.tab_on_close();
	}
	@Test(priority = 292)
	public void display_Status_of_view_user_Test() {
		Assert.assertEquals(um.display_Status_of_view_user(), true);
	}
	
	@Test(priority = 293)
	public void enable_Status_of_view_user_Test() {
		Assert.assertEquals(um.enable_Status_of_view_user(), true);
	}
	@Test(priority = 294)
	public void tab_on_view_user_Test() {
		um.tab_on_view_user();
	}
	
	
	
	
	@Test(priority = 295)
	public void display_Status_of_view_user_ID_Test() throws InterruptedException {
		Assert.assertEquals(um.display_Status_of_user_ID(), true);
	}
	
	@Test(priority = 296)
	public void enable_Status_of_view_user_ID_Test() {
		Assert.assertEquals(um.enable_Status_of_user_ID	(), false);
	}
	@Test(priority = 297)
	public void display_Status_of_view_mobile_Number_Test() {
		Assert.assertEquals(um.display_Status_of_mobile_Number(), true);
	}
	
	@Test(priority = 298)
	public void enable_Status_of_view_mobile_Number_Test() {
		Assert.assertEquals(um.enable_Status_of_mobile_Number(), false);
	}

	@Test(priority = 299)
	public void display_Status_of_view_first_Name_Test() {
		Assert.assertEquals(um.display_Status_of_first_Name(), true);
	}
	
	@Test(priority = 300)
	public void enable_Status_of_view_first_Name_Test() {
		Assert.assertEquals(um.enable_Status_of_first_Name(), false);
	}
	@Test(priority = 301)
	public void display_Status_of_view_last_Name_Test() {
		Assert.assertEquals(um.display_Status_of_last_Name(), true);
	}
	
	@Test(priority = 302)
	public void enable_Status_of_view_last_Name_Test() {
		Assert.assertEquals(um.enable_Status_of_last_Name(), false);
	}
	@Test(priority = 303)
	public void display_Status_of_view_email_Test() {
		Assert.assertEquals(um.display_Status_of_email(), true);
	}
	
	@Test(priority = 304)
	public void enable_Status_of_view_email_Test() {
		Assert.assertEquals(um.enable_Status_of_email(), false);
	}
	@Test(priority = 305)
	public void display_Status_of_view_role_Test() {
		Assert.assertEquals(um.display_Status_of_role1(), true);
	}
	
	@Test(priority = 306)
	public void enable_Status_of_view_role_Test() {
		Assert.assertEquals(um.enable_Status_of_role1(), false);
	}
	@Test(priority = 307)
	public void display_Status_of_view_close_Test() {
		Assert.assertEquals(um.display_Status_of_close(), true);
	}
	
	@Test(priority = 308)
	public void enable_Status_of_view_close() {
		Assert.assertEquals(um.enable_Status_of_close(), true);
	}
	@Test(priority = 309)
	public void tab_on_view_close() {
		um.tab_on_close();
	}

}
