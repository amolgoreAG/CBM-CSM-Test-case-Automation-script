package TestLayerPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.Base_Class_CBM;
import PageLayerPackage.audit_Log;

public class audit_Log_Test extends Base_Class_CBM {

	private static audit_Log al;

	@Test(priority = 310)
	public void display_Status_of_audit_Log_Test() {
		al = new audit_Log();
		Assert.assertEquals(al.display_Status_of_audit_Log(), true);
	}

	@Test(priority = 311)
	public void enable_Status_of_audit_Log_Test() {
		Assert.assertEquals(al.enable_Status_of_audit_Log(), true);
	}

	@Test(priority = 312)
	public void tab_on_audit_Log_Test() {
		al.tab_on_audit_Log();
	}

	@Test(priority = 313)
	public void display_Status_of_audit_Report_Test() {
		Assert.assertEquals(al.display_Status_of_audit_Report(), true);
	}

	@Test(priority = 314)
	public void enable_Status_of_audit_Report_Test() {
		Assert.assertEquals(al.enable_Status_of_audit_Report(), true);
	}

	@Test(priority = 315)
	public void tab_on_audit_Report_Test() {
		al.tab_on_audit_Report();
	}

	@Test(priority = 316)
	public void display_Status_of_audit_Filter_Report_Test() {
		Assert.assertEquals(al.display_Status_of_audit_Filter_Report(), true);
	}

	@Test(priority = 317)
	public void enable_Status_of_audit_Filter_Report_Test() {
		Assert.assertEquals(al.enable_Status_of_audit_Filter_Report(), true);
	}

	@Test(priority = 318)
	public void tab_on_audit_Filter_Report_Test() {
		al.tab_on_audit_Filter_Report();
	}

	@Test(priority = 319)
	public void display_Status_of_audit_Login_Test() {
		Assert.assertEquals(al.display_Status_of_audit_Login(), true);
	}

	@Test(priority = 320)
	public void enable_Status_of_audit_Login_Test() {
		Assert.assertEquals(al.enable_Status_of_audit_Login(), true);
	}

	@Test(priority = 321)
	public void tab_on_audit_Login_Test() {
		al.tab_on_audit_Login();
	}

	@Test(priority = 322)
	public void display_Status_of_fromCalender_Test() {
		Assert.assertEquals(al.display_Status_of_fromCalender(), true);
	}

	@Test(priority = 323)
	public void enable_Status_of_fromCalender_Test() {
		Assert.assertEquals(al.enable_Status_of_fromCalender(), true);
	}

	@Test(priority = 324)
	public void tab_ob_fromCalender_Test() {
		al.tab_ob_fromCalender();
	}

	@Test(priority = 325)
	public void select_the_From_date_Test() throws InterruptedException {
		al.select_the_From_date();
	}

	@Test(priority = 326)
	public void display_Status_of_toCalender_Test() {
		Assert.assertEquals(al.display_Status_of_toCalender(), true);
	}

	@Test(priority = 327)
	public void enable_Status_of_toCalender_Test() {
		Assert.assertEquals(al.enable_Status_of_toCalender(), true);
	}

	@Test(priority = 328)
	public void tab_ob_toCalender_Test() {
		al.tab_ob_toCalender();
	}

	@Test(priority = 329)
	public void select_the_To_date_Test() throws InterruptedException {
		al.select_the_To_date();
	}

	@Test(priority = 330)
	public void display_Status_of_employe_Id_Test() {
		Assert.assertEquals(al.display_Status_of_employe_Id(), true);
	}

	@Test(priority = 331)
	public void enable_Status_of_employe_Id_Test() {
		Assert.assertEquals(al.enable_Status_of_employe_Id(), true);
	}

	@Test(priority = 332)
	public void Enter_employe_Id_Test() {
		al.Enter_employe_Id();
	}

	@Test(priority = 333)
	public void display_Status_of_generate_Report_Test() {
		Assert.assertEquals(al.display_Status_of_generate_Report(), true);
	}

	@Test(priority = 334)
	public void enable_Status_of_generate_Report_Test() {
		Assert.assertEquals(al.enable_Status_of_generate_Report(), true);
	}

	@Test(priority = 335)
	public void tab_on_generate_Report_Test() throws InterruptedException {
		al.tab_on_generate_Report();
	}
	@Test(priority = 336)
	public void display_Status_of_refresh_Test() {
		Assert.assertEquals(al.display_Status_of_refresh(), true);
	}
	
	@Test(priority = 337)
	public void enable_Status_of_refresh_Test() {
		Assert.assertEquals(al.enable_Status_of_refresh(), true);
	}
	
	@Test(priority = 338)
	public void tab_on_refresh_Test() throws InterruptedException {
		al.tab_on_refresh();
	}
	@Test(priority = 339)
	public void display_Status_of_last_Page_Test() throws InterruptedException {
		Assert.assertEquals(al.display_Status_of_last_Page(), true);
	}
	
	@Test(priority = 340)
	public void enable_Status_of_last_Page_Test() {
		Assert.assertEquals(al.enable_Status_of_last_Page(), true);
	}
	
	@Test(priority = 341)
	public void tab_on_last_Page_Test() {
		al.tab_on_last_Page();
	}
	@Test(priority = 342)
	public void tab_on_audit_Report_Test2() {
		al.tab_on_audit_Report();
	}
	@Test(priority = 343)
	public void tab_on_audit_User_Test() {
		al.tab_on_audit_User();
	}
	@Test(priority = 344)
	public void tab_ob_fromCalender_Test2() {
		al.tab_ob_fromCalender();
	}

	@Test(priority = 345)
	public void select_the_From_date_Test2() throws InterruptedException {
		al.select_the_From_date();
	}
	@Test(priority = 346)
	public void tab_ob_toCalender_Test2() {
		al.tab_ob_toCalender();
	}

	@Test(priority = 347)
	public void select_the_To_date_Test2() throws InterruptedException {
		al.select_the_To_date();
	}
	@Test(priority = 348)
	public void Enter_employe_Id_Test2() {
		al.Enter_employe_Id();
	}
	@Test(priority = 349)
	public void tab_on_generate_Report_Test2() throws InterruptedException {
		al.tab_on_generate_Report();
	}
	@Test(priority = 350)
	public void tab_on_refresh_Test2() throws InterruptedException {
		al.tab_on_refresh();
	}
	@Test(priority = 351)
	public void tab_on_last_Page_Test2() {
		al.tab_on_last_Page();
	}
}
