package BaseLayerPackage;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Base_Class_CBM {
	public static WebDriver driver;
	public static ChromeOptions option;

	public static void CBM() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\cognicx\\eclipse-workspace\\CBM\\Driver\\chromedriver.exe");
		option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(45));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(45));
		driver.manage().window().maximize();
		driver.get("http://150.242.13.125:8080/CBM/");
//		driver.get("http://43.241.62.118:8080/CBM/");
	}

}
