package PageLayerPackage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CBM;

public class audit_Log extends Base_Class_CBM {


	@FindBy(xpath = "//i[@class='fas fa-film']")
	WebElement audit_Log;
	
	@FindBy(xpath = "//button[@id='picky__button__button']")
	WebElement audit_Report;
	
	@FindBy(xpath = "//div[@id='picky-list']/div[1]/input")
	WebElement audit_Filter_Report;
	
	@FindBy(xpath = "//div[@id='picky-list']/div[2]/div/input")
	WebElement audit_Login;
	
	@FindBy(xpath = "//div[@id='picky-list']/div[2]/div[2]/input")
	WebElement audit_User;
	
	@FindBy(xpath = "(//div[@class='react-datepicker__input-container'])[1]/input")
	WebElement fromCalender;

	@FindBy(xpath = "(//div[@class='react-datepicker__input-container'])[2]/input")
	WebElement toCalender;

	@FindBy(xpath = "//div[@class='react-datepicker__header']/div[1]")
	WebElement Month_Year;

	@FindBy(xpath = "//button[text()='Next Month']")
	WebElement Next_Month;

	@FindBy(xpath = "//div[text()='15']")
	WebElement date;

	@FindBy(xpath = "//button[text()='Previous Month']")
	WebElement Prev_Month;
	
	@FindBy(xpath = "//input[@id='employeeId']")
	WebElement employe_Id;
	
	@FindBy(xpath = "//button[@class='btn btn-primary alignRight']")
	WebElement generate_Report;
	
	@FindBy(xpath = "//button[@class='btnColormain btn btn-outline-primary']")
	WebElement refresh;
	
	@FindBy(xpath = "//span[text()='Last']")
	WebElement last_Page;
	
	public audit_Log() {
		PageFactory.initElements(driver, this);
	}
	public boolean display_Status_of_audit_Log() {
		return audit_Log.isDisplayed();
	}
	
	public boolean enable_Status_of_audit_Log() {
		return audit_Log.isEnabled();
	}
	
	public void tab_on_audit_Log() {
		while (true) {
			if (audit_Log.isDisplayed() == true) {
				audit_Log.click();
				break;
			} else {
				System.out.println("Not able to clicked on audit_Log");
			}
		}
	}
	public boolean display_Status_of_audit_Report() {
		return audit_Report.isDisplayed();
	}
	
	public boolean enable_Status_of_audit_Report() {
		return audit_Report.isEnabled();
	}
	
	public void tab_on_audit_Report() {
		while (true) {
			if (audit_Report.isDisplayed() == true) {
				audit_Report.click();
				break;
			} else {
				System.out.println("Not able to clicked on audit_Report");
			}
		}
	}
	public boolean display_Status_of_audit_Filter_Report() {
		return audit_Filter_Report.isDisplayed();
	}
	
	public boolean enable_Status_of_audit_Filter_Report() {
		return audit_Filter_Report.isEnabled();
	}
	
	public void tab_on_audit_Filter_Report() {
		while (true) {
			if (audit_Filter_Report.isDisplayed() == true) {
				audit_Filter_Report.sendKeys("login");;
				break;
			} else {
				System.out.println("Not able to Enter in audit_Filter_Report");
			}
		}
	}
	public boolean display_Status_of_audit_Login() {
		return audit_Login.isDisplayed();
	}
	
	public boolean enable_Status_of_audit_Login() {
		return audit_Login.isEnabled();
	}
	
	public void tab_on_audit_Login() {
		while (true) {
			if (audit_Login.isDisplayed() == true) {
				audit_Login.click();
				break;
			} else {
				System.out.println("Not able to select audit_Login");
			}
		}
	}
	public void tab_on_audit_User() {
		while (true) {
			if (audit_User.isDisplayed() == true) {
				audit_User.click();
				break;
			} else {
				System.out.println("Not able to select audit_User");
			}
		}
	}
	public boolean display_Status_of_fromCalender() {
		return fromCalender.isDisplayed();
	}
	public boolean enable_Status_of_fromCalender() {
		return fromCalender.isEnabled();
	}
	public void tab_ob_fromCalender() {
		fromCalender.click();
	}
	public void select_the_From_date() throws InterruptedException {
		while (true) {
			if (Month_Year.getText().equalsIgnoreCase("August 2022")) {
				break;
			} else {
				Thread.sleep(1000);
				Prev_Month.click();
			}
		}
		date.click();
	}
	public boolean display_Status_of_toCalender() {
		return toCalender.isDisplayed();
	}
	public boolean enable_Status_of_toCalender() {
		return toCalender.isEnabled();
	}
	public void tab_ob_toCalender() {
		toCalender.click();
	}
	public void select_the_To_date() throws InterruptedException {
		while (true) {
			if (Month_Year.getText().equalsIgnoreCase("November 2023")) {
				break;
			} else {
				Thread.sleep(1000);
				Next_Month.click();
			}
		}
		date.click();
	}
	public boolean display_Status_of_employe_Id() {
		return employe_Id.isDisplayed();
	}
	public boolean enable_Status_of_employe_Id() {
		return employe_Id.isEnabled();
	}
	public void Enter_employe_Id() {
		employe_Id.sendKeys("");
	}
	public boolean display_Status_of_generate_Report() {
		return generate_Report.isDisplayed();
	}
	public boolean enable_Status_of_generate_Report() {
		return generate_Report.isEnabled();
	}
	public void tab_on_generate_Report() throws InterruptedException {
		generate_Report.click();
		Thread.sleep(5000);
	}
	public boolean display_Status_of_refresh() {
		return refresh.isDisplayed();
	}
	public boolean enable_Status_of_refresh() {
		return refresh.isEnabled();
	}
	public void tab_on_refresh() throws InterruptedException {
		refresh.click();
		Thread.sleep(5000);
	}
	public boolean display_Status_of_last_Page() throws InterruptedException {
//		((JavascriptExecutor)driver).executeScript("argument[0].scrollIntoView(true);", last_Page);
		new Actions(driver).moveToElement(last_Page).build().perform();
		Thread.sleep(5000);
		return last_Page.isDisplayed();
	}
	public boolean enable_Status_of_last_Page() {
		return last_Page.isEnabled();
	}
	public void tab_on_last_Page() {
		new Actions(driver).moveToElement(last_Page).click().build().perform();
	}

}
