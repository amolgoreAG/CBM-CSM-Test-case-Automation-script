package PageLayerPackage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CBM;

public class Report_Model extends Base_Class_CBM{

	@FindBy(xpath = "//i[@class='fas fa-file-invoice']")
	WebElement Report;
	
	@FindBy(xpath = "//button[@id='picky__button__button']/span")
	WebElement Report_Type;
	
	@FindBy(xpath = "//div[@id='picky-list']/div[1]/input")
	WebElement Filter;
	
	@FindBy(xpath = "//div[@id='picky-list']/div[2]/div")
	WebElement firstOption;
	
	@FindBy(xpath = "(//button[@id='picky__button__button'])[2]")
	WebElement Campaign_Name;
	
	@FindBy(xpath = "(//div[@id='picky-list'])[2]/div[1]/input")
	WebElement Campaign_Name_Filter;
	
	@FindBy(xpath = "(//div[@id='picky-list'])[2]/div[2]/div[1]")
	WebElement Campaign_Name_Filter_First_Option;
	
	@FindBy(xpath = "(//div[@class='react-datepicker__input-container'])[1]/input")
	WebElement fromCalender;

	@FindBy(xpath = "(//div[@class='react-datepicker__input-container'])[2]/input")
	WebElement toCalender;

	@FindBy(xpath = "//div[@class='react-datepicker__header']/div[1]")
	WebElement Month_Year;

	@FindBy(xpath = "//button[text()='Next Month']")
	WebElement Next_Month;

	@FindBy(xpath = "//div[text()='15']")
	WebElement date;

	@FindBy(xpath = "//button[text()='Previous Month']")
	WebElement Prev_Month;
	
	@FindBy(xpath = "//button[@class='btn btn-primary alignRight']/i")
	WebElement Generate_Report;
	
	@FindBy(xpath = "(//button[@class='btn btn-primary alignRight'])[2]/i")
	WebElement Download_Report;
	
	@FindBy(xpath = "(//button[@id='picky__button__button'])[1]/span")
	WebElement Report_Typ;
	
	@FindBy(xpath = "//div[@id='picky-list']/div[2]/div[2]")
	WebElement Detail_Report;
	
	@FindBy(xpath = "//input[@id='contactNo']")
	WebElement Contact_Number;
	
	@FindBy(xpath = "(//button[@id='picky__button__button'])[3]/span")
	WebElement Caller_Choice;
	
	@FindBy(xpath = "(//div[@id='picky-list'])[3]/div[1]/input")
	WebElement Caller_Choice_Filter;
	
	@FindBy(xpath = "(//div[@id='picky-list'])[3]/div[2]/div[1]")
	WebElement Caller_Choice_first_option;
	
	public Report_Model() {
		PageFactory.initElements(driver, this);
	}
	public boolean display_Status_of_Report() {
		return Report.isDisplayed();
	}
	public boolean enable_Status_of_Report() {
		return Report.isEnabled();
	}
	public void tab_ob_Report() {
		Report.click();
	}
	public boolean display_Status_of_Report_Type() {
		return Report_Type.isDisplayed();
	}
	public boolean enable_Status_of_Report_Type() {
		return Report_Type.isEnabled();
	}
	public void tab_ob_Report_Type() {
		Report_Type.click();
	}
	public boolean display_Status_of_Filter() {
		return Filter.isDisplayed();
	}
	public boolean enable_Status_of_Filter() {
		return Filter.isEnabled();
	}
	public void tab_ob_Filter_and_enetr_data(String Report) throws InterruptedException {
		Filter.click();
		Thread.sleep(3000);
		Filter.sendKeys(Report);
	}
	public boolean display_Status_of_firstOption() {
		return firstOption.isDisplayed();
	}
	public boolean enable_Status_of_firstOption() {
		return firstOption.isEnabled();
	}
	public void tab_ob_firstOption() {
		firstOption.click();
	}
	public boolean display_Status_of_Campaign_Name() {
		return Campaign_Name.isDisplayed();
	}
	public boolean enable_Status_of_Campaign_Name() {
		return Campaign_Name.isEnabled();
	}
	public void tab_ob_Campaign_Name() {
		Campaign_Name.click();
	}
	public boolean display_Status_of_Campaign_Name_Filter() {
		return Campaign_Name_Filter.isDisplayed();
	}
	public boolean enable_Status_of_Campaign_Name_Filter() {
		return Campaign_Name_Filter.isEnabled();
	}
	public void tab_ob_Campaign_Name_Filter_and_enter_campaign_name(String campaignname) throws InterruptedException {
		try {
			Campaign_Name_Filter.click();
		} catch (Exception e) {
			new Actions(driver).click(Campaign_Name_Filter).build().perform();
		}
		Thread.sleep(2000);
		Campaign_Name_Filter.sendKeys(campaignname);
	}
	public boolean display_Status_of_Campaign_Name_Filter_First_Option() {
		return Campaign_Name_Filter_First_Option.isDisplayed();
	}
	public boolean enable_Status_of_Campaign_Name_Filter_First_Option() {
		return Campaign_Name_Filter_First_Option.isEnabled();
	}
	public void tab_ob_Campaign_Name_Filter_First_Option() {
		Campaign_Name_Filter_First_Option.click();
	}
	public boolean display_Status_of_fromCalender() {
		return fromCalender.isDisplayed();
	}
	public boolean enable_Status_of_fromCalender() {
		return fromCalender.isEnabled();
	}
	public void tab_ob_fromCalender() {
		fromCalender.click();
	}
	public void select_the_From_date() throws InterruptedException {
		while (true) {
			if (Month_Year.getText().equalsIgnoreCase("August 2022")) {
				break;
			} else {
				Thread.sleep(1000);
				Prev_Month.click();
			}
		}
		date.click();
	}
	public boolean display_Status_of_toCalender() {
		return toCalender.isDisplayed();
	}
	public boolean enable_Status_of_toCalender() {
		return toCalender.isEnabled();
	}
	public void tab_ob_toCalender() {
		toCalender.click();
	}
	public void select_the_To_date() throws InterruptedException {
		while (true) {
			if (Month_Year.getText().equalsIgnoreCase("November 2023")) {
				break;
			} else {
				Thread.sleep(1000);
				Next_Month.click();
			}
		}
		date.click();
	}
	public boolean display_Status_of_Generate_Report() {
		return Generate_Report.isDisplayed();
	}
	public boolean enable_Status_of_Generate_Report() {
		return Generate_Report.isEnabled();
	}
	public void tab_ob_Generate_Report() {
		Generate_Report.click();
	}
	public boolean display_Status_of_Download_Report() {
		return Download_Report.isDisplayed();
	}
	public boolean enable_Status_of_Download_Report() {
		return Download_Report.isEnabled();
	}
	public void tab_ob_Download_Report() {
		Download_Report.click();
	}
	public boolean display_Status_of_Report_Typ() {
		return Report_Typ.isDisplayed();
	}
	public boolean enable_Status_of_Report_Typ() {
		return Report_Typ.isEnabled();
	}
	public void tab_ob_Report_Typ() {
		Report_Typ.click();
	}
	public boolean display_Status_of_Detail_Report() {
		return Detail_Report.isDisplayed();
	}
	public boolean enable_Status_of_Detail_Report() {
		return Detail_Report.isEnabled();
	}
	public void tab_ob_Detail_Report() {
		Detail_Report.click();
	}
	public boolean display_Status_of_Contact_Number() {
		return Contact_Number.isDisplayed();
	}
	public boolean enable_Status_of_Contact_Number() {
		return Contact_Number.isEnabled();
	}
	public void tab_ob_Contact_Number() {
		Contact_Number.click();
	}
	public boolean display_Status_of_Caller_Choice() {
		return Caller_Choice.isDisplayed();
	}
	public boolean enable_Status_of_Caller_Choice() {
		return Caller_Choice.isEnabled();
	}
	public void tab_ob_Caller_Choice_and_select_value(String caller_Choice_Filter) throws InterruptedException {
		Caller_Choice.click();
		Thread.sleep(2000);
		Caller_Choice_Filter.sendKeys(caller_Choice_Filter);
		Thread.sleep(2000);
		Caller_Choice_first_option.click();
	}
	
}
