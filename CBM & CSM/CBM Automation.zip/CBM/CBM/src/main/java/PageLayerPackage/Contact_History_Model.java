package PageLayerPackage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CBM;

public class Contact_History_Model extends Base_Class_CBM {
	
	@FindBy(xpath = "//i[@class='fas fa-briefcase']")
	WebElement Contact_hostory;
	
	@FindBy(xpath = "//input[@class='myDatePicker']")
	WebElement From;
	
	@FindBy(xpath = "(//div[@class='react-datepicker__input-container'])[2]/input")
	WebElement To;
	
	@FindBy(xpath = "//div[@class='react-datepicker__header']/div[1]")
	WebElement Month_Year;

	@FindBy(xpath = "//button[text()='Next Month']")
	WebElement Next_Month;

	@FindBy(xpath = "//div[text()='15']")
	WebElement date;

	@FindBy(xpath = "//button[text()='Previous Month']")
	WebElement Prev_Month;
	
	@FindBy(xpath = "//button[text()=' View']")
	WebElement search;
	
	@FindBy(xpath = "(//i[@class='fas fa-trash-alt m-r-20'])[1]")
	WebElement delete;
	
	@FindBy(xpath = "(//div[@class='col-md-2'])[4]/button")
	WebElement Delete_Yes;
	
	@FindBy(xpath = "(//div[@class='col-md-2'])[5]/button")
	WebElement Delete_No;
	
	@FindBy(xpath = "(//li[@class='page-item'])[4]/a")
	WebElement Next_Page;
	
	public Contact_History_Model() {
		PageFactory.initElements(driver , this);
	}
	public boolean dispaly_status_of_Contact_hostory() throws InterruptedException {
		Thread.sleep(1000);
		return Contact_hostory.isDisplayed();
	}
	public boolean enable_status_of_Contact_hostory() throws InterruptedException {
		Thread.sleep(1000);
		return Contact_hostory.isEnabled();
	}
	public void tab_on_Contact_hostory() {
		while (true) {
			if(Contact_hostory.isDisplayed()==true) {
				Contact_hostory.click();
				break;
			}
		}
	}
	public boolean display_status_of_From() {
		return From.isDisplayed();
	}
	public boolean enable_status_of_From() {
		return From.isEnabled();
	}
	public void tab_On_From() {
		From.click();
	}
	public void select_from_date() throws InterruptedException {
		while (true) {
			if (Month_Year.getText().equalsIgnoreCase("January 2023")) {
				break;
			} else {
				Thread.sleep(1000);
				Prev_Month.click();
			}
		}
		date.click();
	}
	public boolean display_status_of_To() {
		return To.isDisplayed();
	}
	public boolean enable_status_of_To() {
		return To.isEnabled();
	}
	public void tab_On_To() {
		To.click();
	}
	public void select_to_date() throws InterruptedException {
		while (true) {
			if (Month_Year.getText().equalsIgnoreCase("November 2023")) {
				break;
			} else {
				Thread.sleep(1000);
				Next_Month.click();
			}
		}
		date.click();
	}
	public boolean display_Status_of_search() {
		return search.isDisplayed();
	}
	public boolean enable_Status_of_search() {
		return search.isEnabled();
	}
	public void tab_on_search() {
		search.click();
	}
	public boolean display_Status_of_delete() {
		return delete.isDisplayed();
	}
	public boolean enable_Status_of_delete() {
		return delete.isEnabled();
	}
	public void tab_on_delete() {
		delete.click();
	}
	public boolean display_Status_of_Delete_Yes() {
		return Delete_Yes.isDisplayed();
	}
	public boolean enable_Status_of_Delete_Yes() {
		return Delete_Yes.isEnabled();
	}
	public void tab_on_Delete_Yes() {
		Delete_Yes.click();
	}
	public boolean display_Status_of_Delete_No() {
		return Delete_No.isDisplayed();
	}
	public boolean enable_Status_of_Delete_No() {
		return Delete_No.isEnabled();
	}
	public void tab_on_Delete_No() {
		Delete_No.click();
	}
	public boolean display_Status_of_Next_Page() {
		return Next_Page.isDisplayed();
	}
	public boolean enable_Status_of_Next_Page() {
		return Next_Page.isEnabled();
	}
	public void tab_on_Next_Page() {
		Next_Page.click();
	}
}
