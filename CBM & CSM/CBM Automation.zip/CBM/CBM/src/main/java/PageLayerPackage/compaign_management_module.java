package PageLayerPackage;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CBM;

public class compaign_management_module extends Base_Class_CBM {

	private static final Logger log = Logger.getLogger(compaign_management_module.class);

	@FindBy(xpath = "//i[@class='fas fa-coins']")
	WebElement compaign_management;

	@FindBy(xpath = "//span[text()='CAMPAIGN MANAGEMENT']")
	WebElement compaign_management_text;

	@FindBy(xpath = "//button[text()=' Add Campaign']/span")
	WebElement add_compaign;

	@FindBy(xpath = "//input[@id='campaignName']")
	WebElement compaign_name;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[1]")
	WebElement compaign_type;

	@FindBy(xpath = "(//div[@id='picky-list'])[1]")
	WebElement IVR_Based_CBM;

	@FindBy(xpath = "(//div[@class='react-datepicker__input-container'])[1]/input")
	WebElement fromCalender;

	@FindBy(xpath = "(//div[@class='react-datepicker__input-container'])[2]/input")
	WebElement toCalender;

	@FindBy(xpath = "//div[@class='react-datepicker__header']/div[1]")
	WebElement Month_Year;

	@FindBy(xpath = "//button[text()='Next Month']")
	WebElement Next_Month;

	@FindBy(xpath = "//div[text()='16']")
	WebElement date;

	@FindBy(xpath = "//button[text()='Previous Month']")
	WebElement Prev_Month;

	@FindBy(xpath = "(//button[@id='picky__button__button']/span)[2]")
	WebElement From_Date_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[2]/div/div[5]")
	WebElement From_Date_Time_List;

	@FindBy(xpath = "(//button[@id='picky__button__button']/span)[3]")
	WebElement To_Date_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[3]/div/div[73]")
	WebElement To_Date_Time_List;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[4]")
	WebElement Call_Before;

	@FindBy(xpath = "(//div[@id='picky-list'])[4]/div/div")
	WebElement Call_Before_Time_List;

	@FindBy(xpath = "//input[@id='concurrentCall']")
	WebElement concurrent_call;

	@FindBy(xpath = "(//input[@id='maxAHr'])[1]")
	WebElement Max_Adv_hrs;

	@FindBy(xpath = "(//input[@id='maxAdvMin'])[1]")
	WebElement Max_Adv_min;

	@FindBy(xpath = "(//input[@id='maxAHr'])[2]")
	WebElement Retry_Delay_Hr;

	@FindBy(xpath = "(//input[@id='maxAdvMin'])[2]")
	WebElement Retry_Delay_Min;

	@FindBy(xpath = "//input[@id='retryCount']")
	WebElement Retry_Count;

	@FindBy(xpath = "(//div[@class='form_container'])[2]/div/div/i")
	WebElement week_day_conf;
	
	@FindBy(xpath = "(//div[@class='row'])[2]/div")
	WebElement week_day_conf1;

	@FindBy(xpath = "(//input[@type='checkbox'])[1]")
	WebElement Sunday_CheckBox;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[5]/span")
	WebElement Sunday_Start_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[5]/div/div[41]")
	WebElement Select_Sunday_Start_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[12]/span")
	WebElement Sunday_End_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[12]/div/div[73]")
	WebElement Select_Sunday_End_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[6]/span")
	WebElement Monday_Start_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[6]/div/div[41]")
	WebElement Select_Monday_Start_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[13]/span")
	WebElement Monday_End_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[13]/div/div[73]")
	WebElement Select_Monday_End_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[7]/span")
	WebElement Tuesday_Start_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[7]/div/div[41]")
	WebElement Select_Tuesday_Start_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[14]/span")
	WebElement Tuesday_End_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[14]/div/div[73]")
	WebElement Select_Tuesday_End_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[8]/span")
	WebElement Wednesday_Start_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[8]/div/div[41]")
	WebElement Select_Wednesday_Start_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[15]/span")
	WebElement Wednesday_End_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[15]/div/div[73]")
	WebElement Select_Wednesday_End_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[9]/span")
	WebElement Thursday_Start_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[9]/div/div[41]")
	WebElement Select_Thursday_Start_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[16]/span")
	WebElement Thursday_End_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[16]/div/div[73]")
	WebElement Select_Thursday_End_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[10]/span")
	WebElement Friday_Start_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[10]/div/div[41]")
	WebElement Select_Friday_Start_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[17]/span")
	WebElement Friday_End_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[17]/div/div[73]")
	WebElement Select_Friday_End_Time;

	@FindBy(xpath = "(//input[@type='checkbox'])[7]")
	WebElement Saturday_CheckBox;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[11]/span")
	WebElement Saturday_Start_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[11]/div/div[41]")
	WebElement Select_Saturday_Start_Time;

	@FindBy(xpath = "(//button[@id='picky__button__button'])[18]/span")
	WebElement Saturday_End_Time;

	@FindBy(xpath = "(//div[@id='picky-list'])[18]/div/div[73]")
	WebElement Select_Saturday_End_Time;

	@FindBy(xpath = "(//input[@type='checkbox'])[8]")
	WebElement Campaign_Active_Deactive_CheckBox;

	@FindBy(xpath = "(//a[@href='#/CBM/dashboard/campaign'])[2]")
	WebElement Intigration;

	@FindBy(xpath = "(//input[@type='checkbox'])[9]")
	WebElement Native_Intigration;

	@FindBy(xpath = "//input[@id='ftpUrl']")
	WebElement SFTP_Location;

	@FindBy(xpath = "//input[@id='ftpFileName']")
	WebElement SFTP_FileName;

	@FindBy(xpath = "//input[@id='ftpUserName']")
	WebElement SFTP_UserName;

	@FindBy(xpath = "//input[@id='ftpPassword']")
	WebElement SFTP_Password;

	@FindBy(xpath = "//button[text()='Submit']")
	WebElement submit;

	@FindBy(xpath = "(//button[text()='Close'])[2]")
	WebElement Close;

	@FindBy(xpath = "//button[text()='Close']")
	WebElement Close1;

	@FindBy(xpath = "//button[text()='Add Campaign']")
	WebElement add_campaign;

	@FindBy(xpath = "(//div[@class='table-responsive']/table//tbody/tr/td[9])[1]/span[1]/i")
	WebElement edit;

	@FindBy(xpath = "//button[text()='Update Campaign']")
	WebElement update_campaign;

	@FindBy(xpath = "(//div[@class='table-responsive']/table//tbody/tr/td[9][1]/span)[2]/i")
	WebElement UploadFile;

	@FindBy(xpath = "//input[@type='file']")
	WebElement Browse_File;
	
	@FindBy(xpath = "(//div[@class='table-responsive']/table//tbody/tr/td[9][1]/span)[3]/i")
	WebElement View;

	public compaign_management_module() {
		PageFactory.initElements(driver, this);
	}

	public boolean user_on_compaign_management() throws InterruptedException {
		try {
			compaign_management.click();
			log.info("Tab on campaign Management");
		} catch (Exception e) {
		log.error("Not able to Tab on campaign Management");
		}
		Thread.sleep(1000);
		String text = compaign_management_text.getText();
		System.out.println(text);
		if (compaign_management_text.getText().equalsIgnoreCase("CAMPAIGN MANAGEMENT")) {
			return true;
		} else {
			return false;
		}
	}

	public boolean display_Status_Of_add_compaign() throws InterruptedException {
		Thread.sleep(900);
		return add_compaign.isDisplayed();
	}

	public boolean Enable_Status_Of_add_compaign() throws InterruptedException {
		Thread.sleep(900);
		return add_compaign.isEnabled();
	}

	public void addcomapaign() throws InterruptedException {
		Thread.sleep(900);
		try {
			add_compaign.click();
			log.info("Tab On Add Compaign");
		} catch (Exception e) {
			log.error("Not able to Tab On Add Compaign");
		}
		Thread.sleep(900);
	}

	public boolean first_check_display_status_of_compaign_name() {
		return compaign_name.isDisplayed();
	}

	public boolean check_enable_status_of_compaign_name() {
		return compaign_name.isEnabled();
	}
	public boolean first_check_display_status_of_compaign_name1() {
		return compaign_name.isDisplayed();
	}
	
	public boolean check_enable_status_of_compaign_name1() {
		return compaign_name.isEnabled();
	}

	public void enter_name_of_the_compaign_Name(String compaignNames) throws InterruptedException {
		Thread.sleep(1000);
		try {
			compaign_name.sendKeys(compaignNames);
			log.info("Enter Compaign Name : " + compaign_name.getAttribute("value"));
		} catch (Exception e) {
			log.error("Not able to Enter Compaign Name");
		}
	}

	public boolean check_display_status_of_compaign_type() throws InterruptedException {
		Thread.sleep(1000);
		return compaign_type.isDisplayed();
	}

	public boolean check_enable_status_of_compaign_type() {
		return compaign_type.isEnabled();
	}
	public boolean check_display_status_of_compaign_type1() throws InterruptedException {
		Thread.sleep(1000);
		return compaign_type.isDisplayed();
	}
	
	public boolean check_enable_status_of_compaign_type1() {
		return compaign_type.isEnabled();
	}

	public void it_will_select_ivr_base_cbm_from_drop_down() throws InterruptedException {
		try {
			compaign_type.click();
			log.info("Open Compaign Type");
		} catch (Exception e) {
			log.error("Not able to Open Compaign Type");
		}
		Thread.sleep(1000);
		try {
			IVR_Based_CBM.click();
			log.info("Select IVR Based CBM");
		} catch (Exception e) {
			log.error("Not able to Select IVR Based CBM");
	}
		}

	public boolean display_Status_of_fromCalender() {
		return fromCalender.isDisplayed();
	}

	public boolean enable_Status_of_fromCalender() {
		return fromCalender.isEnabled();
	}
	public boolean display_Status_of_fromCalender1() {
		return fromCalender.isDisplayed();
	}
	
	public boolean enable_Status_of_fromCalender1() {
		return fromCalender.isEnabled();
	}

	public void open_from_calender() {
		try {
			fromCalender.click();
			log.info("Open From Calender");
		} catch (Exception e) {
			log.error("Nt able Open From Calender");
		}
	}

	public void select_the_From_date() throws InterruptedException {
		try {
			while (true) {
				if (Month_Year.getText().equalsIgnoreCase("January 2024")) {
					break;
				} else {
					Thread.sleep(1000);
					Next_Month.click();
				}
			}
			Thread.sleep(2000);
			date.click();
			log.info("select the date");
		} catch (InterruptedException e) {
			log.error("Not able to select the date");
		}
	}

	public boolean display_Status_of_From_Date_Time() {
		return From_Date_Time.isDisplayed();
	}

	public boolean enable_status_of_From_Date_Time() {
		new Actions(driver).moveToElement(From_Date_Time).build().perform();
		return From_Date_Time.isEnabled();
	}
	public boolean display_Status_of_From_Date_Time1() {
		return From_Date_Time.isDisplayed();
	}
	
	public boolean enable_status_of_From_Date_Time1() {
		new Actions(driver).moveToElement(From_Date_Time).build().perform();
		return From_Date_Time.isEnabled();
	}

	public void open_the_from_date_time() throws InterruptedException {
		try {
			From_Date_Time.click();
			log.info("Open From_Date_Time");
		} catch (Exception e) {
		log.error("Nt able to Open From_Date_Time");
		}
	}

	public void select_the_time() throws InterruptedException {
		Thread.sleep(5000);
		try {
			From_Date_Time_List.click();
			log.info("select From_Date_Time");
		} catch (Exception e) {
			log.error("Not able to select From_Date_Time");
		}
	}

	public boolean display_Status_Of_toCalender() {
		return toCalender.isDisplayed();
	}

	public boolean enable_Status_Of_toCalender() {
		return toCalender.isEnabled();
	}
	public boolean display_Status_Of_toCalender1() {
		return toCalender.isDisplayed();
	}
	
	public boolean enable_Status_Of_toCalender1() {
		return toCalender.isEnabled();
	}

	public void open_to_calender() {
		try {
			toCalender.click();
			log.info("Tab on To Calender");
		} catch (Exception e) {
			log.error("Not able to Tab on To Calender");
		}
	}

	public void select_the_To_date() throws InterruptedException {
		try {
			while (true) {
				if (Month_Year.getText().equalsIgnoreCase("February 2024")) {
					break;
				} else {
					Thread.sleep(1000);
					Next_Month.click();
				}
			}
			date.click();
			log.info("Select the date");
		} catch (InterruptedException e) {
			log.error("Not able to Select the date");
		}
	}

	public boolean display_Status_To_of_Date_Time() {
		return To_Date_Time.isDisplayed();
	}

	public boolean enabele_Status_of_To_Date_Time() {
		return To_Date_Time.isEnabled();
	}
	public boolean display_Status_To_of_Date_Time1() {
		return To_Date_Time.isDisplayed();
	}
	
	public boolean enabele_Status_of_To_Date_Time1() {
		return To_Date_Time.isEnabled();
	}

	public void open_the_To_date_time() throws InterruptedException {
		try {
			To_Date_Time.click();
			log.info("Open the To_Date_Time");
		} catch (Exception e) {
			log.error("Not able to Open the To_Date_Time");
		}
		Thread.sleep(1000);
		try {
			To_Date_Time_List.click();
			log.info("Select the To_Date_Time");
		} catch (Exception e) {
			log.error("Not able to Select the To_Date_Time");
		}
	}

	public boolean display_Status_of_Call_Before() {
		return Call_Before.isDisplayed();
	}

	public boolean enable_Status_of_Call_Before() {
		return Call_Before.isEnabled();
	}
	public boolean display_Status_of_Call_Before1() {
		return Call_Before.isDisplayed();
	}
	
	public boolean enable_Status_of_Call_Before1() {
		return Call_Before.isEnabled();
	}

	public void open_the_call_before_drop_down_and_select_the_day() throws InterruptedException {
		try {
			Call_Before.click();
			log.info("Tab on Call Before");
		} catch (Exception e) {
			log.error("Not able to Tab on Call Before");
		}
		Thread.sleep(2000);
		try {
			Call_Before_Time_List.click();
			log.info("Select the Call_Before_Time");
		} catch (Exception e) {
			log.error("Not able to Select the Call_Before_Time");
		}
	}

	public boolean display_status_of_concurrent_call() {
		return concurrent_call.isDisplayed();
	}

	public boolean enabel_status_of_concurrent_call() {
		return concurrent_call.isEnabled();
	}
	public boolean display_status_of_concurrent_call1() {
		return concurrent_call.isDisplayed();
	}
	
	public boolean enabel_status_of_concurrent_call1() {
		return concurrent_call.isEnabled();
	}

	public void enter_concurrent_call_count_in() {
		try {
			concurrent_call.sendKeys("500");
			log.info("Enter Call Current Call count : " + concurrent_call.getAttribute("value"));
		} catch (Exception e) {
			log.error("Not able to Enter Call Current Call count");
		}
	}

	public void enter_Max_Adv_notice_hrs_and_minutes(String Adv_hrs, String Adv_min) throws InterruptedException {
		try {
			Max_Adv_hrs.sendKeys(Adv_hrs);
			log.info("Enter Max_Adv_hrs : " + Max_Adv_hrs.getAttribute("value"));
		} catch (Exception e) {
			log.error("Not able to Enter Max_Adv_hrs");
		}
		Thread.sleep(1000);
		try {
			Max_Adv_min.sendKeys(Adv_min);
			log.info("Enter Max_Adv_min : " + Max_Adv_min.getAttribute("value"));
		} catch (Exception e) {
			log.error("Not able to Enter Max_Adv_min");
		}
	}

	public void enter_Retry_Delay_hrs_and_minutes(String Retry_Delay_hrs, String Retry_Delay_min)
			throws InterruptedException {
		try {
			Retry_Delay_Hr.sendKeys(Retry_Delay_hrs);
			log.info("Enter Retry_Delay_Hr : " + Retry_Delay_Hr.getAttribute("value"));
		} catch (Exception e) {
			log.error("Not able to Enter Retry_Delay_Hr");
		}
		Thread.sleep(1000);
		try {
			Retry_Delay_Min.sendKeys(Retry_Delay_min);
			log.info("Enter Retry_Delay_Min : " + Retry_Delay_Min.getAttribute("value"));
		} catch (Exception e) {
			log.error("Not able to Enter Retry_Delay_Min");
		}

	}

	public void enter_retry_count() {
		try {
			Retry_Count.sendKeys("3");
			log.info("Enter Retry_Count : " + Retry_Count.getAttribute("value"));
		} catch (Exception e) {
			log.error("Not able to Enter Retry_Count");
		}
	}

	public boolean display_Status_of_week_day_conf() {
		return week_day_conf.isDisplayed();
	}

	public boolean enable_Status_of_week_day_conf() {
		return week_day_conf.isEnabled();
	}
	public boolean display_Status_of_week_day_conf1() {
		return week_day_conf.isDisplayed();
	}
	
	public boolean enable_Status_of_week_day_conf1() {
		return week_day_conf.isEnabled();
	}

	public void open_week_day_conf() {
		try {
			while (true) {
				if(week_day_conf.isEnabled()==true) {
					week_day_conf.click();
					break;
				}
			}
			log.info("Open the week_day_conf");
		} catch (Exception e) {
			log.error("not able to Open the week_day_conf");
		}
	}
	public void open_week_day_conf1() throws InterruptedException {
		while (true) {
			if(week_day_conf1.isDisplayed()==true) {
				new Actions(driver).moveToElement(week_day_conf1).build().perform();
				Thread.sleep(1500);
				week_day_conf1.click();
				break;
			}else {
				System.out.println("Not clicked on week_day_conf1");
			}
		}
	}

	public boolean display_Status_of_Sunday_CheckBox() {
		return Sunday_CheckBox.isDisplayed();
	}

	public boolean enable_Status_of_Sunday_CheckBox() {
		return Sunday_CheckBox.isEnabled();
	}
	public boolean display_Status_of_Sunday_CheckBox1() {
		return Sunday_CheckBox.isDisplayed();
	}
	
	public boolean enable_Status_of_Sunday_CheckBox1() {
		return Sunday_CheckBox.isEnabled();
	}

	public boolean selected_Status_of_Sunday_CheckBox_before_select_checkbox() {
		return Sunday_CheckBox.isSelected();
	}

	public void Select_Sunday_CheckBox() throws InterruptedException {
		Sunday_CheckBox.click();
		Thread.sleep(1500);
	}

	public boolean selected_Status_of_Sunday_CheckBox_after_select_checkbox() {
		return Sunday_CheckBox.isSelected();
	}

	public boolean display_Status_of_Sunday_Start_Time() {
		return Sunday_Start_Time.isDisplayed();
	}

	public boolean enable_Status_of_Sunday_Start_Time() {
		return Sunday_Start_Time.isEnabled();
	}
	public boolean display_Status_of_Sunday_Start_Time1() {
		return Sunday_Start_Time.isDisplayed();
	}
	
	public boolean enable_Status_of_Sunday_Start_Time1() {
		return Sunday_Start_Time.isEnabled();
	}

	public void Tab_On_Sunday_Start_Time_And_Select_Time() throws InterruptedException {
		Sunday_Start_Time.click();
		Thread.sleep(1500);
		Select_Sunday_Start_Time.click();
		Thread.sleep(1500);
	}

	public boolean display_Status_of_Sunday_End_Time() throws InterruptedException {
		return Sunday_End_Time.isDisplayed();
	}

	public boolean enable_Status_of_Sunday_End_Time() {
		return Sunday_End_Time.isEnabled();
	}
	public boolean display_Status_of_Sunday_End_Time1() throws InterruptedException {
		return Sunday_End_Time.isDisplayed();
	}
	
	public boolean enable_Status_of_Sunday_End_Time1() {
		return Sunday_End_Time.isEnabled();
	}

	public void Tab_On_Sunday_End_Time_And_Select_Time() throws InterruptedException {
		Sunday_End_Time.click();
		Thread.sleep(1500);
		Select_Sunday_End_Time.click();
	}

	public void Tab_On_Monday_Start_Time_And_Select_Time() throws InterruptedException {
		Monday_Start_Time.click();
		Thread.sleep(1500);
		Select_Monday_Start_Time.click();
		Thread.sleep(1500);
	}

	public void Tab_On_Monday_End_Time_And_Select_Time() throws InterruptedException {
		Monday_End_Time.click();
		Thread.sleep(1500);
		Select_Monday_End_Time.click();
	}

	public void Tab_On_Tuesday_Start_Time_And_Select_Time() throws InterruptedException {
		Tuesday_Start_Time.click();
		Thread.sleep(1500);
		Select_Tuesday_Start_Time.click();
		Thread.sleep(1500);
	}

	public void Tab_On_Tuesday_End_Time_And_Select_Time() throws InterruptedException {
		Tuesday_End_Time.click();
		Thread.sleep(1500);
		Select_Tuesday_End_Time.click();
	}

	public void Tab_On_Wednesday_Start_Time_And_Select_Time() throws InterruptedException {
		Wednesday_Start_Time.click();
		Thread.sleep(1500);
		Select_Wednesday_Start_Time.click();
		Thread.sleep(1500);
	}

	public void Tab_On_Wednesday_End_Time_And_Select_Time() throws InterruptedException {
		Wednesday_End_Time.click();
		Thread.sleep(1500);
		Select_Wednesday_End_Time.click();
	}

	public void Tab_On_Thursday_Start_Time_And_Select_Time() throws InterruptedException {
		Thursday_Start_Time.click();
		Thread.sleep(1500);
		Select_Thursday_Start_Time.click();
		Thread.sleep(1500);
	}

	public void Tab_On_Thursday_End_Time_And_Select_Time() throws InterruptedException {
		Thursday_End_Time.click();
		Thread.sleep(1500);
		Select_Thursday_End_Time.click();
	}

	public void Tab_On_Friday_Start_Time_And_Select_Time() throws InterruptedException {
		Friday_Start_Time.click();
		Thread.sleep(1500);
		Select_Friday_Start_Time.click();
		Thread.sleep(1500);
	}

	public void Tab_On_Friday_End_Time_And_Select_Time() throws InterruptedException {
		Friday_End_Time.click();
		Thread.sleep(1500);
		Select_Friday_End_Time.click();
		Thread.sleep(1500);
	}

	public void Tab_On_Saturday_CheckBox() {
		Saturday_CheckBox.click();
	}

	public void Tab_On_Saturday_Start_Time_And_Select_Time() throws InterruptedException {
		Saturday_Start_Time.click();
		Thread.sleep(1500);
		Select_Saturday_Start_Time.click();
		Thread.sleep(1500);
	}

	public void Tab_On_Saturday_End_Time_And_Select_Time() throws InterruptedException {
		Saturday_End_Time.click();
		Thread.sleep(1500);
		Select_Saturday_End_Time.click();
	}

	public boolean display_Status_of_Campaign_Active_Deactive_CheckBox() {
		return Campaign_Active_Deactive_CheckBox.isDisplayed();
	}

	public boolean enable_Status_of_Campaign_Active_Deactive_CheckBox() {
		return Campaign_Active_Deactive_CheckBox.isEnabled();
	}
	public boolean display_Status_of_Campaign_Active_Deactive_CheckBox1() {
		return Campaign_Active_Deactive_CheckBox.isDisplayed();
	}
	
	public boolean enable_Status_of_Campaign_Active_Deactive_CheckBox1() {
		return Campaign_Active_Deactive_CheckBox.isEnabled();
	}

	public boolean selected_Status_of_Campaign_Active_Deactive_CheckBox_before_select() {
		return Campaign_Active_Deactive_CheckBox.isSelected();
	}

	public void Tab_On_Campaign_Active_Deactive_CheckBox() throws InterruptedException {
		Thread.sleep(1500);
		Campaign_Active_Deactive_CheckBox.click();
	}

	public boolean selected_Status_of_Campaign_Active_Deactive_CheckBox_after_select() {
		return Campaign_Active_Deactive_CheckBox.isSelected();
	}

	public boolean display_status_of_Intigration() {
		return Intigration.isDisplayed();
	}

	public boolean enable_status_of_Intigration() {
		return Intigration.isEnabled();
	}
	public boolean display_status_of_Intigration1() {
		return Intigration.isDisplayed();
	}
	
	public boolean enable_status_of_Intigration1() {
		return Intigration.isEnabled();
	}

	public void tab_on_Intigration_detail_update() {
		Intigration.click();
	}

	public boolean display_status_of_Native_Intigration() {
		return Native_Intigration.isDisplayed();
	}

	public boolean enable_status_of_Native_Intigration() {
		return Native_Intigration.isEnabled();
	}
	public boolean display_status_of_Native_Intigration1() {
		return Native_Intigration.isDisplayed();
	}
	
	public boolean enable_status_of_Native_Intigration1() {
		return Native_Intigration.isEnabled();
	}

	public boolean check_status_of_Native_Intigration_checkbox_before_select() {
		return Native_Intigration.isSelected();
	}

	public void select_Native_Intigration() {
		Native_Intigration.click();
	}

	public boolean check_status_of_Native_Intigration_checkbox_after_select() {
		return Native_Intigration.isSelected();
	}

	public void Unselect_Native_Intigration() {
		Native_Intigration.click();
	}

	public boolean display_status_of_SFTP_Location() {
		return SFTP_Location.isDisplayed();
	}

	public boolean enable_status_of_SFTP_Location() {
		return SFTP_Location.isEnabled();
	}
	public boolean display_status_of_SFTP_Location1() {
		return SFTP_Location.isDisplayed();
	}
	
	public boolean enable_status_of_SFTP_Location1() {
		return SFTP_Location.isEnabled();
	}

	public boolean display_status_of_SFTP_FileName() {
		return SFTP_FileName.isDisplayed();
	}

	public boolean enable_status_of_SFTP_FileName() {
		return SFTP_FileName.isEnabled();
	}
	public boolean display_status_of_SFTP_FileName1() {
		return SFTP_FileName.isDisplayed();
	}
	
	public boolean enable_status_of_SFTP_FileName1() {
		return SFTP_FileName.isEnabled();
	}

	public boolean display_status_of_SFTP_UserName() {
		return SFTP_UserName.isDisplayed();
	}

	public boolean enable_status_of_SFTP_UserName() {
		return SFTP_UserName.isEnabled();
	}
	public boolean display_status_of_SFTP_UserName1() {
		return SFTP_UserName.isDisplayed();
	}
	
	public boolean enable_status_of_SFTP_UserName1() {
		return SFTP_UserName.isEnabled();
	}

	public boolean display_status_of_SFTP_Password() {
		return SFTP_Password.isDisplayed();
	}

	public boolean enable_status_of_SFTP_Password() {
		return SFTP_Password.isEnabled();
	}
	public boolean display_status_of_SFTP_Password1() {
		return SFTP_Password.isDisplayed();
	}
	
	public boolean enable_status_of_SFTP_Password1() {
		return SFTP_Password.isEnabled();
	}

	public boolean display_status_of_submit() {
		return submit.isDisplayed();
	}

	public boolean enable_status_of_submit() {
		return submit.isEnabled();
	}

	public boolean display_status_of_Close() {
		return Close.isDisplayed();
	}

	public boolean enable_status_of_Close() {
		return Close.isEnabled();
	}

	public void tab_on_Close_btn() {
		Close.click();
	}

	public boolean display_Status_of_Close1() {
		return Close1.isDisplayed();
	}

	public boolean enable_Status_of_Close1() {
		return Close1.isEnabled();
	}
	public void tab_on_close() throws InterruptedException {
		Thread.sleep(3000);
		Close1.click();
	}

	public boolean display_Status_of_add_campaign() {
		new Actions(driver).moveToElement(add_campaign).build().perform();
		return add_campaign.isDisplayed();
	}

	public boolean enable_Status_of_add_campaign() {
		return add_campaign.isEnabled();
	}

	public void tab_on_add_campaign() {
		try {
			add_campaign.click();
		} catch (Exception e) {
			new Actions(driver).click(add_campaign).build().perform();
		}
	}

	public boolean display_Status_of_edit() throws InterruptedException {
		Thread.sleep(2000);
		new Actions(driver).moveToElement(edit).build().perform();
		return edit.isDisplayed();
	}

	public boolean enable_Status_of_edit() {
		return edit.isEnabled();
	}

	public void tab_on_edit() throws InterruptedException {
		Thread.sleep(5000);
			try {
				edit.click();
			} catch (Exception e) {
				new Actions(driver).click(edit).build().perform();
			}
	}

	public boolean display_Status_of_Close_in_update() throws InterruptedException {
		Thread.sleep(2500);
		return Close1.isDisplayed();
	}

	public boolean enable_Status_of_Close_in_update() {
		return Close1.isEnabled();
	}

	public boolean display_Status_of_update_campaign() {
		return update_campaign.isDisplayed();
	}

	public boolean enable_Status_of_update_campaign() {
		return update_campaign.isEnabled();
	}

	public void tab_on_update_campaign() throws InterruptedException {
		Thread.sleep(5000);
		while (true) {
			if (update_campaign.isDisplayed() == true) {

				break;

			} else {
				update_campaign.click();
				System.out.println("update_campaign simple click");
				
			}
		}
		Thread.sleep(3000);
		

	}
	public void tab_on_close_campaign() throws InterruptedException {
		Thread.sleep(5000);
		while (true) {
			if (Close1.isDisplayed() == true) {
				
				break;
				
			} else {
				Close1.click();
				System.out.println("Close1 simple click");
				
			}
		}
		Thread.sleep(3000);
		
		
	}

	public boolean display_Status_of_UploadFile() {
		return UploadFile.isDisplayed();
	}

	public boolean enable_Status_of_UploadFile() {
		return UploadFile.isEnabled();
	}

	public void tab_on_UploadFile() throws InterruptedException {
		Thread.sleep(5000);
		while (true) {
			if (UploadFile.isDisplayed() == true) {
				
				break;
			} else {				
				System.out.println("UploadFile normal click");
			}
			try {
				UploadFile.click();
				System.out.println("UploadFile by normal click");
			} catch (Exception e) {
				new Actions(driver).click(UploadFile).build().perform();
				System.out.println("UploadFile by Action Click");
			}

		}
		Thread.sleep(2000);
		
	}
	public void tab_on__Attached_File() throws InterruptedException {
		
		Thread.sleep(1000);
		Browse_File.sendKeys("‪C:\\Users\\cognicx\\Downloads\\contact-listssssss.csv");
		Thread.sleep(7000);
	}
	public void tab_on_View() throws InterruptedException {
		Thread.sleep(5000);
		try {
			View.click();
		} catch (Exception e) {
			new Actions(driver).click(View).build().perform();
		}
	}
}
