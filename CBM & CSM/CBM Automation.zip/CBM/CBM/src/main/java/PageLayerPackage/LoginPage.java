package PageLayerPackage;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CBM;

public class LoginPage extends Base_Class_CBM {

	private static final Logger log = Logger.getLogger(LoginPage.class);


	@FindBy(xpath = "//input[@placeholder='UserName']")
	WebElement Username;
	
	@FindBy(xpath = "//input[@id='password']")
	WebElement Password;
	
	@FindBy(xpath = "//button[text()='LOGIN']")
	WebElement Loginbtn;
	
	public LoginPage() {
		PageFactory.initElements(driver , this);
	}
	public boolean dispaly_status_of_Username() throws InterruptedException {
		Thread.sleep(1000);
		return Username.isDisplayed();
	}
	public boolean enable_Status_of_username() {
		return Username.isEnabled();
	}
	public void enter_username(String username) {
		Username.sendKeys(username);
		log.info("Enter Username : " + Username.getAttribute("value"));
	}
	public boolean dispaly_status_of_Password() throws InterruptedException {
		Thread.sleep(1000);
		return Password.isDisplayed();
	}
	public boolean enable_Status_of_Password() {
		return Password.isEnabled();
	}
	public void enter_Password(String password) {
		Password.sendKeys(password);
		log.info("Enter password : " + Password.getAttribute("value"));
	}
	public void clickOnLoginbtn() throws InterruptedException {
		Thread.sleep(1000);
		Loginbtn.click();
		log.info("Tab On Logn");
	}
}
