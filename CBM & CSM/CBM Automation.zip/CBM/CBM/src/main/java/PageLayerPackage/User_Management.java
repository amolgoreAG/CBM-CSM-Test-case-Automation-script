package PageLayerPackage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.Base_Class_CBM;

public class User_Management extends Base_Class_CBM {

	@FindBy(xpath = "//i[@class='fas fa-users']")
	WebElement user_management;

	@FindBy(xpath = "//button[text()=' Add User']")
	WebElement add_User;

	@FindBy(xpath = "//input[@id='employeeId']")
	WebElement user_ID;

	@FindBy(xpath = "//input[@id='mobileNumber']")
	WebElement mobile_Number;

	@FindBy(xpath = "//input[@id='password']")
	WebElement password;

	@FindBy(xpath = "//input[@id='firstName']")
	WebElement first_Name;

	@FindBy(xpath = "//input[@id='lastName']")
	WebElement last_Name;

	@FindBy(xpath = "//input[@id='email']")
	WebElement email;

	@FindBy(xpath = "//div[@class='react-dropdown-select-content react-dropdown-select-type-single css-1m5113o e1gn6jc30']")
	WebElement role;
	
	@FindBy(xpath = "//input[@id='role']")
	WebElement role1;

	@FindBy(xpath = "//div[@role='list']/span[1]")
	WebElement role_admin;

	@FindBy(xpath = "//div[@role='list']/span[2]")
	WebElement role_user;

	@FindBy(xpath = "//button[text()='Close']")
	WebElement close;

	@FindBy(xpath = "//button[text()='Add User']")
	WebElement add_Users;

	@FindBy(xpath = "(//span[@class='blue-text'])[1]/i")
	WebElement edit_User;
	
	@FindBy(xpath = "//button[text()='Update User']")
	WebElement update_User;
	
	@FindBy(xpath = "(//span[@data-popper='popper'])[2]/i")
	WebElement view_user;
	

	public User_Management() {
		PageFactory.initElements(driver, this);
	}

	public boolean display_Status_of_user_management() {
		return user_management.isDisplayed();
	}

	public boolean enable_Status_of_user_management() {
		return user_management.isEnabled();
	}

	public void tab_on_user_management() {
		user_management.click();
	}

	public boolean display_Status_of_add_User() {
		return add_User.isDisplayed();
	}

	public boolean enable_Status_of_add_User() {
		return add_User.isEnabled();
	}

	public void tab_on_add_User() {
		while (true) {
			if (add_User.isDisplayed() == true) {
				add_User.click();
				break;
			} else {
				System.out.println("Add User is not clicked");
			}
		}
	}

	public boolean display_Status_of_user_ID() throws InterruptedException {
		Thread.sleep(2500);
		return user_ID.isDisplayed();
	}

	public boolean enable_Status_of_user_ID() {
		return user_ID.isEnabled();
	}

	public void enter_data_in_user_ID() {
		while (true) {
			if (user_ID.isDisplayed() == true) {
				user_ID.sendKeys("ABC123456");
				break;
			} else {
				System.out.println("user_ID is not Entered");
			}
		}
	}

	public boolean display_Status_of_mobile_Number() {
		return mobile_Number.isDisplayed();
	}

	public boolean enable_Status_of_mobile_Number() {
		return mobile_Number.isEnabled();
	}

	public void enter_data_in_mobile_Number() {
		while (true) {
			if (mobile_Number.isDisplayed() == true) {
				mobile_Number.sendKeys("9876543210");
				break;
			} else {
				System.out.println("mobile_Number is not Entered");
			}
		}
	}

	public boolean display_Status_of_password() {
		return password.isDisplayed();
	}

	public boolean enable_Status_of_password() {
		return password.isEnabled();
	}

	public void enter_data_in_password() {
		while (true) {
			if (password.isDisplayed() == true) {
				password.sendKeys("9876543210");
				break;
			} else {
				System.out.println("password is not Entered");
			}
		}
	}

	public boolean display_Status_of_first_Name() {
		return first_Name.isDisplayed();
	}

	public boolean enable_Status_of_first_Name() {
		return first_Name.isEnabled();
	}

	public void enter_data_in_first_Name() {
		while (true) {
			if (first_Name.isDisplayed() == true) {
				first_Name.sendKeys("Amol");
				break;
			} else {
				System.out.println("first_Name is not Entered");
			}
		}
	}

	public boolean display_Status_of_last_Name() {
		return last_Name.isDisplayed();
	}

	public boolean enable_Status_of_last_Name() {
		return last_Name.isEnabled();
	}

	public void enter_data_in_last_Name() {
		while (true) {
			if (last_Name.isDisplayed() == true) {
				last_Name.sendKeys("Gore");
				break;
			} else {
				System.out.println("first_Name is not Entered");
			}
		}
	}

	public boolean display_Status_of_email() {
		return email.isDisplayed();
	}

	public boolean enable_Status_of_email() {
		return email.isEnabled();
	}

	public void enter_data_in_email() {
		while (true) {
			if (email.isDisplayed() == true) {
				email.sendKeys("amolgore@707gmail.com");
				break;
			} else {
				System.out.println("email is not Entered");
			}
		}
	}

	public boolean display_Status_of_role() {
		return role.isDisplayed();
	}

	public boolean enable_Status_of_role() {
		return role.isEnabled();
	}
	public boolean display_Status_of_role1() {
		return role1.isDisplayed();
	}
	
	public boolean enable_Status_of_role1() {
		return role1.isEnabled();
	}

	public void tab_on_role() {
		while (true) {
			if (role.isDisplayed() == true) {
				role.click();
				break;
			} else {
				System.out.println("not click on role");
			}
		}
	}

	public boolean display_Status_of_role_admin() {
		return role_admin.isDisplayed();
	}

	public boolean enable_Status_of_role_admin() {
		return role_admin.isEnabled();
	}

	public void tab_on_role_admin() {
		while (true) {
			if (role_admin.isDisplayed() == true) {
				role_admin.click();
				break;
			} else {
				System.out.println("not click on role_admin");
			}
		}
	}

	public boolean display_Status_of_close() {
		return close.isDisplayed();
	}

	public boolean enable_Status_of_close() {
		return close.isEnabled();
	}

	public void tab_on_close() {
		while (true) {
			if (close.isDisplayed() == true) {
				close.click();
				break;
			} else {
				System.out.println("not click on close");
			}
		}
	}

	public boolean display_Status_of_add_Users() {
		return add_Users.isDisplayed();
	}

	public boolean enable_Status_of_add_Users() {
		return add_Users.isEnabled();
	}

	public void tab_on_add_Users() {
		while (true) {
			if (add_Users.isDisplayed() == true) {
				add_Users.click();
				break;
			} else {
				System.out.println("not click on add_Users");
			}
		}
	}

	public boolean display_Status_of_edit_User() {
		return edit_User.isDisplayed();
	}

	public boolean enable_Status_of_edit_User() {
		return edit_User.isEnabled();
	}

	public void tab_on_edit_User() {
		while (true) {
			if (edit_User.isDisplayed() == true) {
				edit_User.click();
				break;
			} else {
				System.out.println("not click on edit_User");
			}
		}
	}
	public boolean display_Status_of_role_user() {
		return role_user.isDisplayed();
	}

	public boolean enable_Status_of_role_user() {
		return role_user.isEnabled();
	}

	public void tab_on_role_user() {
		while (true) {
			if (role_user.isDisplayed() == true) {
				role_user.click();
				break;
			} else {
				System.out.println("not click on role_user");
			}
		}
	}
	public boolean display_Status_of_update_User() {
		return update_User.isDisplayed();
	}
	
	public boolean enable_Status_of_update_User() {
		return update_User.isEnabled();
	}
	
	public void tab_on_update_User() {
		while (true) {
			if (update_User.isDisplayed() == true) {
				update_User.click();
				break;
			} else {
				System.out.println("not click on update_User");
			}
		}
	}
	public boolean display_Status_of_view_user() {
		return view_user.isDisplayed();
	}
	
	public boolean enable_Status_of_view_user() {
		return view_user.isEnabled();
	}
	
	public void tab_on_view_user() {
		while (true) {
			if (view_user.isDisplayed() == true) {
				view_user.click();
				break;
			} else {
				System.out.println("not click on view_user");
			}
		}
	}

}
